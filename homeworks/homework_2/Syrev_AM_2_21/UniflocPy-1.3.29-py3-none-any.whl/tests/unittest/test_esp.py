import ast
import os
import sys
import unittest

import pandas as pd

from tests.unittest.example_strings import ESP
from unifloc.equipment.esp import Esp
from unifloc.pvt.fluid_flow import FluidFlow
from unifloc.tools.exceptions import UniflocPyError


class TestEsp(unittest.TestCase):
    def setUp(self) -> None:
        data = {
            "ID": 99999,
            "source": "legacy",
            "manufacturer": "Reda",
            "name": "DN500",
            "stages_max": 400,
            "rate_nom_sm3day": 30,
            "rate_opt_min_sm3day": 20,
            "rate_opt_max_sm3day": 40,
            "rate_max_sm3day": 66,
            "slip_nom_rpm": 3000,
            "freq_Hz": 50,
            "eff_max": 0.4,
            "height_stage_m": 0.035,
            "Series": 4,
            "d_od_mm": 86,
            "d_cas_min_mm": 112,
            "d_shaft_mm": 17,
            "area_shaft_mm2": 227,
            "power_limit_shaft_kW": 72,
            "power_limit_shaft_high_kW": 120,
            "power_limit_shaft_max_kW": 150,
            "pressure_limit_housing_atma": 390,
            "d_motor_od_mm": 95,
            "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
            "head_points": [
                4.88,
                4.73,
                4.66,
                4.61,
                4.52,
                4.35,
                4.1,
                3.74,
                3.2800000000000002,
                2.73,
                2.11,
                1.45,
                0.77,
                0,
            ],
            "power_points": [
                0.02,
                0.022,
                0.025,
                0.027,
                0.03,
                0.032,
                0.035,
                0.038,
                0.041,
                0.043000000000000003,
                0.046,
                0.049,
                0.052000000000000005,
                0.055,
            ],
            "eff_points": [
                0,
                0.12,
                0.21,
                0.29,
                0.35000000000000003,
                0.38,
                0.4,
                0.39,
                0.37,
                0.32,
                0.26,
                0.19,
                0.1,
                0,
            ],
        }
        self.h_mes = 100
        self.stages = 100
        self.esp_data = pd.Series(data, name=data["ID"])
        print(f"Test: {self.shortDescription()}")

    def test_esp_data_series(self):
        """
        Esp: задание esp_data с помощью pd.Series
        """
        self.esp = Esp(self.h_mes, self.stages, self.esp_data, None, True, True)
        self.assertIsInstance(self.esp.esp_data, pd.Series)

    def test_esp_data_dict(self):
        """
        Esp: задание esp_data с помощью dict
        """
        self.esp = Esp(self.h_mes, self.stages, self.esp_data.to_dict(), None, True, True)
        self.assertIsInstance(self.esp.esp_data, pd.Series)

    def test_esp_data_dataframe(self):
        """
        Esp: задание esp_data с помощью нереализованного способа DataFrame
        """
        with self.assertRaises(UniflocPyError):
            Esp(self.h_mes, self.stages, pd.DataFrame(self.esp_data), None, True, True)

    def test_esp_calc_p_int_no_corr(self):
        """
        Esp: расчет давления на приеме насоса без коррекций
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq
        )

        self.assertAlmostEqual(pt[0], 13147341.271568477, delta=10)
        self.assertAlmostEqual(pt[1], 291.32754435510304, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_esp_calc_p_int_visc_corr(self):
        """
        Esp: расчет давления на приеме насоса с коррекцией на вязкость
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, True, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq
        )

        self.assertAlmostEqual(pt[0], 13258582.357277524, delta=10)
        self.assertAlmostEqual(pt[1], 291.1683573108402, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_esp_calc_p_dis_no_corr(self):
        """
        Esp: расчет давления на выкиде насоса без коррекций
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                }
            },
        }
        p_int = 50 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400, wct=0.5, p=p_int, t=t, direction_to="dis", freq=freq
        )

        self.assertAlmostEqual(pt[0], 7378686.421463114, delta=10)
        self.assertAlmostEqual(pt[1], 294.82, delta=0.01)
        self.assertAlmostEqual(pt[2], 0)

    def test_esp_calc_p_dis_visc_corr(self):
        """
        Esp: расчет давления на выкиде насоса с коррекцией на вязкость
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                }
            },
        }
        p_int = 50 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, True, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400, wct=0.5, p=p_int, t=t, direction_to="dis", freq=freq
        )

        self.assertAlmostEqual(pt[0], 7314683.291930212, delta=10)
        self.assertAlmostEqual(pt[1], 294.96395642097514, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_esp_add_head_points(self):
        """
        Esp: проверка добавления нулевого напора
        """
        self.esp_data.head_points = self.esp_data.head_points[:-1]
        self.esp_data.rate_points = self.esp_data.rate_points[:-1]
        self.esp_data.power_points = self.esp_data.power_points[:-1]
        self.esp_data.eff_points = self.esp_data.eff_points[:-1]
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), None, True, False
        )
        self.assertEqual(self.esp.head_points[-1], 0)

    def test_esp_add_rate_points(self):
        """
        Esp: проверка добавления нулевого дебита
        """
        self.esp_data.head_points = self.esp_data.head_points[1:]
        self.esp_data.rate_points = self.esp_data.rate_points[1:]
        self.esp_data.power_points = self.esp_data.power_points[1:]
        self.esp_data.eff_points = self.esp_data.eff_points[1:]
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), None, True, False
        )
        self.assertEqual(self.esp.rate_points[0], 0)

    def test_esp_calc_p_well_stop(self):
        """
        Esp: расчет давления на выкиде насоса при отключенном насосе
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                }
            },
        }
        p_int = 50
        t = 20
        freq = 0
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, True, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400, wct=0.5, p=p_int, t=t, direction_to="dis", freq=freq
        )

        self.assertAlmostEqual(pt[0], p_int, delta=0.01)
        self.assertAlmostEqual(pt[1], t, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_esp_calc_p_dis_temp_calc_off(self):
        """
        Esp: расчет давления на выкиде насоса с отключенным температурным расчетом
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                }
            },
        }
        p_int = 50 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400,
            wct=0.5,
            p=p_int,
            t=t,
            direction_to="dis",
            freq=freq,
            temp_grad=0,
        )

        self.assertAlmostEqual(pt[0], 7382730.250731848, delta=10)
        self.assertAlmostEqual(pt[1], t, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_esp_calc_p_dis_temp_grad(self):
        """
        Esp: расчет давления на выкиде насоса при заданном температурном градиенте
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                }
            },
        }
        p_int = 50 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        self.esp = Esp(
            self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, False
        )
        pt = self.esp.calc_pt(
            q_liq=40 / 86400,
            wct=0.5,
            p=p_int,
            t=t,
            direction_to="dis",
            freq=freq,
            temp_grad=0.05,
        )

        self.assertAlmostEqual(pt[0], 7370565.132059846, delta=10)
        self.assertAlmostEqual(pt[1], 298.15, delta=0.01)
        self.assertAlmostEqual(pt[2], 0, delta=0.01)

    def test_docstring_example(self):
        """
        Esp: проверка примера, представленного в docstring
        """
        file_path = os.path.abspath(sys.modules[Esp.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)

        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )
        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(ESP, example_string)

        # Инициализация исходных данных
        # Считывание из json-базы паспортных характеристик насоса
        esp_data = {
            "ID": 99999,
            "source": "legacy",
            "manufacturer": "Reda",
            "name": "DN500",
            "stages_max": 400,
            "rate_nom_sm3day": 30,
            "rate_opt_min_sm3day": 20,
            "rate_opt_max_sm3day": 40,
            "rate_max_sm3day": 66,
            "slip_nom_rpm": 3000,
            "freq_Hz": 50,
            "eff_max": 0.4,
            "height_stage_m": 0.035,
            "Series": 4,
            "d_od_mm": 86,
            "d_cas_min_mm": 112,
            "d_shaft_mm": 17,
            "area_shaft_mm2": 227,
            "power_limit_shaft_kW": 72,
            "power_limit_shaft_high_kW": 120,
            "power_limit_shaft_max_kW": 150,
            "pressure_limit_housing_atma": 390,
            "d_motor_od_mm": 95,
            "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
            "head_points": [
                4.88,
                4.73,
                4.66,
                4.61,
                4.52,
                4.35,
                4.1,
                3.74,
                3.2800000000000002,
                2.73,
                2.11,
                1.45,
                0.77,
                0,
            ],
            "power_points": [
                0.02,
                0.022,
                0.025,
                0.027,
                0.03,
                0.032,
                0.035,
                0.038,
                0.041,
                0.043000000000000003,
                0.046,
                0.049,
                0.052000000000000005,
                0.055,
            ],
            "eff_points": [
                0,
                0.12,
                0.21,
                0.29,
                0.35000000000000003,
                0.38,
                0.4,
                0.39,
                0.37,
                0.32,
                0.26,
                0.19,
                0.1,
                0,
            ],
        }
        # Инициализация свойств флюида
        q_fluid = 20
        wct = 0.1
        fluid_data = {
            "q_fluid": q_fluid / 86400,
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.95,
                    "rp": 50,
                }
            },
        }
        # Инициализация модели флюида
        fluid1 = FluidFlow(**fluid_data)
        # Инициализация класса ЭЦН
        h_mes = 1600
        stages = 100
        viscosity_correction = False
        gas_correction = False
        esp_calculation = Esp(
            h_mes,
            stages,
            esp_data,
            fluid1,
            viscosity_correction,
            gas_correction,
        )
        # Необходимо подать давление и температуру на приеме/выкиде насоса в зависимости от направления расчета
        # (например, если расчет идет от устья к забою, то подаем параметр direction_to='in',
        # температуру и давление
        # на выкиде  и в результате получаем давление на приеме насоса)
        p = 120 * 101325
        t = 30 + 273.15
        freq = 50
        direction_to = "in"
        # Поправка на напор (опционально, по умолчанию None)
        head_factor = 1
        # Коэффициент проскальзывания (опционально, по умолчанию 0.97222)
        slippage_factor = 0.97222
        # Расчет давления и температуры на выкиде или на приеме (в зависимости от направления расчета)
        pt_calc = esp_calculation.calc_pt(
            p,
            t,
            freq,
            q_fluid / 86400,
            wct,
            direction_to=direction_to,
            head_factor=head_factor,
            slippage_factor=slippage_factor,
        )
        self.assertAlmostEqual(pt_calc[0], 8676292.985222656, delta=10)
        self.assertAlmostEqual(pt_calc[1], 299.85485682825026, delta=0.1)
        self.assertEqual(pt_calc[2], 0)

    def test_lower_limit_example(self):
        """
        Esp: проверка срабатывания проверки на минимальное давление
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)
        stages = 600
        self.esp = Esp(self.h_mes, stages, self.esp_data.to_dict(), fluid, False, False)
        pt = self.esp.calc_pt(
            q_liq=10 / 86400, wct=1, p=p_dis, t=t, direction_to="int", freq=freq
        )

        self.assertAlmostEqual(pt[0], 90000, delta=10)
        self.assertAlmostEqual(pt[1], 280.8428530252235, delta=0.01)
        self.assertAlmostEqual(pt[2], 1, delta=0.01)


    def test_esp_gascorr(self):
        """
        Esp: проверка коррекции НРХ на свободный газ
        """
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        fluid = FluidFlow(**fluid_data)

        # Без коррекции
        esp1 = Esp(self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, False)
        p_in1 = esp1.calc_pt(q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq)[0]

        # C коррекцией
        esp2 = Esp(self.h_mes, self.stages, self.esp_data.to_dict(), fluid, False, True)
        p_in2 = esp2.calc_pt(q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq)[0]

        # Проверяем, что коррекция отработала верно
        self.assertTrue(p_in1 < p_in2)


if __name__ == "__main__":
    unittest.main()
