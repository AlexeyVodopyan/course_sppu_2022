import ast
import os
import sys

import pandas as pd
import pytest
import unittest

import tests.unittest.example_strings as strs
import tests.unittest.pvt_test_data as data
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.units_converter as uc


class TestWatCorrelations(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        print(f"Test: {self.shortDescription()}")
        self.wct = 0.1
        self.qliq = uc.convert_rate(100, "m3/day", "m3/s")
        self.gamma_gas = 0.6
        self.gamma_oil = 0.8
        self.gamma_wat = 1
        self.rp = 80
        self.oil_correlations = {
            "pb": "Standing",
            "rs": "Standing",
            "rho": "Standing",
            "b": "Standing",
            "mu": "Beggs",
            "compr": "Vasquez",
        }
        self.gas_correlations = {
            "ppc": "Standing",
            "tpc": "Standing",
            "z": "Dranchuk",
            "mu": "Lee",
        }
        self.water_correlations = {
            "b": "McCain",
            "compr": "Kriel",
            "rho": "Standing",
            "mu": "McCain",
        }
        self.salinity = 0.1
        self.rsb = {"value": 80, "p": 10000000, "t": 303.15}
        self.bob = {"value": 1.5, "p": 10000000, "t": 303.15}
        self.muob = {"value": 0.5, "p": 10000000, "t": 303.15}
        self.table_model_data = None
        self.use_table_model = False
        self.p_sep = 4 * 10 ** 6
        self.t_sep = 303.15
        self.k_sep = 0.5
        self.pvt_model_data = {
            "black_oil": {
                "gamma_gas": self.gamma_gas,
                "gamma_wat": self.gamma_wat,
                "gamma_oil": self.gamma_oil,
                "rp": self.rp,
                "salinity": self.salinity,
                "oil_correlations": self.oil_correlations,
                "gas_correlations": self.gas_correlations,
                "water_correlations": self.water_correlations,
                "rsb": self.rsb,
                "muob": self.muob,
                "bob": self.bob,
                "table_model_data": None,
                "use_table_model": False,
            }
        }

        self.fluid_flow = fl.FluidFlow(self.qliq, self.wct, self.pvt_model_data)
        self.fluid_flow_gas = fl.FluidFlow(
            self.qliq, self.wct, self.pvt_model_data, fluid_type="gas"
        )
        self.fluid_flow_gas_q_zero = fl.FluidFlow(
            0, self.wct, self.pvt_model_data, fluid_type="gas"
        )

    def test_qo_5_30(self):
        """
        FluidFlow: Дебит нефти для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.qo, 0.0012664982016376742, places=5)

    def test_qw_5_30(self):
        """
        FluidFlow: Дебит воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.qw, 10.050320333498314 / 86400, places=5)

    def test_qg_5_30(self):
        """
        FluidFlow: Дебит газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.qg, 78.20467403422214 / 86400, places=5)

    def test_ql_5_30(self):
        """
        FluidFlow: Дебит жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.ql, 0.0013828213536457566, places=5)

    def test_qm_5_30(self):
        """
        FluidFlow: Дебит смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.qm, 0.0022879680438566605, places=5)

    def test_mul_5_30(self):
        """
        FluidFlow: Вязкость жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.mul, 0.9361074925475188, places=5)

    def test_mum_5_30(self):
        """
        FluidFlow: Вязкость смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.mum, 0.5705601462808292, places=5)

    def test_gf_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.gf, 0.39561159634256265, places=5)

    def test_wf_5_30(self):
        """
        FluidFlow: Доля воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.wf, 0.08412015890657222, places=5)

    def test_ro_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.ro, 678.9061776569056, places=5)

    def test_rw_5_30(self):
        """
        FluidFlow: Плотность воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rw, 994.9931612298373, places=5)

    def test_rg_5_30(self):
        """
        FluidFlow: Плотность газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rg, 37.68572893475321, places=5)

    def test_rl_5_30(self):
        """
        FluidFlow: Плотность жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rl, 705.4954649433597, places=5)

    def test_rm_5_30(self):
        """
        FluidFlow: Плотность смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rm, 441.3021892278896, places=5)

    def test_st_oilgas_5_30(self):
        """
        FluidFlow: Поверхностное натяжение нефть-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.stog, 0.013544931521528664, places=5)

    def test_st_watgas_5_30(self):
        """
        FluidFlow: Поверхностное натяжение вода-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.stwg, 0.0673496226226979, places=5)

    def test_st_liqgas_5_30(self):
        """
        FluidFlow: Поверхностное натяжение жидкость-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.stlg, 0.018070990686878053, places=5)

    def test_modify_rsb_p_5_30(self):
        """
        FluidFlow: Давление насыщения для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.pb, 7130386.316498398, places=5)

    def test_modify_rsb_value_5_30(self):
        """
        FluidFlow: Газосодержание при Pнас для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rs, 34.72995604142362, places=5)

    def test_modify_bob_value_5_30(self):
        """
        FluidFlow: Объемный коэффициент нефти при Pнас для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.bo_calibr_dict["value"],
            1.3309842067655304,
            places=5,
        )

    def test_modify_muob_value_5_30(self):
        """
        FluidFlow: Объемный коэффициент для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.muo_calibr_dict["value"],
            0.68488252387754,
            places=5,
        )

    def test_modify_rp_5_30(self):
        """
        FluidFlow: Газовый фактор для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow.rp, 53.26215800400451, places=5)

    def test_gas_fluid_qo_5_30(self):
        """
        FluidFlow: Дебит нефти для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.qo, 0, places=5)

    def test_gas_fluid_qw_5_30(self):
        """
        FluidFlow: Дебит воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.qw, 0, places=5)

    def test_gas_fluid_qg_5_30(self):
        """
        FluidFlow: Дебит газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.qg, 2.2204181732502896e-05, places=5)

    def test_gas_fluid_ql_5_30(self):
        """
        FluidFlow: Дебит жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.ql, 0, places=5)

    def test_gas_fluid_qm_5_30(self):
        """
        FluidFlow: Дебит смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.qm, 2.2204181732502896e-05, places=5)

    def test_gas_fluid_mul_5_30(self):
        """
        FluidFlow: Вязкость жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.mul, 0, places=5)

    def test_gas_fluid_mum_5_30(self):
        """
        FluidFlow: Вязкость смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.mum, 0.012101852555712622, places=5)

    def test_gas_fluid_gf_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.gf, 1, places=5)

    def test_gas_fluid_wf_5_30(self):
        """
        FluidFlow: Доля воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.wf, 0, places=5)

    def test_gas_fluid_ro_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.ro, 800.0, places=5)

    def test_gas_fluid_rw_5_30(self):
        """
        FluidFlow: Плотность воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.rw, 1000.0, places=5)

    def test_gas_fluid_rg_5_30(self):
        """
        FluidFlow: Плотность газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.rg, 37.685728934753236, places=5)

    def test_gas_fluid_rl_5_30(self):
        """
        FluidFlow: Плотность жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.rl, 820.0, places=5)

    def test_gas_fluid_rm_5_30(self):
        """
        FluidFlow: Плотность смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas.rm, 37.685728934753236, places=5)

    def test_gas_fluid_st_oilgas_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение нефть-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas.stog, 0)

    def test_gas_fluid_st_watgas_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение вода-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas.stwg, 0)

    def test_gas_fluid_st_liqgas_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение жидкость-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas.stlg, 0)

    def test_gas_fluid_q_zero_qo_5_30(self):
        """
        FluidFlow: Дебит нефти для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.qo, 0, places=5)

    def test_gas_fluid_q_zero_qw_5_30(self):
        """
        FluidFlow: Дебит воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.qw, 0, places=5)

    def test_gas_fluid_q_zero_qg_5_30(self):
        """
        FluidFlow: Дебит газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.qg, 0, places=5)

    def test_gas_fluid_q_zero_ql_5_30(self):
        """
        FluidFlow: Дебит жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.ql, 0, places=5)

    def test_gas_fluid_q_zero_qm_5_30(self):
        """
        FluidFlow: Дебит смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.qm, 0, places=5)

    def test_gas_fluid_q_zero_mul_5_30(self):
        """
        FluidFlow: Вязкость жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.mul, 0, places=5)

    def test_gas_fluid_q_zero_mum_5_30(self):
        """
        FluidFlow: Вязкость смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.mum, 0, places=5)

    def test_gas_fluid_q_zero_gf_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.gf, 0, places=5)

    def test_gas_fluid_q_zero_wf_5_30(self):
        """
        FluidFlow: Доля воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.wf, 0, places=5)

    def test_gas_fluid_q_zero_ro_5_30(self):
        """
        FluidFlow: Доля газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.ro, 800.0, places=5)

    def test_gas_fluid_q_zero_rw_5_30(self):
        """
        FluidFlow: Плотность воды для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.rw, 1000.0, places=5)

    def test_gas_fluid_q_zero_rg_5_30(self):
        """
        FluidFlow: Плотность газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(
            self.fluid_flow_gas_q_zero.rg, 37.685728934753236, places=5
        )

    def test_gas_fluid_q_zero_rl_5_30(self):
        """
        FluidFlow: Плотность жидкости для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(self.fluid_flow_gas_q_zero.rl, 820.0, places=5)

    def test_gas_fluid_q_zero_rm_5_30(self):
        """
        FluidFlow: Плотность смеси для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertAlmostEqual(
            self.fluid_flow_gas_q_zero.rm, 37.685728934753236, places=5
        )

    def test_gas_fluid_q_zero_stog_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение нефть-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas_q_zero.stog, 0)

    def test_gas_fluid_q_zero_stwg_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение вода-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas_q_zero.stwg, 0)

    def test_gas_fluid_q_zero_stlg_5_30(self):
        """
        FluidFlow: Поверхностное нятяжение жидкость-газ для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas_q_zero.calc_flow(p, t)
        self.assertEqual(self.fluid_flow_gas_q_zero.stlg, 0)

    def test_heat_capacity_mixture(self):
        """
        FluidFlow: удельная теплоемкость смеси при 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow.calc_flow(p, t)
        heat_capacity_mixture = self.fluid_flow.heat_capacity_mixture
        self.assertAlmostEqual(heat_capacity_mixture, 2297.984637443633, delta=0.01)

    def test_heat_capacity_mixture_only_gas(self):
        """
        FluidFlow: удельная теплоемкость смеси при 5 МПа и 303.15 К для случая,
        если задан только газ
        """
        p = 5 * 10 ** 6
        t = 303.15
        self.fluid_flow_gas.calc_flow(p, t)
        heat_capacity_mixture = self.fluid_flow_gas.heat_capacity_mixture
        self.assertAlmostEqual(heat_capacity_mixture, 2545.9220533376506, delta=0.01)

    def test_zero_annulus_modify(self):
        """
        FluidFlow: модификация флюида в затрубе когда давление модификации больше насыщения
        Проверка, что работает и не вылетает ошибка
        """
        pvt_model_data = {
            "black_oil": {
                "gamma_gas": self.gamma_gas,
                "gamma_wat": self.gamma_wat,
                "gamma_oil": self.gamma_oil,
                "rp": self.rp,
                "salinity": self.salinity,
                "oil_correlations": self.oil_correlations,
                "gas_correlations": self.gas_correlations,
                "water_correlations": self.water_correlations,
                "rsb": None,
                "muob": None,
                "bob": None,
                "table_model_data": None,
                "use_table_model": False,
            }
        }

        self.fluid_flow = fl.FluidFlow(self.qliq, self.wct, pvt_model_data)

        self.fluid_flow.modify(30132500, 300, 0.5, "annulus")
        self.fluid_flow.calc_flow(30132500, 300)

    def test_docstring_example(self):
        """
        Pipeline: проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[fl.FluidFlow.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(strs.FLUID_FLOW, example_string)

        # Инициализация исходных данных класса FluidFlow
        q_fluid = 100 / 86400
        wct = 0
        pvt_model_data = {
            "black_oil": {
                "gamma_gas": 0.7,
                "gamma_wat": 1,
                "gamma_oil": 0.8,
                "rp": 50,
                "oil_correlations": {
                    "pb": "Standing",
                    "rs": "Standing",
                    "rho": "Standing",
                    "b": "Standing",
                    "mu": "Beggs",
                    "compr": "Vasquez",
                },
                "gas_correlations": {
                    "ppc": "Standing",
                    "tpc": "Standing",
                    "z": "Dranchuk",
                    "mu": "Lee",
                },
                "water_correlations": {
                    "b": "McCain",
                    "compr": "Kriel",
                    "rho": "Standing",
                    "mu": "McCain",
                },
                "rsb": {"value": 50, "p": 10000000, "t": 303.15},
                "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                "table_model_data": None,
                "use_table_model": False,
            }
        }
        # Инициализация исходных данных метода расчета pvt-свойств флюидов
        p = 4 * (10 ** 6)
        t = 350
        # Инициализация объекта pvt-модели
        fluid_flow = fl.FluidFlow(q_fluid, wct, pvt_model_data)
        # Пересчет всех свойств для данного давления и температуры
        fluid_flow.calc_flow(p, t)
        # Вывод параметра вязкости жидкости
        mul = fluid_flow.mul

        self.assertAlmostEqual(mul, 0.4907733716564117, delta=1e-5)

    def test_reinit_fluid(self):
        """
        FluidFlow: Сброс флагов и калибровочных коэффициентов
        """
        p = 5 * 10 ** 6
        t = 303.15

        self.fluid_flow.calc_flow(p, t)

        self.assertAlmostEqual(self.fluid_flow.pvt_model.rp, 80, places=5)
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.calibr_rs, 0.9739801371117792, places=5
        )
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.rsb_calibr_dict["value"], 80, places=5
        )

        self.fluid_flow.modify(self.p_sep, self.t_sep, self.k_sep)
        self.fluid_flow.calc_flow(p, t)

        self.assertAlmostEqual(self.fluid_flow.pvt_model.rp, 53.26215800400451, places=5)
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.calibr_rs, 0.9746553893451817, places=5
        )
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.rsb_calibr_dict["value"],
            53.26215800400451,
            places=5,
        )

        self.fluid_flow.reinit()

        self.assertAlmostEqual(self.fluid_flow.pvt_model.rp, 80, places=5)
        self.assertAlmostEqual(self.fluid_flow.pvt_model.calibr_rs, 1, places=5)
        self.assertAlmostEqual(
            self.fluid_flow.pvt_model.rsb_calibr_dict["value"], 80, places=5
        )


# тестирование расчета вязкости жидкости/нефти по табличным значениям с помощью pytest
@pytest.fixture
def init_ff(p, t, wct):
    """
    FluidFlow: инициализация исходных данных
    """
    wct = wct
    p = p
    t = t
    q_fluid = 100 / 86400
    # Инициализация исходных данных метода расчета вязкости нефти и жидкости по табличным значениям
    dmuo = data.DT_MUO
    dfmuo = pd.DataFrame(dmuo)
    dmul = data.DT_MUL
    dfmul = pd.DataFrame(dmul)
    pvt_model_data = {
        "black_oil": {
            "gamma_gas": 0.7,
            "gamma_wat": 1,
            "gamma_oil": 0.8,
            "rp": 50,
            "oil_correlations": {
                "pb": "Standing",
                "rs": "Standing",
                "rho": "Standing",
                "b": "Standing",
                "mu": "Beggs",
                "compr": "Vasquez",
            },
            "gas_correlations": {
                "ppc": "Standing",
                "tpc": "Standing",
                "z": "Dranchuk",
                "mu": "Lee",
            },
            "water_correlations": {
                "b": "McCain",
                "compr": "Kriel",
                "rho": "Standing",
                "mu": "McCain",
            },
            "rsb": {"value": 50, "p": 10000000, "t": 303.15},
            "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
            "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
            "table_mu": {"mul": dfmul, "muo": dfmuo}
    }}

    # Инициализация исходных данных метода расчета pvt-свойств флюидов
    # Инициализация объекта pvt-модели
    fluid_flow = fl.FluidFlow(
        q_fluid,
        wct,
        pvt_model_data,
    )
    # Пересчет всех свойств для данного давления и температуры
    fluid_flow.calc_flow(p, t)
    return fluid_flow


testdata_muo = data.MUO_DATATABLE


@pytest.mark.parametrize("p,t, muo_fact, wct", testdata_muo)
def test_muo(init_ff, p, t, muo_fact, wct):
    """
    FluidFlow: расчет вязкости нефти по табличным значениям
    Проверка соответствия значений расчетной интерполяционной функции табличным значениям
    delta = 1.5 сП
    """
    muo_rasc = init_ff.muo
    assert muo_fact + 1.5 >= muo_rasc >= muo_fact - 1.5


testdata_mul = data.MUL_DATATABLE


@pytest.mark.parametrize("p ,t , wct, mul_fact", testdata_mul)
def test_mul(init_ff, p, t, mul_fact, wct):
    """
    FluidFlow: расчет вязкости жидкости по табличным значениям
    Проверка соответствия значений расчетной интерполяционной функции табличным значениям
    delta = 0.5%
    """
    mul_rasc = init_ff.mul
    delta = mul_fact / 100 * 0.5
    assert mul_fact + delta >= mul_rasc >= mul_fact - delta


testdata_muo2 = data.MUO_DATATABLE_EXCEL


@pytest.mark.parametrize("p,t,wct, muo_fact", testdata_muo2)
def test_muo2(init_ff, p, t, wct, muo_fact):
    """
    FluidFlow: расчет вязкости нефти по табличным значениям
    Проверка соответствия значений расчетной интерполяционной функции с аналитически рассчитанной функцией
    delta = 25% , !больше 10% около 10 кейсов из 80
    """
    muo_rasc = init_ff.muo
    delta = muo_rasc / 100 * 25
    assert muo_fact + delta >= muo_rasc >= muo_fact - delta


testdata_mul2 = data.MUL_DATATABLE1_EXCEL


@pytest.mark.parametrize("p ,t , wct, mul_fact", testdata_mul2)
def test_mul2(init_ff, p, t, mul_fact, wct):
    """
    FluidFlow: расчет вязкости жидкости по табличным значениям
    Проверка соответствия значений расчетной интерполяционной функции табличным значениям при p=1 Па
    delta = 26%
    """
    mul_rasc = init_ff.mul
    delta = mul_fact / 100 * 26
    assert mul_fact + delta >= mul_rasc >= mul_fact - delta


testdata_mul3 = data.MUL_DATATABLE2_EXCEL


@pytest.mark.parametrize("p, t, wct, mul_fact", testdata_mul3)
def test_mul3(init_ff, p, t, mul_fact, wct):
    """
    FluidFlow: расчет вязкости жидкости по табличным значениям
    Проверка соответствия значений расчетной интерполяционной функции табличным значениям при различных p
    delta = 30%
    """
    mul_rasc = init_ff.mul
    delta = mul_fact / 100 * 30
    assert mul_fact + delta >= mul_rasc >= mul_fact - delta


testdata_critical = data.FLUID_FLOW_CRITICAL


@pytest.mark.parametrize("p ,t , wct", testdata_critical)
def test_init_crit_value(init_ff, p, t, wct):
    """
    FluidFlow: расчет вязкости жидкости по табличным значениям
    Проверка выполнения расчета на значениях,больше граничных
    """
    muo = init_ff.muo
    mul = init_ff.mul
    assert muo > 0 and mul > 0


@pytest.mark.parametrize("p ,t , wct, mul_fact", testdata_mul3)
def test_mug(init_ff, p, t, wct, mul_fact):
    """
    FluidFlow: расчет вязкости газа после изменения во fluid_flow
    Проверка выполнения расчета
    """
    mug = init_ff.mug
    assert mug > 0


if __name__ == "__main__":
    unittest.main()
