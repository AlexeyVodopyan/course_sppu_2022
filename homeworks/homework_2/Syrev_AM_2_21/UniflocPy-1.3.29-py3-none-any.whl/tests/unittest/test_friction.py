import unittest
from numpy import NAN, isnan

from unifloc.pipe._friction import Friction


class TestFriction(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        self.d_m = 0.126
        self.friction_object = Friction(self.d_m)
        print(f"Test: {self.shortDescription()}")

    def test_n_re_1(self):
        """
        Friction: Число рейнольдса для mu = 1 сПз
        """
        rho_n = 500
        vsm_msec = 10
        mu_n_cp = 1
        self.assertEqual(
            self.friction_object.calc_n_re(rho_n, vsm_msec, mu_n_cp), 630000
        )

    def test_n_re_0(self):
        """
        Friction: Число рейнольдса для mu = 0 сПз
        """
        rho_n = 500
        vsm_msec = 10
        mu_n_cp = 0
        self.assertEqual(
            self.friction_object.calc_n_re(rho_n, vsm_msec, mu_n_cp), 630000000000
        )

    def test_n_re_nan(self):
        """
        Friction: Число рейнольдса для NaN
        """
        rho_n = NAN
        vsm_msec = NAN
        mu_n_cp = NAN
        self.assertTrue(isnan(self.friction_object.calc_n_re(rho_n, vsm_msec, mu_n_cp)))

    def test_norm_friction_factor_laminar(self):
        """
        Friction: Коэффициент однофазного трения Moody, ламинарный режим
        """
        n_re = 100
        eps = 0.0001
        rough_pipe = 1
        self.assertEqual(
            self.friction_object.calc_norm_ff(n_re, eps, rough_pipe), 0.64
        )

    def test_norm_friction_factor_transient(self):
        """
        Friction: Коэффициент однофазного трения Moody, переходный режим
        """
        n_re = 3000
        eps = 0.0001
        rough_pipe = 1
        self.assertAlmostEqual(
            self.friction_object.calc_norm_ff(n_re, eps, rough_pipe),
            0.036033614601047925,
            places=5,
        )

    def test_norm_friction_factor_turbulent_moody(self):
        """
        Friction: Коэффициент однофазного трения Moody (шероховатые трубы), турбулентный режим
        """
        n_re = 10000
        eps = 0.0001
        rough_pipe = 1
        self.assertAlmostEqual(
            self.friction_object.calc_norm_ff(n_re, eps, rough_pipe),
            0.031077556377034216,
            places=5,
        )

    def test_norm_friction_factor_turbulent_drew(self):
        """
        Friction: Коэффициент однофазного трения Drew (гладкие трубы), турбулентный режим
        """
        n_re = 10000
        eps = 0.0001
        rough_pipe = 0
        self.assertAlmostEqual(
            self.friction_object.calc_norm_ff(n_re, eps, rough_pipe),
            0.031840373012488626,
            places=5,
        )

    def test_norm_friction_factor_nan(self):
        """
        Friction: Коэффициент однофазного трения для NaN
        """
        n_re = NAN
        eps = NAN
        rough_pipe = NAN
        self.assertTrue(
            isnan(self.friction_object.calc_norm_ff(n_re, eps, rough_pipe))
        )


if __name__ == "__main__":
    unittest.main()
