import pytest

import unifloc.pipe._hasankabir as hk

# тестирование корреляции HasanKabir с помощью pytest
@pytest.fixture
def init_hk(
    d,
    d_casing,
    theta_deg: float,
    ql_rc_m3day: float,
    qg_rc_m3day: float,
    mul_rc_cp: float,
    mug_rc_cp: float,
    rho_lrc_kgm3: float,
    rho_grc_kgm3: float,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    Инициализация класса для тестирования
    """
    c_calibr_grav = 1
    c_calibr_fric = 1
    h_mes = 0
    h_mes_prev = 0
    vgas_prev = None
    rho_gas_prev = None
    calc_dp_dl_acc = True
    eps_m = 2.54 * 10 ** (-5)
    sigma_l_nm = 5.16443138806286e-02
    hasankabir = hk.HasanKabir(d, d_casing)
    hasankabir.calc_grad(
        theta_deg=theta_deg,
        eps_m=eps_m,
        ql_rc_m3day=ql_rc_m3day,
        qg_rc_m3day=qg_rc_m3day,
        mul_rc_cp=mul_rc_cp,
        mug_rc_cp=mug_rc_cp,
        sigma_l_nm=sigma_l_nm,
        rho_lrc_kgm3=rho_lrc_kgm3,
        rho_grc_kgm3=rho_grc_kgm3,
        c_calibr_grav=c_calibr_grav,
        c_calibr_fric=c_calibr_fric,
        h_mes=h_mes,
        flow_direction=flow_direction,
        vgas_prev=vgas_prev,
        rho_gas_prev=rho_gas_prev,
        h_mes_prev=h_mes_prev,
        # calc_dp_dl_acc=calc_dp_dl_acc,
        rho_mix_rc_kgm3=rho_mix_rc_kgm3,
        p=0,
    )
    return hasankabir


testdata_hk = [
    (0.126, 0.140, 90, 20 / 86400, 2000 / 86400, 1, 0.01, 800, 20, 1, 8.118811881188119,),
    (0.126, 0.140, 90, 0, 0, 1, 0.01, 800, 20, 1, 0),
    (0.06, 0.08, 90, 10 / 86400, 10000 / 86400, 1, 0.01, 800, 20, 1, 0.8191808191808185,),
    (0.08, 0.14, 90, 100 / 86400, 200 / 86400, 1, 0.01, 800, 20, -1, 273.3333333333333),
    (0.07, 0.156, 90, 300 / 86400, 600 / 86400, 1, 0.01, 800, 20, 1, 273.3333333333333),
]


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_dpdl(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Расчет суммарного градиента давления для различных исходных данных
    """

    assert init_hk.dp_dl is not None


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_dpdlgr(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Расчет градиента давления на гравитацию для различных исходных данных
    """

    assert init_hk.dp_dl_gr is not None


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_dpdlfr(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Расчет градиента давления на трение для различных исходных данных
    """

    assert init_hk.dp_dl_fr is not None


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_dpdlacc(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Расчет градиента давления на ускорение для различных исходных данных
    """

    assert init_hk.dp_dl_acc is not None


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_fp(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Проверка определения режима потока для различных исходных данных
    """
    assert init_hk.fp == 0 or 1 or 2 or 3 or 4


@pytest.mark.parametrize(
    "d, d_casing, theta_deg,ql_rc_m3day, qg_rc_m3day, mul_rc_cp, mug_rc_cp, rho_lrc_kgm3,rho_grc_kgm3,flow_direction, rho_mix_rc_kgm3",
    testdata_hk,
)
def test_hk_vdt(
    init_hk,
    d,
    d_casing,
    theta_deg,
    ql_rc_m3day,
    qg_rc_m3day,
    mul_rc_cp,
    mug_rc_cp,
    rho_lrc_kgm3,
    rho_grc_kgm3,
    flow_direction,
    rho_mix_rc_kgm3,
):
    """
    HasanKabir: Проверка расчета скорости пузырька Тейлора для различных исходных данных
    """
    assert init_hk.v_dt_msec is not None
