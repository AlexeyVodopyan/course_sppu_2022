import unittest

from unifloc.common.ambient_temperature_distribution import AmbientTemperatureDistribution
from unifloc.tools.exceptions import UniflocPyError


class TestWellTrajectory(unittest.TestCase):
    def setUp(self) -> None:
        self.md = [0, 1000]
        self.tvd = [0, 900]
        print(f"Test: {self.shortDescription()}")

    def test_set_no_t(self):
        """
        AmbientTemperatureDistribution: проверка задания без T
        """
        amb_temp_data = {"MD": [0, 1800]}
        with self.assertRaises(UniflocPyError):
            amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)

    def test_set_no_md(self):
        """
        AmbientTemperatureDistribution: проверка задания без MD
        """
        amb_temp_data = {"T": [273.15, 273.15]}
        with self.assertRaises(UniflocPyError):
            amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)

    def test_set_dif_len(self):
        """
        AmbientTemperatureDistribution: проверка задания разной длины MD и T
        """
        amb_temp_data = {"T": [273.15, 273.15], "MD": [0, 1200, 1800]}
        with self.assertRaises(UniflocPyError):
            amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)

    def test_set_with_duplicates(self):
        """
        AmbientTemperatureDistribution: проверка задания MD с дубликатами
        """
        amb_temp_data = {"T": [273.15, 273.15, 273.15], "MD": [0, 1800, 1800]}
        with self.assertRaises(UniflocPyError):
            amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)

    def test_calc_temp(self):
        """
        AmbientTemperatureDistribution: расчет температуры
        """
        amb_temp_data = {"T": [273.15, 273.15], "MD": [0, 1800]}
        amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)
        t = amb_temp_dist.calc_temp(1200)
        self.assertEqual(t, 273.15)

    def test_calc_geograd(self):
        """
        AmbientTemperatureDistribution: расчет геотермического градиента
        """
        amb_temp_data = {"T": [273.15, 273.15], "MD": [0, 1800]}
        amb_temp_dist = AmbientTemperatureDistribution(amb_temp_data)
        t = amb_temp_dist.calc_geotemp_grad(1200)
        self.assertEqual(t, 0)
