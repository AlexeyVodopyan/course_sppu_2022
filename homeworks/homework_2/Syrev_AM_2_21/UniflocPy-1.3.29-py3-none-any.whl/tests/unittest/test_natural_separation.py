import ast
import os
import sys
import unittest

from unifloc.equipment.natural_separation import NaturalSeparation
from tests.unittest.example_strings import NATSEP


class TestNaturalSeparation(unittest.TestCase):
    def setUp(self) -> None:
        self.nat_sep = NaturalSeparation(100)
        print(self.shortDescription())

    def test_separation(self):
        """
        NaturalSeparation: расчет естественной сепарации
        """
        d_tub = 0.062
        d_cas = 0.092
        q_liq = 100 / 86400
        q_gas = 1000 / 86400
        sigma_l = 0.001
        rho_liq = 900
        rho_gas = 100
        self.assertAlmostEqual(
            0.29926989255626646,
            self.nat_sep.calc_separation(
                d_tub, d_cas, q_liq, q_gas, sigma_l, rho_liq, rho_gas
            ),
            delta=0.001,
        )

    def test_separation_q_0(self):
        """
        NaturalSeparation: расчет естественной сепарации для нулевого дебита жидкости
        """
        d_tub = 0.062
        d_cas = 0.092
        q_liq = 0
        q_gas = 1000 / 86400
        sigma_l = 0.001
        rho_liq = 900
        rho_gas = 100
        self.assertEqual(
            1,
            self.nat_sep.calc_separation(
                d_tub, d_cas, q_liq, q_gas, sigma_l, rho_liq, rho_gas
            ),
        )

    def test_docstring_example(self):
        """
        NaturalSeparation: проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[NaturalSeparation.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)

        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )
        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(NATSEP, example_string)

        # Инициализация исходных данных
        h_mes_ = 1800
        d_tub = 0.063
        d_cas = 0.130
        q_fluid = 100 / 86400
        q_gas = 0
        sigma_l = 24
        rho_liq = 836
        rho_gas = 0.84

        # Инициализация объекта для расчета естественной сепарации
        k_sep_nat_calc = NaturalSeparation(h_mes_)
        # Расчет коэффициента естественной сепарации
        k_sep_natural = k_sep_nat_calc.calc_separation(
            d_tub, d_cas, q_fluid, q_gas, sigma_l, rho_liq, rho_gas
        )

        self.assertEqual(k_sep_natural, 0.913247182049692)


if __name__ == "__main__":
    unittest.main()
