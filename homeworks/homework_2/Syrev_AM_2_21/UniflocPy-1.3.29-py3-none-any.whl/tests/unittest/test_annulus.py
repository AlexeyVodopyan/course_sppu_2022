import ast
import os
import sys
import unittest

import pandas as pd

from unifloc.pipe.annulus import Annulus
from unifloc.pvt.fluid_flow import FluidFlow
from unifloc.common.trajectory import Trajectory
from unifloc.common.ambient_temperature_distribution import AmbientTemperatureDistribution
from tests.unittest.example_strings import ANNULUS


class TestAnnulus(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов

        Returns
        -------

        """
        self.p_sep = 4 * 101325
        self.t_sep = 303.15
        self.k_sep = 0.5

        self.fluid_data_1 = {
            "q_fluid": 0,
            "wct": 0.98,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 0,
                    "rsb": {"value": 100, "p": 20000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 20000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 20000000, "t": 303.15},
                }
            },
        }
        self.fluid_data_2 = {
            "q_fluid": 0,
            "wct": 0,
            "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 0,}},
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d_tub_1 = 0.062
        d_tub_2 = {"MD": [0, 500, 1000, 2000], "d": [0.062, 0.066, 0.07, 0.071]}
        d_tub_3 = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [2000, 0.071]])

        d_cas_1 = 0.146
        d_cas_2 = {
            "MD": [0, 300, 1000, 2200, 2500],
            "d": [0.1, 0.095, 0.13, 0.098, 0.12],
        }
        d_cas_3 = pd.DataFrame(columns=["MD", "d"], data=[[1800, 0.1], [2200, 0.098], [2500, 0.12]])

        self.pipe_data_1 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_1, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_1, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.pipe_data_2 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_2, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_2, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.pipe_data_3 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_3, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_3, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.pipe_data_4 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_1, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_2, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.pipe_data_5 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_3, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_1, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.pipe_data_6 = {
            "casing": {"bottom_depth": 2500, "d": d_cas_2, "roughness": 0.0001},
            "tubing": {"bottom_depth": 2000, "d": d_tub_3, "roughness": 0.0001, "s_wall": 0.005,},
        }

        self.trajectory = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [2000, 2000], [2500, 2500]])
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        self.ambient_temperature_distribution = AmbientTemperatureDistribution(self.ambient_temperature_data)
        self.well_trajectory = Trajectory(**self.well_trajectory_data)

        print(self.shortDescription())

    def test_annulus_fluid_1_d_1(self):
        """
        Annulus: Расчет динамического уровня для набора данных флюида 1

        Returns
        -------

        """
        p_esp = 150 * 101325
        t_esp = 303.15
        p_ann = 20 * 101325
        t_ann = 303.15

        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_1["tubing"]["bottom_depth"],
            self.pipe_data_1["casing"]["d"],
            self.pipe_data_1["tubing"]["d"],
            self.pipe_data_1["tubing"]["s_wall"],
            self.pipe_data_1["casing"]["roughness"],
            self.well_trajectory,
        )
        results = self.annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, self.fluid_data_1["wct"],)
        self.assertAlmostEqual(
            results[0], 657.4139566349206, places=2,
        )
        self.assertAlmostEqual(
            results[1], 2138619.903026203, places=2,
        )

    def test_annulus_p_ann_greater_p_esp(self):
        """
        Annulus: Расчет динамического уровня для случая затрубное давление больше давления на приеме

        Returns
        -------

        """
        p_esp = 10 * 101325
        t_esp = 303.15
        p_ann = 20 * 101325
        t_ann = 303.15

        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_1["tubing"]["bottom_depth"],
            self.pipe_data_1["casing"]["d"],
            self.pipe_data_1["tubing"]["d"],
            self.pipe_data_1["tubing"]["s_wall"],
            self.pipe_data_1["casing"]["roughness"],
            self.well_trajectory,
        )
        results = self.annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, self.fluid_data_1["wct"])
        self.assertAlmostEqual(
            results[0], 2000, places=2,
        )
        self.assertAlmostEqual(
            results[1], 2388538.878240615, places=2,
        )

    def test_annulus_p_esp_greater_p_ann(self):
        """
        Annulus: Расчет динамического уровня для случая давление на приеме больше затрубного давления

        Returns
        -------

        """
        p_esp = 300 * 101325
        t_esp = 303.15
        p_ann = 20 * 101325
        t_ann = 303.15

        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_1["tubing"]["bottom_depth"],
            self.pipe_data_1["casing"]["d"],
            self.pipe_data_1["tubing"]["d"],
            self.pipe_data_1["tubing"]["s_wall"],
            self.pipe_data_1["casing"]["roughness"],
            self.well_trajectory,
        )
        results = self.annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, self.fluid_data_1["wct"])

        self.assertAlmostEqual(
            results[0], 0, places=2,
        )

        self.assertAlmostEqual(
            results[1], 10887859.16893746, places=2,
        )

    def test_annulus_fluid_2_d_1(self):
        """
        Annulus: Расчет динамического уровня для набора данных флюида 2

        Returns
        -------

        """
        p_esp = 150 * 101325
        t_esp = 303.15
        p_ann = 20 * 101325
        t_ann = 303.15

        self.fluid = FluidFlow(**self.fluid_data_2)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_1["tubing"]["bottom_depth"],
            self.pipe_data_1["casing"]["d"],
            self.pipe_data_1["tubing"]["d"],
            self.pipe_data_1["tubing"]["s_wall"],
            self.pipe_data_1["casing"]["roughness"],
            self.well_trajectory,
        )
        results = self.annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, self.fluid_data_2["wct"])
        self.assertAlmostEqual(results[0], 319.50145071427596, places=2)
        self.assertAlmostEqual(results[1], 2080192.4626913616, places=2)

    def test_annulus_d_2(self):
        """
        Annulus: Расчет диаметра затрубного пространства для набора данных pipedata_2

        Returns
        -------

        """
        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_2["tubing"]["bottom_depth"],
            self.pipe_data_2["casing"]["d"],
            self.pipe_data_2["tubing"]["d"],
            self.pipe_data_2["tubing"]["s_wall"],
            self.pipe_data_2["casing"]["roughness"],
            self.well_trajectory,
        )

        self.assertCountEqual(
            self.annulus.d_annulus["d"],
            [
                0.02800000000000001,
                0.023000000000000007,
                0.019000000000000003,
                0.05,
                0.049000000000000016,
            ],
        )
        self.assertCountEqual(self.annulus.d_annulus["MD"], [0, 300, 500, 1000, 2000])

    def test_annulus_d_3(self):
        """
        Annulus: Расчет диаметра затрубного пространства для набора данных pipedata_3

        Returns
        -------

        """
        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_3["tubing"]["bottom_depth"],
            self.pipe_data_3["casing"]["d"],
            self.pipe_data_3["tubing"]["d"],
            self.pipe_data_3["tubing"]["s_wall"],
            self.pipe_data_3["casing"]["roughness"],
            self.well_trajectory,
        )

        self.assertCountEqual(
            self.annulus.d_annulus["d"],
            [0.02800000000000001, 0.02800000000000001, 0.019000000000000017],
        )
        self.assertCountEqual(self.annulus.d_annulus["MD"], [0, 1800, 2000])

    def test_annulus_d_4(self):
        """
        Annulus: Расчет диаметра затрубного пространства для набора данных pipedata_4

        Returns
        -------

        """
        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_4["tubing"]["bottom_depth"],
            self.pipe_data_4["casing"]["d"],
            self.pipe_data_4["tubing"]["d"],
            self.pipe_data_4["tubing"]["s_wall"],
            self.pipe_data_4["casing"]["roughness"],
            self.well_trajectory,
        )

        self.assertCountEqual(
            self.annulus.d_annulus["d"],
            [0.074, 0.06999999999999999, 0.06599999999999999, 0.065],
        )
        self.assertCountEqual(self.annulus.d_annulus["MD"], [0, 500, 1000, 2000])

    def test_annulus_d_5(self):
        """
        Annulus: Расчет диаметра затрубного пространства для набора данных pipedata_5

        Returns
        -------

        """
        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_5["tubing"]["bottom_depth"],
            self.pipe_data_5["casing"]["d"],
            self.pipe_data_5["tubing"]["d"],
            self.pipe_data_5["tubing"]["s_wall"],
            self.pipe_data_5["casing"]["roughness"],
            self.well_trajectory,
        )

        self.assertCountEqual(
            self.annulus.d_annulus["d"],
            [0.02800000000000001, 0.02800000000000001, 0.02800000000000001],
        )
        self.assertCountEqual(self.annulus.d_annulus["MD"], [0, 1800, 2000])

    def test_annulus_d_6(self):
        """
        Annulus: Расчет диаметра затрубного пространства для набора данных pipedata_6

        Returns
        -------

        """
        self.fluid = FluidFlow(**self.fluid_data_1)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.annulus = Annulus(
            self.fluid,
            self.ambient_temperature_distribution,
            self.pipe_data_6["tubing"]["bottom_depth"],
            self.pipe_data_6["casing"]["d"],
            self.pipe_data_6["tubing"]["d"],
            self.pipe_data_6["tubing"]["s_wall"],
            self.pipe_data_6["casing"]["roughness"],
            self.well_trajectory,
        )

        self.assertCountEqual(
            self.annulus.d_annulus["d"],
            [
                0.02800000000000001,
                0.023000000000000007,
                0.05800000000000001,
                0.049000000000000016,
            ],
        )
        self.assertCountEqual(self.annulus.d_annulus["MD"], [0, 300, 1000, 2000])

    def test_docstring_example(self):
        """
        Annulus: Проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[Annulus.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [node for node in module.body if isinstance(node, ast.ClassDef)]

        doc_string = ast.get_docstring(
            [node for node in class_definitions[0].body if isinstance(node, ast.FunctionDef)][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(ANNULUS, example_string)

        import pandas as pd
        import unifloc.pvt.fluid_flow as fl
        import unifloc.common.trajectory as traj
        import unifloc.common.ambient_temperature_distribution as amb
        import unifloc.pipe.annulus as ann

        # Инициализация исходных данных класса FluidFlow
        q_fluid = 100 / 86400
        wct = 0
        pvt_model_data = {
            "black_oil": {
                "gamma_gas": 0.7,
                "gamma_wat": 1,
                "gamma_oil": 0.8,
                "rp": 50,
                "oil_correlations": {
                    "pb": "Standing",
                    "rs": "Standing",
                    "rho": "Standing",
                    "b": "Standing",
                    "mu": "Beggs",
                    "compr": "Vasquez",
                },
                "gas_correlations": {"ppc": "Standing", "tpc": "Standing", "z": "Dranchuk", "mu": "Lee",},
                "water_correlations": {"b": "McCain", "compr": "Kriel", "rho": "Standing", "mu": "McCain",},
                "rsb": {"value": 50, "p": 10000000, "t": 303.15},
                "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                "table_model_data": None,
                "use_table_model": False,
            }
        }
        # Инициализация исходных данных класса WellTrajectory
        trajectory = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [2000, 2000], [2500, 2500]])
        well_trajectory_data = {"inclinometry": trajectory}
        well_trajectory = traj.Trajectory(**well_trajectory_data)
        # Задание параметров сепарации
        p_sep = 4 * (10 ** 6)
        t_sep = 303.15
        k_sep = 0.5
        # Создание объекта флюида
        fluid = fl.FluidFlow(q_fluid, wct, pvt_model_data)
        # Модификация флюида
        fluid.modify(p_sep, t_sep, k_sep, calc_type="annulus")
        bottom_depth = 2000
        d_casing = 0.146
        d_tubing = 0.062
        s_wall = 0.005
        roughness = 0.0001
        # Создание объекта с температурой породы
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        # Создание объекта затрубного пространства
        annulus = ann.Annulus(
            fluid, amb_temp, bottom_depth, d_casing, d_tubing, s_wall, roughness, well_trajectory,
        )
        # Инициализация исходных данных метода расчета динамического уровня calc_hdyn
        p_esp = 150 * 101325
        t_esp = 303.15
        p_ann = 20 * 101325
        t_ann = 303.15
        # Вызов метода расчета динамического уровня
        h_dyn, p_dyn = annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, wct)
        self.assertAlmostEqual(87.35601875034558, h_dyn, delta=0.01)
        self.assertAlmostEqual(2041112.9782812826, p_dyn, delta=0.01)


def init_an(d_casing, d_tubing, h_start, flow_direction, extra_output, p_wh: float = 20 * 101325):
    """
    Инициализация класса для тестирования
    """
    d_casing = d_casing
    d_tubing = d_tubing
    h_start = h_start
    flow_direction = flow_direction
    q_fluid = 100 / 86400
    wct = 0
    pvt_model_data = {
        "black_oil": {
            "gamma_gas": 0.7,
            "gamma_wat": 1,
            "gamma_oil": 0.8,
            "rp": 50,
            "oil_correlations": {
                "pb": "Standing",
                "rs": "Standing",
                "rho": "Standing",
                "b": "Standing",
                "mu": "Beggs",
                "compr": "Vasquez",
            },
            "gas_correlations": {"ppc": "Standing", "tpc": "Standing", "z": "Dranchuk", "mu": "Lee",},
            "water_correlations": {"b": "McCain", "compr": "Kriel", "rho": "Standing", "mu": "McCain",},
            "rsb": {"value": 50, "p": 10000000, "t": 303.15},
            "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
            "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
            "table_model_data": None,
            "use_table_model": False,
        }
    }
    # Инициализация исходных данных класса WellTrajectory
    trajectory = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [2000, 2000], [2500, 2500]])
    well_trajectory_data = {"inclinometry": trajectory}
    well_trajectory = Trajectory(**well_trajectory_data)
    # Задание параметров сепарации
    p_sep = 4 * (10 ** 6)
    t_sep = 303.15
    k_sep = 0.5
    # Создание объекта флюида
    fluid = FluidFlow(q_fluid, wct, pvt_model_data)
    # Модификация флюида
    fluid.modify(p_sep, t_sep, k_sep, calc_type="annulus")
    bottom_depth = 2000

    s_wall = 0.005
    roughness = 0.0001
    # Создание объекта с температурой породы
    ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
    amb_temp = AmbientTemperatureDistribution(ambient_temperature_data)
    # Создание объекта затрубного пространства
    annulus = Annulus(fluid, amb_temp, bottom_depth, d_casing, d_tubing, s_wall, roughness, well_trajectory,)
    # Инициализация исходных данных метода расчета динамического уровня calc_pt_an
    p_wh = p_wh

    # Вызов метода расчета динамического уровня
    p_rasc = annulus.calc_pt(
        h_start=h_start,
        p_mes=p_wh,
        flow_direction=flow_direction,
        heat_balance=False,
        q_liq=q_fluid,
        rp=100,
        extra_output=extra_output,
        hydr_corr_type="hasankabir",
    )
    return p_rasc, annulus


def test_ann_fd_1():
    """
    Annulus: d_casing = 0.146, d_tubing = 0.062, расчет вниз, поток вверх
    """
    d_casing = 0.146
    d_tubing = 0.062
    h_start = "top"
    flow_direction = 1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert 6194038.9976318525 - 9000 <= p <= 6194038.9976318525 + 9000


def test_ann_fd_2():
    """
    Annulus: d_casing = 0.146, d_tubing = 0.062,  расчет вниз, поток вниз
    """
    d_casing = 0.146
    d_tubing = 0.062
    h_start = "top"
    flow_direction = -1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert 6071851.948701027 - 9000 <= p <= 6071851.948701027 + 9000


def test_ann_fd_3():
    """
    Annulus: d_casing = 0.146, d_tubing = 0.062, расчет вверх, поток вверх
    """
    d_casing = 0.146
    d_tubing = 0.062
    h_start = "bottom"
    flow_direction = -1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert 90000 - 9000 <= p <= 90000 + 9000


def test_ann_fd_4():
    """
    Annulus: d_casing = 0.146, d_tubing = 0.062, расчет вверх, поток вниз
    """
    d_casing = 0.146
    d_tubing = 0.062
    h_start = "bottom"
    flow_direction = 1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert 240179.30192830172 - 9000 <= p <= 240179.30192830172 + 9000


def test_ann_2():
    """
    Annulus: Запрос доп.параметров расчета
    """
    d_casing = 0.146
    d_tubing = 0.062
    h_start = "bottom"
    flow_direction = 1
    an = init_an(d_casing, d_tubing, h_start, flow_direction, True)[1]
    assert len(an.distributions) == 46


def test_ann_d_1():
    """
    Annulus: Непостоянный диаметр, заданный с помощью DataFrame
    """

    d_casing = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.10], [1000, 0.14]])
    d_tubing = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.06], [1000, 0.08]])
    h_start = "bottom"
    flow_direction = 1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert p == 1236753.2733124683


def test_ann_d_2():
    """
    Annulus: Непостоянный диаметр, заданный с помощью словаря
    """
    d_casing = {"MD": [0, 1000], "d": [0.10, 0.14]}
    d_tubing = {"MD": [0, 1000], "d": [0.06, 0.08]}
    h_start = "bottom"
    flow_direction = 1
    p = init_an(d_casing, d_tubing, h_start, flow_direction, None)[0][0]
    assert 1236753.2733124683 - 9000 <= p <= 1236753.2733124683 + 9000


def test_ann_ff():
    """
    Annulus: Тестирование совпадения результатов при расчете в разные стороны
    """
    d_casing = 0.146
    d_tubing = 0.062
    p_start = 20 * 101325
    p_bottom = init_an(d_casing, d_tubing, "top", -1, None, p_start)[0][0]
    p_top = init_an(d_casing, d_tubing, "bottom", -1, None, p_bottom)[0][0]
    assert p_top - p_start/20 <= p_start <= p_top + p_start/20


def test_ann_multi():
    """
    Annulus: Тестирование совпадения расчетов при вызове 3 раза
    """

    d_casing = 0.146
    d_tubing = 0.062
    p1 = init_an(d_casing, d_tubing, "top", 1, None)[0][0]
    p2 = init_an(d_casing, d_tubing, "top", 1, None)[0][0]
    p3 = init_an(d_casing, d_tubing, "top", 1, None)[0][0]
    assert p1 == p2 == p3


if __name__ == "__main__":
    unittest.main()