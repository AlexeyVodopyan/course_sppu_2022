import unittest
from numpy import NAN, isnan

from unifloc.pvt._gas_correlations import GasCorrelations
from unifloc.tools.exceptions import NotImplementedPvtCorrError
from unifloc.service._constants import GAS_CORRS


class TestGasCorrelations(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        print(f"Test: {self.shortDescription()}")
        self.gamma_gas = 0.6
        gas_correlations = GAS_CORRS.copy()
        self.gas_correlations = GasCorrelations(gas_correlations)

    def test_z_kareem_5_30(self):
        """
        GasCorrs: Z-фактор по корреляции Kareem для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        gas_correlations = GAS_CORRS.copy()
        gas_correlations["z"] = "kareem"
        self.gas_correlations = GasCorrelations(gas_correlations)
        self.assertAlmostEqual(
            self.gas_correlations.calc_z(p, t, self.gamma_gas),
            0.9016888098776518,
            places=5,
        )

    def test_z_dranchuk_5_30(self):
        """
        GasCorrs: Z-фактор по корреляции Dranchuk для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        gas_correlations = GAS_CORRS.copy()
        gas_correlations["z"] = "dranchuk"
        self.gas_correlations = GasCorrelations(gas_correlations)
        self.assertAlmostEqual(
            self.gas_correlations.calc_z(p, t, self.gamma_gas),
            0.9015831801406884,
            places=5,
        )

    def test_bg_5_30(self):
        """
        GasCorrs: Объемный коэффициент газа для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        z = 0.9
        self.assertAlmostEqual(
            self.gas_correlations.calc_gas_fvf(p, t, z), 0.019150725185999997, places=5
        )

    def test_rho_gas_002(self):
        """
        GasCorrs: Плотность газа для bg = 0.02
        """
        bg = 0.02
        self.assertAlmostEqual(
            self.gas_correlations.calc_gas_density(self.gamma_gas, bg),
            36.148929436329276,
            places=5,
        )

    def test_mug_lee_30(self):
        """
        GasCorrs: Вязкость газа для 303.15 К по корреляции Lee
        """
        t = 303.15
        rho_gas = 35
        gas_correlations = GAS_CORRS.copy()
        gas_correlations["mu"] = "lee"
        self.gas_correlations = GasCorrelations(gas_correlations)
        self.assertAlmostEqual(
            self.gas_correlations.calc_gas_viscosity(t, self.gamma_gas, rho_gas),
            0.012018407692200764,
            places=5,
        )

    def test_mug_not_implemented_error(self):
        """
        GasCorrs: Вязкость газа для корреляции LaLaLand
        """
        gas_correlations = GAS_CORRS.copy()
        correlation = "LaLaLand"
        gas_correlations["mu"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.gas_correlations = GasCorrelations(gas_correlations)

    def test_z_not_implemented_error(self):
        """
        GasCorrs: Z-фактор для нереализованной корреляции LaLaLand
        """
        gas_correlations = GAS_CORRS.copy()
        correlation = "LaLaLand"
        gas_correlations["z"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.gas_correlations = GasCorrelations(gas_correlations)

    def test_ppc_not_implemented_error(self):
        """
        GasCorrs: Ppc для нереализованной корреляции LaLaLand
        """
        gas_correlations = GAS_CORRS.copy()
        correlation = "LaLaLand"
        gas_correlations["ppc"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.gas_correlations = GasCorrelations(
                {"ppc": correlation, "tpc": "standing", "z": "kareem", "mu": "lee"}
            )

    def test_tpc_not_implemented_error(self):
        """
        GasCorrs: Tpc для нереализованной корреляции LaLaLand
        """
        gas_correlations = GAS_CORRS.copy()
        correlation = "LaLaLand"
        gas_correlations["tpc"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.gas_correlations = GasCorrelations(
                {"ppc": "standing", "tpc": correlation, "z": "kareem", "mu": "lee"}
            )

    def test_bg_nan(self):
        """
        GasCorrs: Объемный коэффициент газа для NaN
        """
        p = NAN
        t = NAN
        z = NAN
        self.assertTrue(isnan(self.gas_correlations.calc_gas_fvf(p, t, z)))

    def test_mug_nan(self):
        """
        GasCorrs: Вязкость газа для NaN
        """
        t = NAN
        rho_gas = NAN
        self.assertTrue(
            isnan(self.gas_correlations.calc_gas_viscosity(t, self.gamma_gas, rho_gas))
        )

    def test_rho_gas_nan(self):
        """
        GasCorrs: Плотность газа для NaN
        """
        bg = NAN
        self.assertTrue(
            isnan(self.gas_correlations.calc_gas_density(self.gamma_gas, bg))
        )

    def test_exception_detail(self):
        """
        GasCorrs: Z-фактор тестирование сохранения нереализованной корреляции LaLaLand в контекст ошибки
        """
        gas_correlations = GAS_CORRS.copy()
        correlation = "LaLaLand"
        gas_correlations["z"] = correlation
        try:
            self.gas_correlations = GasCorrelations(
                {"ppc": "standing", "tpc": "standing", "z": correlation, "mu": "lee"}
            )
        except NotImplementedPvtCorrError as e:
            print(e.detail)
            self.assertEqual(e.detail, correlation)

    def test_z_newton(self):
        """
        GasCorrs: Z-фактор по корреляции Dranchuk для 270 МПа и 303.15 К
        """
        p = 270 * 10 ** 6
        t = 303.15
        gas_correlations = GAS_CORRS.copy()
        gas_correlations["z"] = "dranchuk"
        self.gas_correlations = GasCorrelations(gas_correlations)
        self.assertAlmostEqual(
            self.gas_correlations.calc_z(p, t, self.gamma_gas),
            4.250175765265038,
            places=5,
        )

    def test_z_standing(self):
        """
        GasCorrs: Z-фактор по корреляции Standing для 270 МПа и 303.15 К
        """
        p = 270 * 10 ** 6
        t = 303.15
        gas_correlations = GAS_CORRS.copy()
        gas_correlations["z"] = "standing"
        self.gas_correlations = GasCorrelations(gas_correlations)
        self.assertAlmostEqual(
            self.gas_correlations.calc_z(p, t, self.gamma_gas),
            4.244476971854596,
            places=5,
        )


if __name__ == "__main__":
    unittest.main()
