import ast
import copy
import json
import os
import sys
import unittest

import pandas as pd
import numpy.testing as npt

import tests.unittest.example_strings as exs
import unifloc.service._constants as const
import unifloc.tools.exceptions as exc
import unifloc.tools.units_converter as uc
import unifloc.well.esp_well as esw


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.fluid_data = {
            "q_fluid": 100 / 86400,
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 60,
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        self.d = {"MD": [0, 1000], "d": [0.062, 0.082]}
        self.pipe_data = {
            "casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
            "tubing": {
                "bottom_depth": 1400,
                "d": self.d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        self.trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.esp_data = {
            "ID": 737,
            "source": "UniflocVBA",
            "manufacturer": "Новомет",
            "name": "ВНН5-125",
            "stages_max": 517,
            "rate_nom_sm3day": 125,
            "rate_opt_min_sm3day": 80,
            "rate_opt_max_sm3day": 160,
            "rate_max_sm3day": 230,
            "slip_nom_rpm": 2910,
            "freq_Hz": 50,
            "eff_max": 0.55,
            "rate_points": [
                0,
                20,
                40,
                60,
                80,
                100,
                120,
                125,
                140,
                160,
                180,
                200,
                220,
                230,
            ],
            "head_points": [
                6.7,
                6.72,
                6.7,
                6.69,
                6.6,
                6.43,
                5.92,
                5.8,
                5.12,
                4.1,
                2.99,
                1.9,
                0.73,
                0,
            ],
            "power_points": [
                0.106,
                0.113,
                0.12,
                0.126,
                0.133,
                0.14,
                0.147,
                0.148,
                0.154,
                0.161,
                0.169,
                0.1725,
                0.1692,
                0.1621,
            ],
            "eff_points": [
                0,
                0.14,
                0.25,
                0.36,
                0.46,
                0.52,
                0.55,
                0.55,
                0.53,
                0.46,
                0.36,
                0.24,
                0.1,
                0,
            ],
        }

        motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }

        self.equipment_data = {
            "esp_system": {
                "esp": {
                    "esp_data": self.esp_data,
                    "stages": 345,
                    "viscosity_correction": True,
                    "gas_correction": False,
                },
                "esp_electric_system": {
                    "motor_data": motor_data,
                    "pump_nom_freq": self.esp_data["freq_Hz"],
                    "gassep_nom_power": 500,
                    "protector_nom_power": 500,
                    "transform_eff": 0.97,
                    "cs_eff": 0.97,
                    "cable_specific_resistance": 1.18,
                },
                "separator": {"k_gas_sep": 0},
            },
            "packer": False,
        }
        self.ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        self.esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            self.equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        print(self.shortDescription())

    def test_calc_pwf_pfl(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        results = self.esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, p_ann=p_ann)

        self.assertEqual(len(results), 15)
        self.assertAlmostEqual(results[0], 3961766.018659096, delta=2000)
        self.assertAlmostEqual(results[2], 1358.353333004197, delta=1)

    def test_calc_pwf_pfl_electric(self):
        """
        EspWell: Расчет забойного давления. Проверка рассчитанных электрических параметров
        """
        pfl = 10 * 101325
        q_liq = 150 / 86400
        wct = 0.1
        freq = 48
        p_ann = 8 * 101325
        results = self.esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, p_ann=p_ann)

        # Мощность на СУ
        self.assertAlmostEqual(results[1], 53425.46687847497, delta=10)
        # Напряжение на трансформаторе
        self.assertAlmostEqual(results[3], 2105.196334761541, delta=1)
        # Сила тока ПЭД
        self.assertAlmostEqual(results[4], 18.330194595274058, delta=0.5)
        # Загрузка ПЭД
        self.assertAlmostEqual(results[5], 0.5237198455792588, delta=0.01)
        # КПД насоса
        self.assertAlmostEqual(results[6], 0.3732906309310629, delta=0.01)
        # КПД системы УЭЦН
        self.assertAlmostEqual(results[7], 0.277255724650251, delta=0.01)
        # Мощность насоса
        self.assertAlmostEqual(results[11], 39709.91249942121, delta=2000)
        # Мощность ПЭД
        self.assertAlmostEqual(results[12], 48675.534103820944, delta=0.01)

    def test_calc_pwf_pfl_electric_with_coef(self):
        """
        EspWell: Расчет забойного давления. Проверка рассчитанных электрических параметров с учетом адаптационных
        коэффициентов для электрики

        """
        pfl = 10 * 101325
        q_liq = 150 / 86400
        wct = 0.1
        freq = 48
        p_ann = 8 * 101325

        c_pump_power = 1.1
        c_cosf = 0.9
        c_amperage = 0.95
        c_transform_power = 1.3
        c_motor_volt = 1.2

        results = self.esp_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            freq=freq,
            p_ann=p_ann,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        # Мощность на СУ
        self.assertAlmostEqual(results[1], 75324.31293520174, delta=100)
        # Напряжение на трансформаторе
        self.assertAlmostEqual(results[3], 2843.350097118854, delta=1)
        # Сила тока ПЭД
        self.assertAlmostEqual(results[4], 19.115523634593874, delta=0.5)
        # Загрузка ПЭД
        self.assertAlmostEqual(results[5], 0.5749029664539511, delta=0.01)
        # КПД насоса
        self.assertAlmostEqual(results[6], 0.33934799633153023, delta=0.01)
        # КПД системы УЭЦН
        self.assertAlmostEqual(results[7], 0.19664951051756202, delta=0.01)
        # Мощность насоса
        self.assertAlmostEqual(results[11], 43680.90374936334, delta=2000)
        # Мощность ПЭД
        self.assertAlmostEqual(results[12], 52785.28512838782, delta=0.01)

    def test_calc_pwf_pfl_with_packer(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм c пакером
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        equipment_data_new = copy.deepcopy(self.equipment_data)
        equipment_data_new.update({"packer": True})
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data_new,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pwf = esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq)
        self.assertAlmostEqual(pwf[0], 4455692.403256696, delta=9000)

    def test_calc_pwf_pfl_extra_output(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с доп. атрибутами
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, p_ann=p_ann, freq=freq, output_params=True
        )

        self.assertIsInstance(self.esp_well.extra_output, dict)
        self.assertEqual(len(self.esp_well.extra_output), len(const.DISTRS) + 8)
        for par in const.DISTRS:
            self.assertIsNotNone(self.esp_well.extra_output.get(par))

    def test_calc_pwf_pfl_extra_output_gray(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм
        с доп. атрибутами на корреляции Gray
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            p_ann=p_ann,
            freq=freq,
            output_params=True,
            hydr_corr_type="gray",
        )

        self.assertIsInstance(self.esp_well.extra_output, dict)
        self.assertEqual(len(self.esp_well.extra_output), len(const.DISTRS) + 8)
        for par in const.DISTRS:
            if par != "flow_pattern":
                self.assertIsNotNone(self.esp_well.extra_output.get(par))

    def test_calc_pwf_pfl_extra_to_json(self):
        """
        EspWell: Проверка что экстра-выводные параметры конвертируются в JSON
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, p_ann=p_ann, freq=freq, output_params=True
        )

        self.assertIsInstance(json.dumps(self.esp_well.extra_output), str)

    def test_calc_pwf_pfl_extra_to_json_choke(self):
        """
        EspWell: Проверка что экстра-выводные параметры конвертируются в JSON с штуцером
        """
        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, output_params=True, p_ann=p_ann)

        self.assertIsInstance(json.dumps(esp_well.extra_output), str)

    def test_calc_pfl_pwf(self):
        """
        EspWell: Расчет линейного давления от забойного = 40 атм
        """
        pwf = 7271572.3130373005
        q_liq = 50 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pfl = self.esp_well.calc_pfl_pwf(pwf, q_liq, wct, freq=freq, p_ann=p_ann)
        self.assertAlmostEqual(pfl[0], 15235192.837526333, delta=0.01)

    def test_calc_pfl_pwf_low_p_in(self):
        """
        EspWell: Расчет линейного давления от забойного = 40 атм для низкого забойного давления,
        не доходящего до приема
        """
        pwf = 10 * 101325
        q_liq = 50 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pfl = self.esp_well.calc_pfl_pwf(pwf, q_liq, wct, freq=freq, p_ann=p_ann)
        self.assertIsNone(pfl[0])
        self.assertEqual(pfl[-1], 1)

    def test_calc_pfl_pwf_low_p_wh(self):
        """
        EspWell: Расчет линейного давления от забойного = 40 атм для низкого забойного давления,
        не доходящего до буфера
        """
        pwf = 40 * 101325
        q_liq = 200 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pfl = self.esp_well.calc_pfl_pwf(pwf, q_liq, wct, freq=freq, p_ann=p_ann)
        self.assertAlmostEqual(90000, pfl[0])
        self.assertEqual(pfl[-1], 1)

    def test_calc_pfl_pwf_extra_output(self):
        """
        EspWell: Расчет линейного давления c экстра-параметрами
        """
        pwf = 50 * 101325
        q_liq = 80 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pfl_pwf(
            pwf, q_liq, wct, freq=freq, p_ann=p_ann, output_params=True, step_length=100,
        )
        # self.maxDiff = None
        self.assertIsNotNone(self.esp_well.extra_output["dp_dl"])

    def test_negative_depth_calc_pwf_pfl(self):
        """
        EspWell: Проверка отрицательности массива глубин при расчете забойного давления
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pwf_pfl(pfl, q_liq, wct, p_ann=p_ann, freq=freq)

        self.assertTrue(
            all(list(map(lambda x: x <= 0, self.esp_well.extra_output.get("depth"))))
        )

    def test_negative_depth_calc_pfl_pwf(self):
        """
        EspWell: Проверка отрицательности массива глубин при расчете линейного давления
        """
        pwf = 7271572.3130373005
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        self.esp_well.calc_pfl_pwf(pwf, q_liq, wct, freq=freq, p_ann=p_ann)

        self.assertTrue(
            all(list(map(lambda x: x <= 0, self.esp_well.extra_output.get("depth"))))
        )

    def test_uniflocpy_error_p_ann_none(self):
        """
        EspWell: Проверка ошибки при незадании затрубного давления
        """
        pwf = 7271572.3130373005
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55

        with self.assertRaises(exc.UniflocPyError):
            self.esp_well.calc_pwf_pfl(pwf, q_liq, wct, freq=freq)

    def test_check_hdyn_none(self):
        """
        EspWell: Проверка что динамический уровень None при расчете с пакером
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        equipment_data_new = copy.deepcopy(self.equipment_data)
        equipment_data_new.update({"packer": True})
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data_new,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        result = esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq)

        self.assertIsNone(result[2])

    def test_docstring_example(self):
        """
        EspWell: Проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[esw.EspWell.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]
        self.maxDiff = None
        self.assertEqual(exs.ESP_WELL, example_string)
        # Пример исходных данных для насоса
        # Если мы хотим задать насос вручную, то нам соответственно нужно заполнить все строки
        # Например, при помощи словаря:
        esp_data = {
            "ID": 99999,
            "source": "legacy",
            "manufacturer": "Reda",
            "name": "DN500",
            "stages_max": 400,
            "rate_nom_sm3day": 30,
            "rate_opt_min_sm3day": 20,
            "rate_opt_max_sm3day": 40,
            "rate_max_sm3day": 66,
            "slip_nom_rpm": 3000,
            "freq_Hz": 50,
            "eff_max": 0.4,
            "height_stage_m": 0.035,
            "Series": 4,
            "d_od_mm": 86,
            "d_cas_min_mm": 112,
            "d_shaft_mm": 17,
            "area_shaft_mm2": 227,
            "power_limit_shaft_kW": 72,
            "power_limit_shaft_high_kW": 120,
            "power_limit_shaft_max_kW": 150,
            "pressure_limit_housing_atma": 390,
            "d_motor_od_mm": 95,
            "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
            "head_points": [
                4.88,
                4.73,
                4.66,
                4.61,
                4.52,
                4.35,
                4.1,
                3.74,
                3.28,
                2.73,
                2.11,
                1.45,
                0.77,
                0,
            ],
            "power_points": [
                0.02,
                0.022,
                0.025,
                0.027,
                0.03,
                0.032,
                0.035,
                0.038,
                0.041,
                0.043,
                0.046,
                0.049,
                0.052000000000000005,
                0.055,
            ],
            "eff_points": [
                0,
                0.12,
                0.21,
                0.29,
                0.35,
                0.38,
                0.4,
                0.39,
                0.37,
                0.32,
                0.26,
                0.19,
                0.1,
                0,
            ],
        }
        # Можно задавать с помощью dict - esp_data = data
        # esp_data = pd.Series(esp_data, name=esp_data['ID'])

        # Исходные данные для ПЭД
        motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }
        # Инициализация исходных данных
        df = pd.DataFrame(
            columns=["MD", "TVD"], data=[[0, 0], [1400, 1200], [1800, 1542.85]]
        )
        # Возможный способ задания инклинометрии через dict
        # df = {'MD': [0, 1000],
        #       'TVD': [0, 900]}
        # В словари с калибровками подается давление и температура калибровки.
        # Зачастую - это давление насыщения и пластовая температура
        fluid_data = {
            "q_fluid": uc.convert_rate(40, "m3/day", "m3/s"),
            "wct": 0,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 50,
                    "oil_correlations": {
                        "pb": "Standing",
                        "rs": "Standing",
                        "rho": "Standing",
                        "b": "Standing",
                        "mu": "Beggs",
                        "compr": "Vasquez",
                    },
                    "gas_correlations": {
                        "ppc": "Standing",
                        "tpc": "Standing",
                        "z": "Dranchuk",
                        "mu": "Lee",
                    },
                    "water_correlations": {
                        "b": "McCain",
                        "compr": "Kriel",
                        "rho": "Standing",
                        "mu": "McCain",
                    },
                    "rsb": {"value": 50, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                    "table_model_data": None,
                    "use_table_model": False,
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        # Так тоже возможно: d = {'MD': [0, 1000], 'd': [0.06, 0.08]}
        pipe_data = {
            "casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
            "tubing": {
                "bottom_depth": 1400,
                "d": d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        well_trajectory_data = {"inclinometry": df}
        ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
        equipment_data = {
            "esp_system": {
                "esp": {
                    "esp_data": esp_data,
                    "stages": 345,
                    "viscosity_correction": True,
                    "gas_correction": False,
                },
                "esp_electric_system": {
                    "motor_data": motor_data,
                    "gassep_nom_power": 500,
                    "protector_nom_power": 500,
                    "transform_eff": 0.97,
                    "cs_eff": 0.97,
                    "cable_specific_resistance": 1.18,
                    "cable_length": 1450,
                },
                "separator": {"k_gas_sep": 0},
            },
            "packer": False,
        }
        # Текущая частота
        freq = 53
        # Затрубное давление
        p_ann = 10 * 101325
        # Инициализация объекта скважины
        well = esw.EspWell(
            fluid_data,
            pipe_data,
            equipment_data,
            well_trajectory_data,
            ambient_temperature_data,
        )
        p_wf = well.calc_pwf_pfl(
            uc.convert_pressure(1, "MPa", "Pa"),
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            freq,
            p_ann=p_ann,
        )

        # Можно указать output_params=True, тогда рассчитаются распределения
        well.calc_pwf_pfl(
            uc.convert_pressure(1, "MPa", "Pa"),
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            freq,
            p_ann=p_ann,
            output_params=True,
        )
        # Запрос всех значений доп. свойств в виде словаря
        self.assertAlmostEqual(p_wf[0], 9051598.928980302, delta=1000)

    def test_p_results_with_choke(self):
        """
        EspWell: Тестирование правильности создания распределения давления с штуцером

        :return:
        """
        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, freq=freq, output_params=True, p_ann=p_ann
        )
        self.assertAlmostEqual(pwf[0], 3962874.498533643, delta=1000)
        self.assertAlmostEqual(len(esp_well.extra_output), 51)
        # TODO: Тест неправильный - но на текущий момент лучше не сделать, нужно поправить после внедрения оптимизатора
        print(esp_well.extra_output.get("p"))
        npt.assert_almost_equal(
            esp_well.extra_output.get("p"),
            [
                6683416.507132877,
                6948591.844603377,
                6948591.844603377,
                7021852.093617,
                7095112.119301452,
                7168371.829769542,
                7241631.133134073,
                7314889.93750785,
                7388148.151003679,
                7461405.681734364,
                7534662.437812707,
                7607918.327351517,
                7681173.258463596,
                7754427.139261748,
                7827679.877858779,
                7900931.382367496,
                7974181.560900702,
                8047430.321571201,
                8120677.572491797,
                8193923.221775298,
                8267167.177534505,
                8340409.347882223,
                8413649.64093126,
                8486887.96479442,
                8560124.227584507,
                8633358.337414324,
                8706590.202396678,
                8779819.730644371,
                8853046.830270212,
                8926271.409387004,
                8999493.376107547,
                9072712.638544653,
                9145929.104811125,
                9219142.683019765,
                9292353.281283377,
                9365560.80771477,
                9438765.170426747,
                9511966.277532112,
                9585164.03714367,
                9658358.357374225,
                9731549.146336582,
                9804736.31214355,
                9877919.762907926,
                9951099.40674252,
                10024275.151760137,
                10097446.906073578,
                10170614.577795653,
                10243778.075039163,
                10316937.305916913,
                10390092.178541707,
                10463242.601026352,
                10536388.481483653,
                10609529.728026412,
                10682666.248767437,
                10755797.95181953,
                10828924.745295497,
                10902046.537308142,
                10975163.235970272,
                11048274.749394689,
                11121380.985694198,
                11194481.852981605,
                11267577.259369714,
                11340667.11297133,
                11413751.321899258,
                11486829.794266302,
                11559902.438185269,
                11632969.16176896,
                11706029.873130184,
                11779084.48038174,
                11852132.891636439,
                11925175.015007082,
                11998210.758606475,
                12071240.030547421,
                12144262.73894273,
                12217278.7919052,
                12290288.09754764,
                12363290.563982852,
                12436286.099323642,
                12509274.611682815,
                12582256.009173177,
                12655230.199907532,
                12728197.091998681,
                12801156.593559437,
                12874108.612702595,
                12947053.057540966,
                13019989.836187353,
                13092918.856754562,
                13165840.027355395,
                13238753.256102659,
                13311658.451109158,
                13384555.520487696,
                13457444.37235108,
                13530324.914812114,
                13603197.055983601,
                13676060.703978347,
                13748915.766909156,
                13821762.152888834,
                13894599.770030186,
                13967428.526446013,
                14040248.330249125,
                14113059.089552324,
                14185860.712468414,
                14258653.107110202,
                14331436.181590492,
                14404209.844022086,
                14476974.002517793,
                14549728.565190416,
                14622475.62496271,
                14695220.08848359,
                14767962.143732296,
                14840701.789596941,
                14913439.024965638,
                14986173.848726505,
                15058906.259767655,
                15131636.256977202,
                15204363.839243263,
                15277089.00545395,
                15349811.754497379,
                15422532.085261663,
                15495249.99663492,
                15567965.48750526,
                15640678.556760801,
                15713389.203289658,
                15786097.425979942,
                15858803.223719772,
                15931506.59539726,
                16004207.539900523,
                16076906.056117672,
                16149602.142936824,
                16222295.799246093,
                16294987.023933595,
                16367675.815887442,
                16440362.17399575,
                16513046.097146634,
                16585727.58422821,
                16658406.63412859,
                16731083.245735887,
                16803757.41793822,
                16876429.149623703,
                16949098.440054536,
                17021765.289958127,
                17094429.69877792,
                17167091.665763494,
                17167091.665763494,
                1201153.8971504772,
                1201153.8971504772,
                1266864.9796336927,
                1332631.7184092517,
                1398454.83075015,
                1464331.6701681097,
                1530259.0258138801,
                1596233.6868382099,
                1662252.4423918477,
                1728312.081625543,
                1794409.3936900445,
                1860541.167736101,
                1926704.1929144617,
                1992895.2583758752,
                2059111.1532710907,
                2125348.6667508567,
                2191604.587965923,
                2258111.858147784,
                2325411.4661458107,
                2393462.7507719765,
                2462198.1741129328,
                2531550.19825533,
                2601451.2852858184,
                2671833.8972910484,
                2742630.496357671,
                2813773.5445723366,
                2885195.504021696,
                2956828.836792399,
                3028594.805843197,
                3100388.4076478705,
                3172196.560104755,
                3244018.6580372527,
                3315854.096268765,
                3387702.269622694,
                3459562.5729224416,
                3531434.40099141,
                3603317.1486530006,
                3675210.2107306165,
                3747112.9820476584,
                3819024.8683538437,
                3890945.511162446,
                3962874.554043243,
            ],
            decimal=2,
        )

    def test_p_results_no_choke(self):
        """
        EspWell: Тестирование правильности создания распределения давления без штуцера

        :return:
        """
        pfl = 7271572.3130373005
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 10 * 101325
        self.esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, freq=freq, p_ann=p_ann, output_params=True
        )
        # print(self.esp_well.extra_output.get("p"))
        npt.assert_almost_equal(
            self.esp_well.extra_output.get("p"),
            [
                7734438.120766094,
                7807713.282142792,
                7880988.09684306,
                7954262.472943959,
                8027536.318522551,
                8100809.541655899,
                8174082.050421066,
                8247353.752895113,
                8320624.557155103,
                8393894.371278096,
                8467163.103341158,
                8540430.661421347,
                8613696.953595728,
                8686961.887941364,
                8760225.372535314,
                8833487.315454643,
                8906747.624776412,
                8980006.208577681,
                9053262.974935517,
                9126517.83192698,
                9199770.68762913,
                9273021.450119033,
                9346270.02747375,
                9419516.32777034,
                9492760.259085868,
                9566001.729497397,
                9639240.647081988,
                9712476.919916704,
                9785710.456078608,
                9858941.163644757,
                9932168.95069222,
                10005393.725298055,
                10078615.395539325,
                10151833.869493093,
                10225049.055236422,
                10298260.860846372,
                10371469.194400005,
                10444673.963974386,
                10517875.077646576,
                10591072.443493638,
                10664265.96959263,
                10737455.564020619,
                10810641.134854667,
                10883822.590171833,
                10956999.838049179,
                11030172.786563773,
                11103341.34379267,
                11176505.417812936,
                11249664.916701633,
                11322819.748535825,
                11395969.82139257,
                11469115.043348933,
                11542255.322481975,
                11615390.56686876,
                11688520.684586346,
                11761645.583711801,
                11834765.172322184,
                11907879.358494557,
                11980988.050305983,
                12054091.155833524,
                12127188.583154242,
                12200280.2403452,
                12273366.035483459,
                12346445.876646081,
                12419519.67191013,
                12492587.329352668,
                12565648.757050755,
                12638703.863081455,
                12711752.55552183,
                12784794.742448943,
                12857830.331939854,
                12930859.232071627,
                13003881.350921324,
                13076896.596566007,
                13149904.877082735,
                13222906.100548577,
                13295900.17504059,
                13368887.008635838,
                13441866.509411383,
                13514838.585444286,
                13587803.144811612,
                13660760.09559042,
                13733709.345857775,
                13806650.803690737,
                13879584.37716637,
                13952509.974361734,
                14025427.503353894,
                14098336.872219909,
                14171237.989036845,
                14244130.761881761,
                14317015.09883172,
                14389890.907963786,
                14462758.097355017,
                14535616.57508248,
                14608466.249223236,
                14681307.027854346,
                14754138.819052871,
                14826961.530895876,
                14899775.071460422,
                14972579.348823572,
                15045374.271062385,
                15118159.746253928,
                15190935.68247526,
                15263701.987803444,
                15336458.92163829,
                15409211.674603658,
                15481961.998535153,
                15554709.892590722,
                15627455.355928306,
                15700198.387705853,
                15772938.987081306,
                15845677.15321261,
                15918412.88525771,
                15991146.18237455,
                16063877.043721076,
                16136605.468455233,
                16209331.455734964,
                16282055.004718214,
                16354776.11456293,
                16427494.784427054,
                16500211.013468532,
                16572924.80084531,
                16645636.14571533,
                16718345.047236538,
                16791051.504566878,
                16863755.5168643,
                16936457.08328674,
                17009156.20299215,
                17081852.87513847,
                17154547.098883644,
                17227238.873385623,
                17299928.197802346,
                17372615.071291763,
                17445299.493011814,
                17517981.462120444,
                17590660.9777756,
                17663338.039135225,
                17736012.645721264,
                17808684.798175156,
                17881354.496065013,
                17954021.738838535,
                17954021.738838535,
                1203476.7610267042,
                1203476.7610267042,
                1269189.9488797276,
                1334958.7514606353,
                1400783.862886525,
                1466662.6295696301,
                1532591.8335656573,
                1598568.2569303121,
                1664588.6817193008,
                1730649.889988329,
                1796748.663793103,
                1862881.7851893287,
                1929046.0362327127,
                1995238.19897896,
                2061455.055483777,
                2127693.38780287,
                2193949.977991945,
                2260460.490466863,
                2327789.4301891415,
                2395893.5108800423,
                2464699.3074228377,
                2534133.3947008005,
                2604122.347597203,
                2674592.740995318,
                2745471.1497784187,
                2816684.148829777,
                2888158.3130326653,
                2959820.217270357,
                3031590.197626366,
                3103384.6016917583,
                3175193.5192818115,
                3247016.347585673,
                3318852.483792491,
                3390701.3250914114,
                3462562.268671583,
                3534434.7117221523,
                3606318.051432267,
                3678211.6849910747,
                3750115.0095877224,
                3822027.4315326028,
                3893948.5879224883,
                3965878.12656374,
            ],
            decimal=2,
        )

    def test_nodal_results(self):
        """
        EspWell: Тестирование создания распределения ключевых узлов

        :return:
        """
        pwf = 7271572.3130373005
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 10 * 101325
        self.esp_well.calc_pwf_pfl(
            pwf, q_liq, wct, freq=freq, p_ann=p_ann, output_params=True
        )
        self.assertEqual(
            self.esp_well.extra_output.get("nodes"),
            [
                "Буфер",
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                "Выкид ЭЦН",
                "Прием ЭЦН",
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                "Верхние дыры перфорации",
            ],
        )

    def test_calc_pwf_pfl_choke_1(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного и коэффициента
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, p_ann=p_ann)
        self.assertAlmostEqual(pwf[0], 3962874.498533643, delta=1000)

    def test_calc_pwf_pfl_choke_2(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного и коэффициента
        с с_choke = 2
        """
        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, c_choke=2, p_ann=p_ann)
        self.assertAlmostEqual(pwf[0], 3960419.992791885, delta=1000)

    def test_calc_pwf_pfl_choke_adapt(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного и коэффициента
        с адаптацией штуцера
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, freq=freq, c_choke=None, p_wh=pwh, p_ann=p_ann
        )
        self.assertAlmostEqual(pwf[0], 3967209.0880947663, delta=1000)

    def test_calc_pwf_pfl_choke_adapt_const(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного и коэффициента
        с adapt=const
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        pwh = 12 * 101325
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            freq=freq,
            c_choke={"const": pwh - pfl},
            p_ann=p_ann,
            output_params=True,
        )
        self.assertAlmostEqual(pwf[0], 3963652.717130728, delta=1000)

    def test_calc_pwf_pfl_choke_extra(self):
        """
        EspWell: Расчет забойного давления от линейного = 10 атм с штуцером с доп. распределениями
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        esp_well = esw.EspWell(
            self.fluid_data,
            self.pipe_data,
            equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        freq = 55
        p_ann = 8 * 101325
        pwf = esp_well.calc_pwf_pfl(
            pfl, q_liq, wct, freq=freq, output_params=True, p_ann=p_ann
        )
        self.assertAlmostEqual(pwf[0], 3962874.498533643, delta=1000)
        self.assertAlmostEqual(len(esp_well.extra_output), 51)

    def test_calc_pwf_pfl_continuous_calc(self):
        """
        EspWell: Проверка отсутствия зависания скважин при больших давлениях оптимизатора
        """
        fluid_data = {
            "q_fluid": 0.0023148148148148147,
            "wct": 0.985,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_oil": 0.8151389680173715,
                    "gamma_wat": 1.0,
                    "rp": 217.5540112620073,
                    "rsb": {"value": 107.27700163599182, "p": 15705375.0, "t": 345.25},
                    "bob": {"value": 2.041, "p": 15705375.0, "t": 345.25},
                    "muob": {"value": 1.6160890644639971, "p": 15705375.0, "t": 345.25},
                    "fluid_type": "liquid",
                }
            },
        }
        equipment_data = {
            "choke": {"d": 0.032},
            "esp_system": {
                "esp": {
                    "h_mes": 3100.0,
                    "stages": 482.0,
                    "esp_data": {
                        "name": "2ЭЦНДПЭКР5А-160",
                        "section_number": 1,
                        "rate_nom_sm3day": 160.00000,
                        "rate_opt_min_sm3day": 100.00000,
                        "rate_opt_max_sm3day": 200.00000,
                        "freq_Hz": 50.00000,
                        "rate_points": [
                            0.1,
                            48.9,
                            101.8,
                            130.0,
                            160.0,
                            161.4,
                            171.4,
                            180.2,
                            196.8,
                            235.8,
                            279.8,
                        ],
                        "head_points": [
                            0.138,
                            0.182,
                            0.228,
                            0.251,
                            0.268,
                            0.268,
                            0.269,
                            0.267,
                            0.257,
                            0.243,
                            0.243,
                        ],
                        "power_points": [
                            0.138,
                            0.182,
                            0.228,
                            0.251,
                            0.268,
                            0.268,
                            0.269,
                            0.267,
                            0.257,
                            0.243,
                            0.243,
                        ],
                        "eff_points": [
                            0.001,
                            0.319,
                            0.505,
                            0.581,
                            0.638,
                            0.64,
                            0.645,
                            0.641,
                            0.614,
                            0.464,
                            0.0,
                        ],
                        "stages_max": 146,
                        "rate_max_sm3day": 279.80000,
                        "slip_nom_rpm": 2910.00000,
                        "eff_max": 0.63800,
                    },
                    "viscosity_correction": True,
                    "gas_correction": False,
                },
                "esp_electric_system": {
                    "motor_data": {
                        "id": 2709282700,
                        "manufacturer": "Борец",
                        "name": "9ЭДБТ125-117 В5",
                        "d_motor_mm": 117.0,
                        "motor_nom_i": 49.0,
                        "motor_nom_power": 125.0,
                        "motor_nom_voltage": 2100.0,
                        "motor_nom_eff": 0.825,
                        "motor_nom_cosf": 0.85,
                        "motor_nom_freq": 50.0,
                        "load_points": [
                            0.2,
                            0.3,
                            0.4,
                            0.5,
                            0.6,
                            0.7,
                            0.8,
                            0.9,
                            1.0,
                            1.1,
                            1.2,
                        ],
                        "amperage_points": [
                            0.5,
                            0.53,
                            0.58,
                            0.64,
                            0.7,
                            0.77,
                            0.84,
                            0.92,
                            1.0,
                            1.09,
                            1.18,
                        ],
                        "cosf_points": [
                            0.4,
                            0.5,
                            0.6,
                            0.67,
                            0.725,
                            0.785,
                            0.81,
                            0.85,
                            0.875,
                            0.895,
                            0.905,
                        ],
                        "eff_points": [
                            0.74,
                            0.8,
                            0.845,
                            0.85,
                            0.87,
                            0.875,
                            0.87,
                            0.86,
                            0.845,
                            0.84,
                            0.83,
                        ],
                        "rpm_points": [
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                            3000.0,
                        ],
                    },
                    "cable_specific_resistance": 1.311500815660685,
                    "transform_eff": 0.97,
                    "cs_eff": 0.97,
                },
            },
            "packer": False,
        }
        pipe_data = {
            "casing": {"bottom_depth": 3299.0, "d": 0.1468, "roughness": 0.0001},
            "tubing": {
                "bottom_depth": 3041.89,
                "roughness": 0.0001,
                "d": {"MD": [1536.23, 2103.79, 3041.89], "d": [0.062, 0.062, 0.062]},
                "s_wall": 0.0055,
            },
        }
        well_trajectory_data = {
            "inclinometry": {
                "MD": [
                    0.0,
                    10.0,
                    20.0,
                    30.0,
                    40.0,
                    50.0,
                    60.0,
                    70.0,
                    80.0,
                    90.0,
                    110.0,
                    159.0,
                    183.0,
                    207.0,
                    231.0,
                    255.0,
                    279.0,
                    304.0,
                    328.0,
                    352.0,
                    376.0,
                    400.0,
                    424.0,
                    448.0,
                    473.0,
                    497.0,
                    521.0,
                    545.0,
                    569.0,
                    593.0,
                    606.0,
                    633.0,
                    657.0,
                    681.0,
                    705.0,
                    729.0,
                    753.0,
                    778.0,
                    802.0,
                    826.0,
                    850.0,
                    874.0,
                    898.0,
                    922.0,
                    946.0,
                    971.0,
                    995.0,
                    1019.0,
                    1043.0,
                    1067.0,
                    1091.0,
                    1115.0,
                    1140.0,
                    1164.0,
                    1188.0,
                    1212.0,
                    1236.0,
                    1260.0,
                    1285.0,
                    1308.0,
                    1333.0,
                    1357.0,
                    1381.0,
                    1400.0,
                    1421.0,
                    1442.0,
                    1454.0,
                    1466.0,
                    1490.0,
                    1514.0,
                    1538.0,
                    1562.0,
                    1587.0,
                    1611.0,
                    1635.0,
                    1659.0,
                    1683.0,
                    1707.0,
                    1732.0,
                    1756.0,
                    1780.0,
                    1804.0,
                    1828.0,
                    1852.0,
                    1876.0,
                    1888.0,
                    1925.0,
                    1949.0,
                    1973.0,
                    1997.0,
                    2021.0,
                    2045.0,
                    2069.0,
                    2093.0,
                    2117.0,
                    2141.0,
                    2165.0,
                    2190.0,
                    2214.0,
                    2238.0,
                    2262.0,
                    2286.0,
                    2310.0,
                    2334.0,
                    2358.0,
                    2383.0,
                    2407.0,
                    2431.0,
                    2455.0,
                    2479.0,
                    2503.0,
                    2527.0,
                    2552.0,
                    2576.0,
                    2588.0,
                    2612.0,
                    2636.0,
                    2660.0,
                    2684.0,
                    2709.0,
                    2733.0,
                    2757.0,
                    2781.0,
                    2805.0,
                    2829.0,
                    2841.0,
                    2866.0,
                    2890.0,
                    2914.0,
                    2938.0,
                    2962.0,
                    2986.0,
                    3010.0,
                    3034.0,
                    3058.0,
                    3083.0,
                    3107.0,
                    3131.0,
                    3155.0,
                    3179.0,
                    3203.0,
                    3227.0,
                    3252.0,
                    3276.0,
                    3300.0,
                    3325.0,
                    3350.0,
                    3387.0,
                    3411.0,
                    3436.0,
                    3461.0,
                    3483.0,
                    3501.0,
                ],
                "TVD": [
                    0.0,
                    10.0,
                    20.0,
                    30.0,
                    40.0,
                    50.0,
                    59.99,
                    69.99,
                    79.99,
                    89.99,
                    109.99,
                    158.98,
                    182.97,
                    206.97,
                    230.97,
                    254.96,
                    278.95,
                    303.94,
                    327.92,
                    351.87,
                    375.77,
                    399.59,
                    423.28,
                    446.69,
                    470.54,
                    492.69,
                    513.93,
                    534.5,
                    554.81,
                    574.98,
                    585.87,
                    608.46,
                    628.5,
                    648.42,
                    668.11,
                    687.51,
                    706.42,
                    725.27,
                    742.41,
                    758.86,
                    775.23,
                    791.66,
                    807.91,
                    824.02,
                    840.2,
                    857.28,
                    873.75,
                    890.17,
                    906.6,
                    922.92,
                    939.08,
                    955.26,
                    972.33,
                    988.93,
                    1005.7,
                    1022.59,
                    1039.34,
                    1055.87,
                    1072.6,
                    1087.64,
                    1104.12,
                    1120.19,
                    1136.52,
                    1149.59,
                    1164.09,
                    1178.51,
                    1186.54,
                    1194.3,
                    1209.64,
                    1225.0,
                    1240.51,
                    1256.08,
                    1272.23,
                    1287.77,
                    1303.68,
                    1320.04,
                    1336.39,
                    1352.56,
                    1369.31,
                    1385.42,
                    1401.56,
                    1417.75,
                    1433.97,
                    1450.25,
                    1466.62,
                    1474.81,
                    1500.1,
                    1516.51,
                    1532.85,
                    1549.07,
                    1565.28,
                    1581.46,
                    1597.63,
                    1613.9,
                    1630.23,
                    1646.57,
                    1662.97,
                    1680.05,
                    1696.45,
                    1712.62,
                    1728.47,
                    1744.19,
                    1759.86,
                    1775.59,
                    1791.4,
                    1807.97,
                    1823.91,
                    1839.69,
                    1855.57,
                    1871.61,
                    1887.55,
                    1903.24,
                    1919.38,
                    1935.0,
                    1942.91,
                    1958.78,
                    1975.02,
                    1991.72,
                    2008.52,
                    2026.04,
                    2042.94,
                    2059.84,
                    2076.71,
                    2093.92,
                    2111.51,
                    2120.32,
                    2138.95,
                    2157.29,
                    2175.82,
                    2194.41,
                    2213.28,
                    2232.61,
                    2252.59,
                    2273.11,
                    2293.85,
                    2315.57,
                    2336.47,
                    2357.7,
                    2379.26,
                    2400.91,
                    2422.84,
                    2445.01,
                    2468.24,
                    2490.82,
                    2513.73,
                    2537.75,
                    2561.84,
                    2597.66,
                    2621.03,
                    2645.5,
                    2670.04,
                    2691.7,
                    2709.45,
                ],
            }
        }
        ambient_temperature_data = {"MD": [0, 3299.0], "T": [278.15, 345.25]}
        esp_well = esw.EspWell(
            fluid_data,
            pipe_data,
            equipment_data,
            well_trajectory_data,
            ambient_temperature_data,
        )
        pfl = 27.467 * 101325
        q_liq = 253.846 / 86400
        wct = 0.985
        freq = 54.75
        p_ann = 22 * 101325
        pwf = esp_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            freq=freq,
            p_ann=p_ann,
            c_choke={"const": 20265},
            hydr_corr_type="gray",
            head_factor=0.76,
            c_pump_power=0.88,
            c_cosf=0.89,
            c_transform_power=1.15,
            c_motor_volt=1.32,
            c_amperage=1.09,
        )
        self.assertAlmostEqual(pwf[0], 27066438.72616508, delta=1000)


# тестирование расчета коэффициента сепарации газосепаратора с помощью pytest
def init_esp_wll(sep_name=None, p=10, gas_corr=True):
    """
    EspWell: инициализация
    """
    fluid_data = {
        "q_fluid": 100 / 86400,
        "wct": 0.1,
        "pvt_model_data": {
            "black_oil": {
                "gamma_gas": 0.7,
                "gamma_wat": 1,
                "gamma_oil": 0.8,
                "rp": 100,
                "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
            }
        },
    }
    # Диаметр можно задавать как числом так и таблицей с распределением по глубине
    d = {"MD": [0, 1000], "d": [0.062, 0.082]}
    pipe_data = {
        "casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
        "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005,},
    }
    trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
    well_trajectory_data = {"inclinometry": trajectory}
    esp_data = {
        "ID": 737,
        "source": "UniflocVBA",
        "manufacturer": "Новомет",
        "name": "ВНН5-125",
        "stages_max": 517,
        "rate_nom_sm3day": 125,
        "rate_opt_min_sm3day": 80,
        "rate_opt_max_sm3day": 160,
        "rate_max_sm3day": 230,
        "slip_nom_rpm": 2910,
        "freq_Hz": 50,
        "eff_max": 0.55,
        "rate_points": [0, 20, 40, 60, 80, 100, 120, 125, 140, 160, 180, 200, 220, 230,],
        "head_points": [
            6.7,
            6.72,
            6.7,
            6.69,
            6.6,
            6.43,
            5.92,
            5.8,
            5.12,
            4.1,
            2.99,
            1.9,
            0.73,
            0,
        ],
        "power_points": [
            0.106,
            0.113,
            0.12,
            0.126,
            0.133,
            0.14,
            0.147,
            0.148,
            0.154,
            0.161,
            0.169,
            0.1725,
            0.1692,
            0.1621,
        ],
        "eff_points": [
            0,
            0.14,
            0.25,
            0.36,
            0.46,
            0.52,
            0.55,
            0.55,
            0.53,
            0.46,
            0.36,
            0.24,
            0.1,
            0,
        ],
    }

    motor_data = {
        "ID": 1,
        "manufacturer": "Centrilift",
        "name": "562Centrilift-KMB-130-2200B",
        "d_motor_mm": 142.7,
        "motor_nom_i": 35,
        "motor_nom_power": 96.98,
        "motor_nom_voltage": 2200,
        "motor_nom_eff": 80,
        "motor_nom_cosf": 0.82,
        "motor_nom_freq": 60,
        "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
        "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
        "rpm_points": [
            3568.604,
            3551.63,
            3534.656,
            3517.682,
            3500.708,
            3483.734,
            3466.76,
            3449.786,
            3432.812,
            3415.838,
        ],
    }

    equipment_data = {
        "esp_system": {
            "esp": {
                "esp_data": esp_data,
                "stages": 345,
                "viscosity_correction": True,
                "gas_correction": gas_corr,
            },
            "esp_electric_system": {
                "motor_data": motor_data,
                "pump_nom_freq": esp_data["freq_Hz"],
                "gassep_nom_power": 500,
                "protector_nom_power": 500,
                "transform_eff": 0.97,
                "cs_eff": 0.97,
                "cable_specific_resistance": 1.18,
            },
            "separator": {"k_gas_sep": 0, "sep_name": sep_name},
        },
        "packer": False,
    }
    ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

    esp_well = esw.EspWell(
        fluid_data,
        pipe_data,
        equipment_data,
        well_trajectory_data,
        ambient_temperature_data,
    )

    pfl = p * 101325
    q_liq = 100 / 86400
    wct = 0.1
    freq = 55
    p_ann = 8 * 101325
    res = esp_well.calc_pwf_pfl(pfl, q_liq, wct, freq=freq, p_ann=p_ann)

    return res[0]


def test_esp_well_sep1():
    """
    EspWell: Расчет с конкретным сепаратором
    """
    p = init_esp_wll(sep_name="3МНГБ5А.1-КМ")
    assert p is not None


def test_esp_well_sep2():
    """
    EspWell: Расчет с неправильным названием сепаратора(по усредненной хар-ке)
    """
    p = init_esp_wll(sep_name="Нет тут названия и не будет.")
    assert p is not None


def test_esp_well_sep3():
    """
    EspWell: Расчет без конкретного сепаратора
    """
    p = init_esp_wll()
    assert p is not None


def test_esp_well_gas_corr():
    """
    EspWell: Расчет забойного давления от линейного = 10 атм без учета деградации НРХ по свободному газу
    """
    p = init_esp_wll(gas_corr=False)
    assert p == 4609143.428997107


def test_esp_well_gas_corr_with_sep():
    """
    EspWell: Расчет забойного давления от линейного = 10 атм без учета деградации НРХ по свободному газу c конкретным сепаратором
    """
    p = init_esp_wll(sep_name="МНГСЛ5-М", gas_corr=False)
    assert p == 4045263.206376261


if __name__ == "__main__":
    unittest.main()
