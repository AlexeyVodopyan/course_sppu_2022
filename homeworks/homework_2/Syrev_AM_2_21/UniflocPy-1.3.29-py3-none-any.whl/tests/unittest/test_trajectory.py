import ast
import os
import sys
import unittest

import numpy as np
import pandas as pd

import unifloc.common.trajectory as traj
import unifloc.tools.exceptions as exc
import tests.unittest.example_strings as exs


class TestWellTrajectory(unittest.TestCase):
    def setUp(self) -> None:
        self.md = [0, 1000]
        self.tvd = [0, 900]
        print(f"Test: {self.shortDescription()}")

    def test_well_trajectory_dataframe(self):
        """
        Trajectory: Исходные данные с помощью DataFrame
        """
        inclinometry = pd.DataFrame(
            columns=["MD", "TVD"], data=np.array([self.md, self.tvd]).T
        )
        well_trajectory = traj.Trajectory(inclinometry)
        self.assertEqual(well_trajectory.calc_tvd(1000), 900)

    def test_well_trajectory_dict(self):
        """
        Trajectory: Исходные данные с помощью dict
        """
        inclinometry = {"MD": self.md, "TVD": self.tvd}
        well_trajectory = traj.Trajectory(inclinometry)
        self.assertEqual(well_trajectory.calc_tvd(1000), 900)

    def test_well_trajectory_type_error(self):
        """
        Trajectory: Исходные данные с помощью нереализованного способа задания - списка
        """
        inclinometry = [self.md, self.tvd]
        with self.assertRaises(exc.InclinometryError):
            traj.Trajectory(inclinometry)

    def test_well_trajectory_duplicate_error(self):
        """
        Trajectory: Исходные данные заданные с дубликатами MD
        """
        inclinometry = {"MD": [0, 0, 10], "TVD": [0, 0, 9]}
        with self.assertRaises(exc.InclinometryError):
            traj.Trajectory(inclinometry)

    def test_well_trajectory_MD_up_TVD(self):
        """
        Trajectory: Исходные данные заданные с TVD > MD
        """
        inclinometry = {"MD": [0, 2, 10], "TVD": [0, 3, 9]}
        with self.assertRaises(exc.InclinometryError):
            traj.Trajectory(inclinometry)

    def test_well_trajectory_dMD_up_dTVD(self):
        """
        Trajectory: Исходные данные заданные с dTVD > dMD
        """
        inclinometry = {"MD": [0, 3, 10, 12], "TVD": [0, 3, 9, 11.5]}
        with self.assertRaises(exc.InclinometryError):
            traj.Trajectory(inclinometry)

    def test_well_trajectory_dMD_up_abs_dTVD(self):
        """
        Trajectory: Исходные данные заданные с abs(dTVD) > dMD
        """
        inclinometry = {"MD": [0, 1039.62, 1243.61], "TVD": [0, 1039.62, 778.8]}
        with self.assertRaises(exc.InclinometryError):
            traj.Trajectory(inclinometry)

    def test_rounding(self):
        """
        Trajectory: Исходные данные с вылетом MathDomain Error из-за интерполяции
        """
        inclinometry = {
            "MD": [
                0.0,
                10.0,
                20.0,
                30.0,
                40.0,
                50.0,
                60.0,
                70.36,
                98.91,
                127.41,
                156.18,
                184.52,
                213.21,
                241.65,
                270.06,
                298.47,
                326.86,
                355.26,
                383.37,
                411.89,
                440.23,
                468.66,
                497.03,
                525.55,
                554.57,
                583.23,
                611.62,
                630.46,
                668.32,
                697.37,
                725.77,
                754.22,
                782.62,
                811.14,
                839.69,
                868.01,
                896.39,
                925.01,
                953.64,
                981.9,
                1011.1,
                1039.58,
                1068.2,
                1096.67,
                1125.13,
                1153.84,
                1182.48,
                1210.97,
                1239.42,
                1268.49,
                1297.02,
                1325.48,
                1353.89,
                1382.34,
                1413.68,
                1442.09,
                1470.54,
                1499.0,
                1527.34,
                1555.77,
                1584.08,
                1612.43,
                1640.84,
                1669.59,
                1698.17,
                1726.79,
                1755.23,
                1783.7,
                1812.11,
                1840.58,
                1869.41,
                1897.99,
                1926.7,
                1955.22,
                1983.63,
                2012.15,
                2040.48,
                2069.04,
                2097.5,
                2125.78,
                2154.21,
                2182.59,
                2211.08,
                2239.7,
                2268.23,
                2296.87,
                2325.42,
                2353.79,
                2381.98,
                2410.22,
                2438.56,
                2467.33,
                2497.88,
                2526.27,
                2554.66,
                2583.04,
                2611.52,
                2640.11,
                2668.4,
                2697.11,
                2725.34,
                2753.61,
                2782.2,
                2810.7,
                2839.04,
                2867.41,
                2895.91,
                2924.54,
                2953.46,
                2982.15,
                3010.67,
                3038.95,
                3067.46,
                3095.85,
                3124.0,
                3152.48,
                3175.1,
                3189.32,
                3202.89,
                3217.11,
                3231.19,
                3244.35,
                3258.8,
                3272.52,
                3286.91,
                3300.63,
                3310.61,
                3319.61,
                3328.99,
                3338.25,
                3347.74,
                3357.22,
                3366.47,
                3375.97,
                3385.45,
                3394.67,
                3404.16,
                3413.6,
                3422.83,
                3432.29,
                3441.54,
                3450.97,
                3460.4,
                3469.66,
                3478.91,
                3488.17,
                3497.4,
                3506.83,
                3516.08,
                3525.51,
                3534.99,
                3544.25,
                3553.63,
                3562.98,
                3572.3,
                3581.65,
                3591.06,
                3600.46,
                3609.71,
                3619.19,
                3628.67,
                3637.92,
                3647.35,
                3656.81,
                3666.21,
                3675.69,
                3685.17,
                3694.42,
                3703.92,
                3713.32,
                3722.61,
                3731.88,
                3741.37,
                3750.63,
                3759.89,
                3769.14,
                3778.38,
                3787.64,
                3796.89,
                3806.15,
                3815.37,
                3824.62,
                3834.1,
                3843.48,
                3852.97,
                3862.23,
                3871.67,
                3881.0,
                3890.25,
                3899.5,
                3904.0,
                3919.0,
            ],
            "TVD": [
                0.0,
                10.0,
                20.0,
                30.0,
                40.0,
                50.0,
                60.0,
                70.36,
                98.9,
                127.4,
                156.16,
                184.5,
                213.19,
                241.63,
                270.03,
                298.44,
                326.83,
                355.23,
                383.34,
                411.85,
                440.19,
                468.62,
                496.99,
                525.51,
                554.53,
                583.19,
                611.58,
                630.42,
                668.27,
                697.32,
                725.72,
                754.17,
                782.57,
                811.09,
                839.63,
                867.95,
                896.33,
                924.95,
                953.57,
                981.83,
                1011.02,
                1039.5,
                1068.12,
                1096.59,
                1125.05,
                1153.75,
                1182.39,
                1210.88,
                1239.29,
                1268.22,
                1296.46,
                1324.51,
                1352.42,
                1380.29,
                1410.94,
                1438.73,
                1466.62,
                1494.44,
                1522.03,
                1549.75,
                1577.32,
                1604.9,
                1632.55,
                1660.56,
                1688.32,
                1716.03,
                1743.59,
                1771.15,
                1798.69,
                1826.36,
                1854.37,
                1882.13,
                1910.04,
                1937.8,
                1965.57,
                1993.55,
                2021.35,
                2049.31,
                2077.1,
                2104.76,
                2132.51,
                2160.19,
                2188.02,
                2216.02,
                2243.89,
                2271.84,
                2299.68,
                2327.3,
                2354.81,
                2382.27,
                2409.68,
                2437.57,
                2467.27,
                2494.84,
                2522.22,
                2549.3,
                2575.97,
                2602.32,
                2628.04,
                2653.32,
                2677.33,
                2700.74,
                2723.52,
                2745.33,
                2766.19,
                2785.99,
                2804.93,
                2823.35,
                2841.79,
                2860.1,
                2878.4,
                2895.83,
                2912.0,
                2927.02,
                2940.65,
                2953.45,
                2963.27,
                2969.59,
                2975.54,
                2981.04,
                2985.76,
                2989.64,
                2993.39,
                2996.48,
                2999.05,
                3000.88,
                3002.0,
                3003.0,
                3003.89,
                3004.44,
                3004.75,
                3005.0,
                3005.26,
                3005.55,
                3005.86,
                3006.18,
                3006.39,
                3006.55,
                3006.79,
                3006.93,
                3006.83,
                3006.62,
                3006.4,
                3006.18,
                3005.98,
                3005.86,
                3005.81,
                3005.72,
                3005.56,
                3005.36,
                3005.1,
                3004.81,
                3004.49,
                3004.28,
                3004.18,
                3004.12,
                3004.05,
                3003.95,
                3003.86,
                3003.79,
                3003.74,
                3003.72,
                3003.72,
                3003.7,
                3003.71,
                3003.74,
                3003.79,
                3003.76,
                3003.63,
                3003.45,
                3003.25,
                3003.22,
                3003.38,
                3003.58,
                3003.76,
                3003.94,
                3004.12,
                3004.29,
                3004.37,
                3004.31,
                3004.17,
                3004.01,
                3003.84,
                3003.71,
                3003.67,
                3003.76,
                3004.01,
                3004.35,
                3004.61,
                3004.68,
                3004.65,
                3004.5,
            ],
        }
        md1 = 446.7135689410393
        md2 = 517.2861392741102
        well_trajectory = traj.Trajectory(inclinometry)
        self.assertTrue(well_trajectory.calc_angle(md1, md2))

    def test_example(self):
        """
        Trajectory: Тестирование работоспособности примера
        """
        file_path = os.path.abspath(sys.modules[traj.Trajectory.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples"):]

        self.assertEqual(exs.TRAJ, example_string)

        inclinometry = pd.DataFrame(
            columns=["MD", "TVD"],
            data=[[0, 0], [1400, 1400], [1800, 1542.85], [2000, 1700]],
        )
        trajectory = traj.Trajectory(inclinometry)
        tvd = trajectory.calc_tvd(1000)
        self.assertEqual(tvd, 1000)


if __name__ == "__main__":
    unittest.main()
