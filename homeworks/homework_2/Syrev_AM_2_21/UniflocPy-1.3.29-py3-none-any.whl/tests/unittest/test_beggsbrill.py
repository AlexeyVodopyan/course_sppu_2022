import unittest

import numpy as np

import unifloc.pipe._beggsbrill as bb 


class TestBeggsBrill(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        self.d = 0.126
        self.beggsbrill = bb.BeggsBrill(self.d)
        self.eps_m = 0.0001
        self.sigma_l_nm = 5.16443138806286e-02
        self.c_calibr_grav = 1
        self.c_calibr_fric = 1
        self.init_datasets = {
            1: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 20 / 86400,
                "qg_rc_m3day": 2000 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            2: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 0,
                "qg_rc_m3day": 0,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            3: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 10 / 86400,
                "qg_rc_m3day": 10000 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            4: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 100 / 86400,
                "qg_rc_m3day": 200 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            5: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 300 / 86400,
                "qg_rc_m3day": 600 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            "np.NAN": {
                "theta_deg": np.NAN,
                "eps_m": np.NAN,
                "ql_rc_m3day": np.NAN,
                "qg_rc_m3day": np.NAN,
                "mul_rc_cp": np.NAN,
                "mug_rc_cp": np.NAN,
                "sigma_l_nm": np.NAN,
                "rho_lrc_kgm3": np.NAN,
                "rho_grc_kgm3": np.NAN,
                "c_calibr_grav": np.NAN,
                "c_calibr_fric": np.NAN,
            },
        }
        print(self.shortDescription())

    def test_bb_1(self):
        """
        BeggsBrill: Расчет всех параметров для набора исходных данных № 1 с Qж = 20 м3/сут,
        Qг = 2000 м3/сут, угол = 90,
        для режима потока = расслоенный
        """

        self.beggsbrill.calc_grad(**self.init_datasets[1])

        self.assertAlmostEqual(self.beggsbrill.dp_dl, 1602.821088643234, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsl, 0.018564586868460426, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsg, 1.8564586868460429, places=5)
        self.assertAlmostEqual(self.beggsbrill.fp, 0, places=5)
        self.assertAlmostEqual(self.beggsbrill.ll, 0.009900990099009901, places=5)
        self.assertAlmostEqual(
            self.beggsbrill.ff, 0.024805146300933015, places=5
        )
        self.assertAlmostEqual(self.beggsbrill.dp_dl_gr, 1593.2272759499167, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl_fr, 9.593812693317195, places=7)
        self.assertAlmostEqual(self.beggsbrill.n_fr, 2.8442893362547554, places=7)
        self.assertAlmostEqual(
            self.beggsbrill.hl, 0.18257498574844044, places=7
        )

    def test_bb_2(self):
        """
        BeggsBrill: Расчет всех параметров для набора исходных данных № 2 с Qж = 0 м3/сут
         Qг = 0 м3/сут, угол = 90
        """

        self.beggsbrill.calc_grad(**self.init_datasets[2])

        self.assertAlmostEqual(self.beggsbrill.dp_dl, 7848.0, places=5)
        self.assertEqual(self.beggsbrill.vsl, 0)
        self.assertEqual(self.beggsbrill.vsg, 0)
        self.assertEqual(self.beggsbrill.fp, 0)
        self.assertEqual(self.beggsbrill.ll, 0)
        self.assertEqual(self.beggsbrill.ff, 0)
        self.assertAlmostEqual(self.beggsbrill.dp_dl_gr, 7848.0, places=5)
        self.assertEqual(self.beggsbrill.dp_dl_fr, 0)
        self.assertEqual(self.beggsbrill.n_fr, 0)
        self.assertEqual(self.beggsbrill.hl, 1)

    def test_bb_3(self):
        """
        BeggsBrill: Расчет всех параметров для набора исходных данных № 3 с Qж = 10 м3/сут
         Qг = 10000 м3/сут,
        угол = 90, для режима потока = распределенный
        """

        self.beggsbrill.calc_grad(**self.init_datasets[3])

        self.assertAlmostEqual(self.beggsbrill.dp_dl, 535.0648703760878, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsl, 0.009282293434230213, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsg, 9.282293434230215, places=5)
        self.assertAlmostEqual(self.beggsbrill.fp, 2, places=5)
        self.assertAlmostEqual(self.beggsbrill.ll, 0.000999000999000999, places=5)
        self.assertAlmostEqual(
            self.beggsbrill.ff, 0.03299245282120796, places=5
        )
        self.assertAlmostEqual(self.beggsbrill.dp_dl_gr, 300.19783676276, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl_fr, 234.86703361332778, places=7)
        self.assertAlmostEqual(self.beggsbrill.n_fr, 69.8456219786443, places=7)
        self.assertAlmostEqual(
            self.beggsbrill.hl, 0.013591290515010847, places=7
        )

    def test_bb_4(self):
        """
        BeggsBrill: Расчет всех параметров для набора исходных данных № 4 с Qж = 100 м3/сут,
        Qг = 200 м3/сут, угол = 90,
        для режима потока = переходный
        """

        self.beggsbrill.calc_grad(**self.init_datasets[4])

        self.assertAlmostEqual(self.beggsbrill.fp, 3, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl, 6954.399845799097, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsl, 0.09282293434230214, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsg, 0.18564586868460428, places=5)
        self.assertAlmostEqual(self.beggsbrill.ll, 0.3333333333333333, places=5)
        self.assertAlmostEqual(
            self.beggsbrill.ff, 0.03303538646725336, places=5
        )
        self.assertAlmostEqual(self.beggsbrill.dp_dl_gr, 6951.553484810533, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl_fr, 2.8463609885649936, places=7)
        self.assertAlmostEqual(self.beggsbrill.n_fr, 0.06273552599326732, places=7)
        self.assertAlmostEqual(
            self.beggsbrill.hl, 0.8828450148736939, places=7
        )

    def test_bb_5(self):
        """
        BeggsBrill: Расчет всех параметров для набора исходных данных № 5 с Qж = 100 м3/сут,
        Qг = 200 м3/сут, угол = 90,
        для режима потока = прерывистый
        """

        self.beggsbrill.calc_grad(**self.init_datasets[5])

        self.assertAlmostEqual(self.beggsbrill.fp, 1, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl, 3868.3031601360262, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsl, 0.2784688030269064, places=5)
        self.assertAlmostEqual(self.beggsbrill.vsg, 0.5569376060538128, places=5)
        self.assertAlmostEqual(self.beggsbrill.ll, 0.3333333333333333, places=5)
        self.assertAlmostEqual(
            self.beggsbrill.ff, 0.03152814582757646, places=5
        )
        self.assertAlmostEqual(self.beggsbrill.dp_dl_gr, 3843.854699097763, places=5)
        self.assertAlmostEqual(self.beggsbrill.dp_dl_fr, 24.448461038263346, places=7)
        self.assertAlmostEqual(self.beggsbrill.n_fr, 0.5646197339394057, places=7)
        self.assertAlmostEqual(
            self.beggsbrill.hl, 0.4767054417389063, places=7
        )

    def test_bb_nan(self):
        """
        BeggsBrill: Расчет всех параметров для np.NAN
        """

        self.beggsbrill.calc_grad(**self.init_datasets["np.NAN"])

        self.assertTrue(np.isnan(self.beggsbrill.dp_dl))
        self.assertTrue(np.isnan(self.beggsbrill.vsl))
        self.assertTrue(np.isnan(self.beggsbrill.vsg))
        self.assertTrue(np.isnan(self.beggsbrill.ll))
        self.assertTrue(np.isnan(self.beggsbrill.ff))
        self.assertTrue(np.isnan(self.beggsbrill.dp_dl_gr))
        self.assertTrue(np.isnan(self.beggsbrill.dp_dl_fr))
        self.assertTrue(np.isnan(self.beggsbrill.n_fr))
        self.assertTrue(np.isnan(self.beggsbrill.hl))


if __name__ == "__main__":
    unittest.main()
