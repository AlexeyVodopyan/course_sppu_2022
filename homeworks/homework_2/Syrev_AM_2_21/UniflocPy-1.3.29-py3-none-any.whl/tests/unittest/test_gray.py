import unittest
from numpy import NAN, isnan
from unifloc.pipe._gray import Gray


class TestGray(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        self.d = 0.126
        self.gray = Gray(self.d)
        self.eps_m = 0.0001
        self.sigma_l_nm = 5.16443138806286e-02
        self.c_calibr_grav = 1
        self.c_calibr_fric = 1
        self.init_datasets = {
            1: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 20 / 86400,
                "qg_rc_m3day": 2000 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            2: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 0,
                "qg_rc_m3day": 0,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
            },
            "NaN": {
                "theta_deg": NAN,
                "eps_m": NAN,
                "ql_rc_m3day": NAN,
                "qg_rc_m3day": NAN,
                "mul_rc_cp": NAN,
                "mug_rc_cp": NAN,
                "sigma_l_nm": NAN,
                "rho_lrc_kgm3": NAN,
                "rho_grc_kgm3": NAN,
                "c_calibr_grav": NAN,
                "c_calibr_fric": NAN,
            },
        }
        print(self.shortDescription())

    def test_gray_1(self):
        """
        Gray: Расчет всех параметров для набора исходных данных № 1 c Qж = 20, Qг = 2000
        """
        self.gray.calc_grad(**self.init_datasets[1])
        self.assertAlmostEqual(self.gray.dp_dl, 721.725352764069, places=5)
        self.assertAlmostEqual(self.gray.vsl, 0.018564586868460426, places=5)
        self.assertAlmostEqual(self.gray.vsg, 1.8564586868460429, places=5)
        self.assertAlmostEqual(self.gray.ff, 0.11260481978033558, places=5)
        self.assertAlmostEqual(self.gray.dp_dl_gr, 678.1735213726677, places=5)
        self.assertAlmostEqual(self.gray.dp_dl_fr, 43.55183139140139, places=7)
        self.assertAlmostEqual(self.gray.hl, 0.06298825392360852, places=7)

    def test_gray_2(self):
        """
        Gray: Расчет всех параметров для набора исходных данных № 2 c Qж = 0, Qг = 0
        """
        self.gray.calc_grad(**self.init_datasets[2])
        self.assertAlmostEqual(self.gray.dp_dl, 196.20000000000002, places=5)
        self.assertAlmostEqual(self.gray.vsl, 0, places=5)
        self.assertAlmostEqual(self.gray.vsg, 0, places=5)
        self.assertAlmostEqual(self.gray.ff, 1, places=5)
        self.assertAlmostEqual(self.gray.dp_dl_gr, 196.20000000000002, places=5)
        self.assertAlmostEqual(self.gray.dp_dl_fr, 0, places=7)
        self.assertAlmostEqual(self.gray.hl, 0, places=7)

    def test_gray_nan(self):
        """
        Gray: Расчет всех параметров для NaN
        """
        self.gray.calc_grad(**self.init_datasets["NaN"])
        self.assertTrue(isnan(self.gray.dp_dl))
        self.assertTrue(isnan(self.gray.vsl))
        self.assertTrue(isnan(self.gray.vsg))
        self.assertTrue(isnan(self.gray.ff))
        self.assertTrue(isnan(self.gray.dp_dl_gr))
        self.assertTrue(isnan(self.gray.dp_dl_fr))
        self.assertTrue(isnan(self.gray.hl))


if __name__ == "__main__":
    unittest.main()
