import ast
import os
import sys
import unittest

import tests.unittest.example_strings as exs
from unifloc.equipment import gl_system as gl
from unifloc.equipment import gl_valve as gl_vl


class TestGlSystem(unittest.TestCase):
    def setUp(self) -> None:
        self.equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1000,
                    "d": 0.006,
                    "p_valve": 3 * 101325,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        self.equipment_data_new = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1300,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": 50 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": 60 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": 40 * 101325,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": 50 * 101325,
                    "valve_type": "ЦКсОК",
                },
            },
        }
        self.gl_system = gl.GlSystem(self.equipment_data["gl_system"])
        self.gl_system_new = gl.GlSystem(self.equipment_data_new["gl_system"])
        print(self.shortDescription())

    def test_working_valve(self):
        """
        GlSystem: тестирование определения рабочего клапана
        """
        self.assertEqual(self.gl_system.h_mes_work, 1000)

    def test_set_q_inj(self):
        """
        GlSystem: установка расхода газлифтного газа
        """
        self.gl_system.q_inj = 1000
        self.assertEqual(self.gl_system.q_inj, 1000)

    def test_calc_dome_charge_pressure(self):
        """
        GlSystem: Расчет давления зарядки сильфона в рабочих условиях
        """
        p_d = self.gl_system_new.valve_working.dome_charge_pressure()

        self.assertAlmostEqual(p_d, 4886904.301658124, delta=1000)

    def test_calc_close_pressure(self):
        """
        GlSystem: Расчет давления закрытия клапана
        """
        p_d = self.gl_system_new.valve_working.dome_charge_pressure()
        p_close = self.gl_system_new.valve_working.close_pressure(p_d=p_d)

        self.assertAlmostEqual(p_close, 4886904.301658124, delta=1000)

    def test_calc_open_pressure(self):
        """
        GlSystem: Расчет давления открытия клапана
        """
        p_out = 50 * 101325
        t_out = 303.15

        p_d = self.gl_system_new.valve_working.dome_charge_pressure()
        p_close = self.gl_system_new.valve_working.close_pressure(p_d=p_d)
        p_open = self.gl_system_new.valve_working.open_pressure(
            p_close=p_close, p_out=p_out, t_out=t_out
        )

        self.assertAlmostEqual(p_open, 4880322.449931905, delta=1000)

    def test_calc_valve_status(self):
        """
        GlSystem: Определение статуса клапана
        """
        p_in = 60 * 101325
        t_in = 303.15
        p_out = 50 * 101325
        t_out = 303.15

        p_d = self.gl_system_new.valve_working.dome_charge_pressure()
        p_close = self.gl_system_new.valve_working.close_pressure(p_d=p_d)
        p_open = self.gl_system_new.valve_working.open_pressure(
            p_close=p_close, p_out=p_out, t_out=t_out
        )
        status = self.gl_system_new.valve_working.valve_status(
            p_in=p_in, t_in=t_in, p_out=p_out, p_open=p_open
        )

        self.assertEqual(status, gl_vl.GlValve.RETURN_STATUS.OPEN.name)

    def test_calc_q_gas(self):
        """
        GlSystem: Расчет расхода гл. газа через клапан при известных давлениях на входе и выходе из клапана
        """
        p_in = 60 * 101325
        p_out = 50 * 101325
        t = 303.15
        gamma_gas = 0.6

        result = self.gl_system_new.valve_working.calc_qgas(
            p_in=p_in, p_out=p_out, t=t, gamma_gas=gamma_gas
        )
        self.assertAlmostEqual(result[0], 7344.038461021629 / 86400, delta=0.0001)

    def test_calc_pin_pout(self):
        """
        GlSystem: Расчет давления на входе в клапан при известном расходе гл. газа через клапана и давлении на выходе
        """
        p_out = 50 * 101325
        t = 303.15
        gamma_gas = 0.6
        q_gas = 10000 / 86400

        p_in = self.gl_system_new.valve_working.calc_pt(
            p_mes=p_out, t_mes=t, flow_direction=1, q_gas=q_gas, gamma_gas=gamma_gas
        )
        self.assertAlmostEqual(p_in, 7002700.098946931, delta=1000)

    def test_calc_pout_pin(self):
        """
        GlSystem: Расчета давления на выходе из клапана при известном расходе гл. газа и давлении на входе
        """
        p_in = 70 * 101325
        t = 303.15
        gamma_gas = 0.6
        q_gas = 10000 / 86400

        p_out = self.gl_system_new.valve_working.calc_pt(
            p_mes=p_in, t_mes=t, flow_direction=-1, q_gas=q_gas, gamma_gas=gamma_gas
        )
        self.assertAlmostEqual(p_out, 5222191.284229289, delta=1000)

    def test_calc_pin_pout_curve(self):
        """
        GlSystem: Расчет давления на входе в клапан при известном расходе гл. газа через клапана и \
        давлении на выходе с помощью метода кривых
        """
        p_out = 50 * 101325
        t = 303.15
        gamma_gas = 0.6
        q_gas = 10000 / 86400

        p_in = self.gl_system_new.valve_working.calc_pt(
            p_mes=p_out,
            t_mes=t,
            flow_direction=1,
            q_gas=q_gas,
            gamma_gas=gamma_gas,
            calc_curve=True,
        )
        self.assertAlmostEqual(p_in, 7068743.532036841, delta=1000)

    def test_calc_pout_pin_curve(self):
        """
        GlSystem: Расчета давления на выходе из клапана при известном расходе гл. газа и давлении \
        на входе с помощью метода кривых
        """
        p_in = 70 * 101325
        t = 303.15
        gamma_gas = 0.6
        q_gas = 10000 / 86400

        p_out = self.gl_system_new.valve_working.calc_pt(
            p_mes=p_in,
            t_mes=t,
            flow_direction=-1,
            q_gas=q_gas,
            gamma_gas=gamma_gas,
            calc_curve=True,
        )
        self.assertAlmostEqual(p_out, 5222036.827340222, delta=1000)

    def test_make_dist(self):
        """
        GlSystem: Формирование распределений для клапана
        """
        h_mes = 1000
        p_in = 60 * 101325
        t_in = 303.15
        p_out = 50 * 101325
        t_out = 303.15

        self.gl_system_new.valve_working.make_dist(
            h_mes=h_mes, p_out=p_out, t_out=t_out, p_in=p_in, t_in=t_in
        )

        self.assertAlmostEqual(len(self.gl_system_new.valve_working.distributions), 3)
        self.assertAlmostEqual(
            len(self.gl_system_new.valve_working.distributions_annulus), 3
        )


if __name__ == "__main__":
    unittest.main()
