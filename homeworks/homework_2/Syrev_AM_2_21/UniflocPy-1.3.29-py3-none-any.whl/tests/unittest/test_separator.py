import ast
import os
import sys
import unittest

from unifloc.equipment.natural_separation import NaturalSeparation
from unifloc.equipment.separator import Separator
from tests.unittest.example_strings import SEP


class TestSeparator(unittest.TestCase):
    def setUp(self) -> None:
        self.sep = Separator(100, 0.3)
        print(self.shortDescription())

    def test_separation(self):
        """
        Separator: расчет общей сепарации без конкретного сепаратора
        """
        self.assertAlmostEqual(self.sep.calc_general_separation(0.7), 0.7899999999999999)

    def test_separation_with_sep(self):
        """
        Separator: расчет общей сепарации с конкретным сепаратором
        """
        self.sep = Separator(100, 0.3, "GSA5-1")
        self.assertAlmostEqual(
            self.sep.calc_general_separation(0.7, 0.8, 65 / 86400, 65), 0.7725509548957223
        )

    def test_separation_with_sepunk(self):
        """
        Separator: расчет общей сепарации с ошибкой в названии сепаратора/сепаратором не из базы
        """
        self.sep = Separator(100, 0.3, "Этовообщенесепаратор5А")
        self.assertAlmostEqual(
            self.sep.calc_general_separation(0.7, 0.8, 65 / 86400, 65), 0.876793978647218
        )

    def test_docstring_example(self):
        """
        Separator: проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[Separator.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)

        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )
        example_string = doc_string[doc_string.find("Examples") :]
        self.maxDiff = None
        self.assertEqual(SEP, example_string)

        # Расчет естественной сепарации
        # Инициализация исходных данных для расчета естественной сепарации
        h_mes_ = 1800
        d_tub = 0.063
        d_cas = 0.130
        q_fluid = 100 / 86400
        q_gas = 0
        sigma_l = 24
        rho_liq = 836
        rho_gas = 0.84

        # Инициализация класса расчета естественной сепарации
        k_sep_nat_calc = NaturalSeparation(h_mes_)
        # Расчет коэффициента естественной сепарации
        k_sep_natural = k_sep_nat_calc.calc_separation(
            d_tub, d_cas, q_fluid, q_gas, sigma_l, rho_liq, rho_gas
        )

        # Инициализация исходных данных для расчета общей сепарации
        k_gas_sep = 0.7
        # Инициализация класса расчета общей сепарации
        k_gassep_calc = Separator(h_mes_, k_gas_sep)
        # Расчет коэффициента общей сепарации
        k_sep_total = k_gassep_calc.calc_general_separation(k_sep_natural)

        self.assertEqual(k_sep_total, 0.9739741546149076)


if __name__ == "__main__":
    unittest.main()
