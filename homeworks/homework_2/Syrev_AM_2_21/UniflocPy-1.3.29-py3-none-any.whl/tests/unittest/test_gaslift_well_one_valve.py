import ast
import copy
import json
import os
import sys
import unittest

import pandas as pd
import numpy.testing as npt

import tests.unittest.example_strings as exs
import unifloc.service._constants as const
import unifloc.tools.units_converter as uc
import unifloc.well.gaslift_well_one_valve as gl_well


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.fluid_data = {
            "q_fluid": 100 / 86400,
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        self.d = {"MD": [0, 1000], "d": [0.062, 0.082]}
        self.pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": self.d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        self.trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1000,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        self.ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        self.gl_well_vl = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )

        print(self.shortDescription())

    def test_gl_valve_calc_pwf_pfl_pinj(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и \
        давления закачки гл.г. при заданном расходе гл.г.
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj
        )
        self.assertAlmostEqual(result[2], 6926977.027769802, delta=1000)
        self.assertAlmostEqual(result[0], 3197699.275495634, delta=1000)

    def test_gl_valve_calc_pwf_pfl_qinj(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г.\
        при заданном давлении закачки гл.г.
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[2], 8219293.578775201, delta=1000)
        self.assertAlmostEqual(result[8], 64136.23882019944 / 86400, delta=0.01)

    def test_gl_valve_calc_pwf_pfl_pinj_choke_1(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и давления закачки гл.г. со штуцером \
        при заданном расходе гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj
        )
        self.assertAlmostEqual(result[2], 12934772.4989543, delta=1000)
        self.assertAlmostEqual(result[0], 7427175.182089607, delta=1000)

    def test_gl_valve_calc_pwf_pfl_qinj_ann_choke_1(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. со штуцером \
        на газовой линии при заданном давлении закачки гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[2], 8084084.11326428, delta=1000)
        self.assertAlmostEqual(result[8], 59603.6626088638 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_double_choke_1(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. с двумя штуцерами \
        при заданном давлении закачки гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[2], 15144521.26014598, delta=1000)
        self.assertAlmostEqual(result[8], 37249.851154969096 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_pinj_choke_2(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и давления закачки гл.г. со штуцером без \
        буферного давления и коэффициента с с_choke = 1.3 при заданном расходе гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, c_choke=1.3
        )
        self.assertAlmostEqual(result[2], 9258572.2627173, delta=1000)
        self.assertAlmostEqual(result[0], 4907004.127426135, delta=1000)

    def test_gl_valve_calc_pwf_pfl_qinj_ann_choke_2(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. со штуцером \
        на газовой линии без затрубного давления и коэффициента с с_ann_choke = 1.3 \
        при заданном давлении закачки гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, c_ann_choke=1.3
        )
        self.assertAlmostEqual(result[2], 8187460.233654691, delta=1000)
        self.assertAlmostEqual(result[8], 63091.3279753423 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_double_choke_2(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. с двумя штуцерами \
        без затрубного давления и коэффициента с с_ann_choke = 1.3 и с_choke = 1.3 \
        при заданном давлении закачки гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            c_choke=1.3,
            c_ann_choke=1.3,
        )
        self.assertAlmostEqual(result[2], 12351393.225489797, delta=1000)
        self.assertAlmostEqual(result[8], 60133.185701924216 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_pinj_choke_adapt(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и давления закачки гл.г. со штуцером, \
        с буферным и адаптацией штуцера при заданном расходе гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, c_choke=None, p_wh=pwh
        )
        self.assertAlmostEqual(result[2], 7604260.475420052, delta=1000)
        self.assertAlmostEqual(result[0], 3682155.7920817207, delta=1000)

    def test_gl_valve_calc_pwf_pfl_ann_choke_adapt(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм со штуцером на \
        газовой линии, с затрубным давлением, давлением закачки гл.г., расходом гл.г. и \
        адаптацией штуцера
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        p_ann = 95 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_choke=None,
            p_ann=p_ann,
        )
        self.assertAlmostEqual(result[2], 6926977.027769802, delta=1000)

    def test_gl_valve_calc_pwf_pfl_double_choke_adapt(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм с двумя штуцерами, \
        с буферным, с затрубным давлением, давлением закачки гл.г., расходом гл.г. \
        и адаптацией штуцера
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        pwh = 15 * 101325
        p_ann = 95 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_choke=None,
            c_ann_choke=None,
            p_ann=p_ann,
            p_wh=pwh,
        )
        self.assertAlmostEqual(result[2], 7604260.475420052, delta=1000)

    def test_gl_valve_calc_pwf_pfl_pinj_choke_const(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и давления закачки гл.г. со штуцером, \
        без буферного и с постоянным перепадом на штуцере при заданном расходе гл.г.
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        pwh = 12 * 101325
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            c_choke={"const": pwh - pfl},
        )
        self.assertAlmostEqual(result[2], 7186223.660752786, delta=1000)
        self.assertAlmostEqual(result[0], 3381852.459659196, delta=1000)

    def test_gl_valve_calc_pwf_pfl_qinj_ann_choke_const(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. со штуцером на \
        газовой линии, без затрубного давления и расхода гл.г., с давлением закачки гл.г. \
        с постоянным перепадом на штуцере
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        p_ann = 95 * 101325
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            c_ann_choke={"const": p_gas_inj - p_ann},
        )
        self.assertAlmostEqual(result[2], 8123912.900158872, delta=1000)
        self.assertAlmostEqual(result[8], 60854.87461907253 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_double_choke_const(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 и расхода гл.г. атм с двумя штуцерами, \
        без буферного, без затрубного давления и расхода гл.г., с давлением закачки гл.г. и \
        с постоянными перепадами на штуцерах
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 70 / 86400
        pwh = 15 * 101325
        p_ann = 97 * 101325
        wct = 0.5
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            c_choke={"const": pwh - pfl},
            c_ann_choke={"const": p_gas_inj - p_ann},
        )

        self.assertAlmostEqual(result[2], 9102769.737924283, delta=1000)
        self.assertAlmostEqual(result[8], 62171.36269579625 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_double_choke_extra(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. с двумя штуцерами \
        при заданном давлении закачки гл.г. с доп. распределениями
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, output_params=True
        )
        self.assertAlmostEqual(result[2], 15144521.26014598, delta=1000)
        self.assertAlmostEqual(result[8], 37249.851154969096 / 86400, delta=0.0001)
        self.assertAlmostEqual(len(gl_well_.extra_output), 47)
        self.assertAlmostEqual(len(gl_well_.extra_output_annulus), 47)

    def test_gl_valve_calc_pwf_pfl_qinj_output1(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм \
        c дополнительными атрибутами при заданном давлении закачки гл.г.
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325

        self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, output_params=True
        )

        self.assertIsInstance(self.gl_well_vl.extra_output, dict)
        self.assertIsInstance(self.gl_well_vl.extra_output_annulus, dict)
        self.assertEqual(len(self.gl_well_vl.extra_output), len(const.DISTRS) + 4)
        self.assertEqual(len(self.gl_well_vl.extra_output_annulus), len(const.DISTRS) + 4)

        for par in const.DISTRS:
            self.assertIsNotNone(self.gl_well_vl.extra_output.get(par))
            if (
                par != "rs"
                and par != "pb"
                and par != "muo"
                and par != "muw"
                and par != "bo"
                and par != "bw"
                and par != "compro"
                and par != "flow_pattern"
                and par != "v_mix_krit"
            ):
                self.assertIsNotNone(self.gl_well_vl.extra_output_annulus.get(par))
            else:
                self.assertIsNone(self.gl_well_vl.extra_output_annulus.get(par))

    def test_gl_valve_calc_pwh_pwf_qinj(self):
        """
        GasLiftWellOneValve: Расчет буферного давления от забойного = 200 атм \
        при заданном давлении закачки гл.г.
        """

        pwf = 200 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        p_gas_inj = 100 * 101325
        result = self.gl_well_vl.calc_pwh_pwf(
            p_wf=pwf, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[0], 8505028.11568878, delta=1000)
        self.assertEqual(result[5], 0)

    def test_gl_valve_calc_pwh_pwf_qinj_before_p_wh(self):
        """
        GasLiftWellOneValve: Расчет буферного давления от забойного для случая \
        не дохода до буфера при заданном давлении закачки гл.г.
        """

        pwf = 50 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        p_gas_inj = 100 * 101325
        pfl = self.gl_well_vl.calc_pwh_pwf(
            p_wf=pwf, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, output_params=True
        )
        self.assertAlmostEqual(pfl[0], 89999.99999999997, delta=1000)
        self.assertEqual(pfl[5], 1)

    def test_gl_valve_extra_annulus_to_json(self):
        """
        GasLiftWellOneValve: Проверка конвертируемости распределений для затруба в Json для случая \
        глубина клапана < глубины НКТ
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, output_params=True
        )

        self.assertIsInstance(json.dumps(self.gl_well_vl.extra_output_annulus), str)

    def test_gl_valve_negative_depth_annulus_calc_pwf_pfl(self):
        """
        GasLiftWellOneValve: Проверка отрицательности массива глубин для затруба при расчете \
        забойного давления при заданном давлении закачки гл.г.
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        self.gl_well_vl.calc_pwf_pfl(p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj)

        self.assertTrue(
            all(
                list(map(lambda x: x <= 0, self.gl_well_vl.extra_output_annulus["depth"]))
            )
        )

    def test_gl_valve_negative_depth_annulus_calc_pwh_pwf(self):
        """
        GasLiftWellOneValve: Проверка отрицательности массива глубин для затруба при расчете \
        буферного давления при заданном давлении закачки гл.г.
        """
        pwf = 200 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        p_gas_inj = 100 * 101325
        self.gl_well_vl.calc_pwh_pwf(p_wf=pwf, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj)

        self.assertTrue(
            all(
                list(map(lambda x: x <= 0, self.gl_well_vl.extra_output_annulus["depth"]))
            )
        )

    def test_gl_valve_extra_annulus_to_json_hvl_eq_htub(self):
        """
        GasLiftWellOneValve: Проверка конвертируемости распределений для затруба в Json для случая
        глубина клапана = глубине НКТ при заданном давлении закачки гл.г.
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1400,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        gl_well_.calc_pwf_pfl(p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj)
        self.assertIsInstance(json.dumps(gl_well_.extra_output_annulus), str)

    def test_gl_valve_test_p_array(self):
        """
        SelfFlowWell: Проверка распределения давления
        """
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            step_length=None,
            output_params=True,
        )
        results = gl_well_.extra_output
        npt.assert_almost_equal(
            results.get("p"),
            [
                1013221.9,
                2071239.04,
                3557341.85,
                4352629.37,
                4438357.77,
                4446995.19,
                4447859.58,
                4447859.58,
                5216006.95,
                6793864.73,
                6950170.31,
                6965784.95,
                6967346.25,
            ],
            decimal=2,
        )

    def test_gl_valve_docstring_example(self):
        """
        GasLiftWellOneValve: Проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(
            sys.modules[gl_well.GasLiftWellOneValve.__module__].__file__
        )

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(example_string, exs.GL_WELL_VL)

        # Инициализация исходных данных
        df = pd.DataFrame(
            columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]]
        )
        # Возможный способ задания инклинометрии через dict
        # df = {"MD": [0, 1000],
        #       "TVD": [0, 900]}
        # В словари с калибровками подается давление и температура калибровки.
        # Зачастую - это давление насыщения и пластовая температура
        fluid_data = {
            "q_fluid": uc.convert_rate(100, "m3/day", "m3/s"),
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "oil_correlations": {
                        "pb": "Standing",
                        "rs": "Standing",
                        "rho": "Standing",
                        "b": "Standing",
                        "mu": "Beggs",
                        "compr": "Vasquez",
                    },
                    "gas_correlations": {
                        "ppc": "Standing",
                        "tpc": "Standing",
                        "z": "Dranchuk",
                        "mu": "Lee",
                    },
                    "water_correlations": {
                        "b": "McCain",
                        "compr": "Kriel",
                        "rho": "Standing",
                        "mu": "McCain",
                    },
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                    "table_model_data": None,
                    "use_table_model": False,
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        well_trajectory_data = {"inclinometry": df}
        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1000,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            }
        }
        ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        # Инициализация объекта скважины
        well = gl_well.GasLiftWellOneValve(
            fluid_data,
            pipe_data,
            well_trajectory_data,
            ambient_temperature_data,
            equipment_data,
        )
        # Расчет линейного давления
        parameters = well.calc_pwh_pwf(
            p_wf=uc.convert_pressure(20, "MPa", "Pa"),
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            p_gas_inj=uc.convert_pressure(15, "MPa", "Pa"),
        )
        # Расчет забойного давления
        p_fl = parameters[0]
        self.assertAlmostEqual(p_fl, 10232778.022334496, delta=1000)

        q_inj = well.gl_system.q_inj
        self.assertAlmostEqual(q_inj, 0.8673107784103471, delta=0.0001)

        p_wf = well.calc_pwf_pfl(
            p_fl=p_fl,
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            q_gas_inj=q_inj,
        )
        # Расчет с сохранением доп. атрибутов распределений свойств
        well.calc_pwf_pfl(
            p_fl=p_fl,
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            q_gas_inj=q_inj,
            output_params=True,
        )
        # Или можно указать что "all", тогда рассчитаются все возможные
        p_wf = well.calc_pwf_pfl(
            p_fl=p_fl,
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            q_gas_inj=q_inj,
            output_params=True,
        )
        # Запрос всех значений доп. свойств в виде словаря
        result = well.extra_output
        result_annulus = well.extra_output_annulus
        self.assertAlmostEqual(p_wf[2], 19999997.0189848, delta=1000)

    def test_gl_valve_nodes_distribution(self):
        """
        GasLiftWellOneValve: Тестирование создания распределения ключевых узлов для затруба
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            step_length=None,
            output_params=True,
        )

        self.assertEqual(
            self.gl_well_vl.extra_output_annulus.get("nodes"),
            ["Затруб", None, None, None, None, "Рабочий газлифтный клапан"],
        )

    def test_gl_valve_calc_pwf_pfl_qinj_recalc_pb(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. \
        c пересчетом давления насыщения при заданном давлении закачки гл.г.
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, recalc_pb=True
        )

        self.assertAlmostEqual(result[2], 8219293.350820484, delta=1000)
        self.assertAlmostEqual(result[8], 64136.23882014809 / 86400, delta=0.0001)
        self.assertAlmostEqual(
            self.gl_well_vl.tubing_upper_point.fluid.rp, 1012.6248757794233, delta=0.01
        )
        self.assertNotEqual(
            self.gl_well_vl.tubing_upper_point.fluid.rp, self.gl_well_vl.fluid.rp
        )

    def test_gl_valve_calc_pwf_pfl_pinj_curve(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и давления закачки гл.г. \
        при заданном расходе гл.г. с помощью метода кривых
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, calc_curve=True
        )

        self.assertAlmostEqual(result[2], 6956944.697993723, delta=1000)
        self.assertAlmostEqual(result[0], 3219249.20378367, delta=1000)

    def test_gl_valve_calc_pwf_pfl_qinj_curve(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. \
        при заданном давлении закачки гл.г. с помощью метода кривых
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, calc_curve=True
        )

        self.assertAlmostEqual(result[2], 8249800.970599178, delta=1000)
        self.assertAlmostEqual(result[8], 64140.15135619228 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_double_choke_curve(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. с двумя штуцерами \
        при заданном давлении закачки гл.г. с помощью метода кривых
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, calc_curve=True
        )
        self.assertAlmostEqual(result[2], 10729147.081348663, delta=1000)
        self.assertAlmostEqual(result[8], 58825.769400732264 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_curve_multipoint(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. \
        при заданном давлении закачки гл.г. с помощью метода кривых (несколько решений)
        """

        pfl = 5 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 150 * 101325
        result = self.gl_well_vl.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, calc_curve=True
        )

        self.assertAlmostEqual(result[2], 9057029.933871197, delta=1000)
        self.assertAlmostEqual(result[8], 96805.17050895233 / 86400, delta=0.0001)

    def test_gl_valve_calc_pwf_pfl_qinj_no_s_wall(self):
        """
        GasLiftWellOneValve: Расчет забойного давления от линейного = 10 атм и расхода гл.г. \
        при заданном давлении закачки гл.г. при не заданном значении толщины стенки НКТ
        """
        pipe_data = {
            "casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001,},
            "tubing": {"bottom_depth": 1400, "d": self.d, "roughness": 0.0001,},
        }
        gl_well_ = gl_well.GasLiftWellOneValve(
            self.fluid_data,
            pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[2], 8218935.014265969, delta=1000)
        self.assertAlmostEqual(result[8], 64124.556456221515 / 86400, delta=0.01)


if __name__ == "__main__":
    unittest.main()
