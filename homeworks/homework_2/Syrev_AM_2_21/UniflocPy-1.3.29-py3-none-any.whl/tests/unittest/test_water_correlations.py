import unittest
from numpy import NAN, isnan

from unifloc.pvt._water_correlations import WaterCorrelations
from unifloc.tools.exceptions import NotImplementedPvtCorrError
from unifloc.service._constants import WAT_CORRS


class TestWaterCorrelations(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов

        Returns
        -------

        """
        self.gamma_wat = 1
        water_correlations = WAT_CORRS.copy()
        self.wat_correlations = WaterCorrelations(water_correlations)
        print(f"Test: {self.shortDescription()}")

    def test_bw_mccain_5_30(self):
        """
        WaterCorrs: Объемный коэффициент воды для корреляции McCain для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        water_correlations = WAT_CORRS.copy()
        correlation = "mccain"
        water_correlations["b"] = correlation
        self.wat_correlations = WaterCorrelations(water_correlations)
        self.assertAlmostEqual(
            self.wat_correlations.calc_water_fvf(t, p), 1.0050320333498315, places=5
        )

    def test_bw_not_implemented_error(self):
        """
        WaterCorrs: Объемный коэффициент воды для нереализованной корреляции LaLaLand
        """
        water_correlations = WAT_CORRS.copy()
        correlation = "LaLaLand"
        water_correlations["b"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.wat_correlations = WaterCorrelations(water_correlations)

    def test_bw_mccain_nan(self):
        """
        WaterCorrs: Объемный коэффициент воды для корреляции McCain для NaN
        """
        p = NAN
        t = NAN
        water_correlations = WAT_CORRS.copy()
        correlation = "mccain"
        water_correlations["b"] = correlation
        self.wat_correlations = WaterCorrelations(water_correlations)
        self.assertTrue(isnan(self.wat_correlations.calc_water_fvf(t, p)))

    def test_rho_wat_standing_5_30(self):
        """
        WaterCorrs: Плотность воды для корреляции Standing для 5 МПа и 303.15 К
        """
        p = 5 * 10 ** 6
        t = 303.15
        bw = 1.01
        water_correlations = WAT_CORRS.copy()
        correlation = "standing"
        water_correlations["rho"] = correlation
        salinity = 1200
        self.wat_correlations = WaterCorrelations(water_correlations)

        self.assertAlmostEqual(
            self.wat_correlations.calc_water_density(
                t, p, self.gamma_wat, bw, salinity
            ),
            990.09900990099,
            places=5,
        )

    def test_rho_wat_not_implemented_error(self):
        """
        WaterCorrs: Плотность воды для нереализованной корреляции LaLaLand
        """
        water_correlations = WAT_CORRS.copy()
        correlation = "LaLaLand"
        water_correlations["rho"] = correlation

        with self.assertRaises(NotImplementedPvtCorrError):
            self.wat_correlations = WaterCorrelations(water_correlations)

    def test_rho_wat_standing_nan(self):
        """
        WaterCorrs: Плотность воды по корреляции Standing для NaN
        """
        p = NAN
        t = NAN
        bw = NAN
        water_correlations = WAT_CORRS.copy()
        correlation = "standing"
        water_correlations["rho"] = correlation
        salinity = NAN
        self.wat_correlations = WaterCorrelations(water_correlations)

        self.assertTrue(
            isnan(
                self.wat_correlations.calc_water_density(
                    t, p, self.gamma_wat, bw, salinity
                )
            )
        )

    def test_salinity(self):
        """
        WaterCorrs: Соленость воды для 1000 кг/м3
        """
        self.assertAlmostEqual(
            self.wat_correlations.calc_salinity(self.gamma_wat),
            1363.1482481105195,
            places=5,
        )

    def test_wat_compr_kriel_5_30(self):
        """
        WaterCorrs: Сжимаемость воды по корреляции Kriel для 5 МПа и 303.15 К
        """
        t = 5 * 10 ** 6
        p = 303.15
        salinity = 1200
        water_correlations = WAT_CORRS.copy()
        correlation = "kriel"
        water_correlations["compr"] = correlation
        self.wat_correlations = WaterCorrelations(water_correlations)

        self.assertAlmostEqual(
            self.wat_correlations.calc_water_compressibility(t, p, salinity),
            1.5184447406454814e-11,
            places=5,
        )

    def test_muw_mccain_5_30(self):
        """
        WaterCorrs: Вязкость воды по методике McCain для 5 МПа и 303.15 K
        """
        t = 303.15
        p = 30 * 10 ** 6
        salinity = 1200
        water_correlations = WAT_CORRS.copy()
        correlation = "mccain"
        water_correlations["mu"] = correlation
        self.wat_correlations = WaterCorrelations(water_correlations)
        self.assertAlmostEqual(
            self.wat_correlations.calc_water_viscosity(t, p, salinity),
            0.9185863054493262,
            places=5,
        )

    def test_muw_not_implemented_error(self):
        """
        WaterCorrs: Вязкость воды по нереализованной методике LaLaLand
        """
        water_correlations = WAT_CORRS.copy()
        correlation = "LaLaLand"
        water_correlations["mu"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.wat_correlations = WaterCorrelations(water_correlations)

    def test_muw_mccain_nan(self):
        """
        WaterCorrs: Вязкость воды по McCain для NaN
        """
        t = NAN
        p = NAN
        salinity = NAN
        water_correlations = WAT_CORRS.copy()
        correlation = "mccain"
        water_correlations["mu"] = correlation
        self.wat_correlations = WaterCorrelations(water_correlations)
        self.assertTrue(
            isnan(self.wat_correlations.calc_water_viscosity(t, p, salinity))
        )

    def test_exception_detail(self):
        """
        WaterCorrs: Вязкость воды тестирование сохранения нереализованной корреляции в контекст ошибки
        """
        water_correlations = WAT_CORRS.copy()
        correlation = "LaLaLand"
        water_correlations["mu"] = correlation

        try:
            self.wat_correlations = WaterCorrelations(water_correlations)
        except NotImplementedPvtCorrError as e:
            print(e.detail)
            self.assertEqual(e.detail, correlation)


if __name__ == "__main__":
    unittest.main()
