import ast
import copy
import json
import os
import sys
import unittest

import pandas as pd

import tests.unittest.example_strings as exs
import unifloc.service._constants as const
import unifloc.tools.units_converter as uc
import unifloc.well.gaslift_well_several_valves as gl_well


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.fluid_data = {
            "q_fluid": 100 / 86400,
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        self.d = {"MD": [0, 1000], "d": [0.062, 0.082]}
        self.pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": self.d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        self.trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.equipment_data_new = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1300,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": uc.convert_pressure(60, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(40, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            },
        }
        self.ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        self.gl_well_vls = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data_new,
        )
        print(self.shortDescription())

    def test_gl_valves_calc_pwf_pfl(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм (гл. скв. с несколькими клапанами)
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = self.gl_well_vls.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, p_gas_inj=p_gas_inj
        )

        self.assertAlmostEqual(result[2], 6990405.073906656, delta=1000)

    def test_gl_valves_calc_pwf_pfl_choke(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером \
        (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, p_gas_inj=p_gas_inj
        )

        self.assertAlmostEqual(result[2], 13144715.993175277, delta=1000)

    def test_gl_valves_calc_pwf_pfl_ann_choke(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером на газ. линии \
        (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, p_gas_inj=p_gas_inj
        )

        self.assertAlmostEqual(result[2], 6990405.073906656, delta=1000)

    def test_gl_valves_calc_pwf_pfl_double_choke(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм с двумя штуцерами
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, p_gas_inj=p_gas_inj
        )

        self.assertAlmostEqual(result[2], 13144715.993175277, delta=1000)

    def test_gl_valves_calc_pwf_pfl_choke_coeff(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером \
        и c_choke = 1.3 (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_choke=1.3,
        )

        self.assertAlmostEqual(result[2], 9374537.900899751, delta=1000)

    def test_gl_valves_calc_pwf_pfl_ann_choke_coeff(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером на \
        газ. линии и c_ann_choke = 1.3 (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_ann_choke=1.3,
        )

        self.assertAlmostEqual(result[2], 6990405.073906656, delta=1000)

    def test_gl_valves_calc_pwf_pfl_double_choke_coeff(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм с двумя штуцерами \
        и c_choke = 1.3, c_ann_choke = 1.3 (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_choke=1.3,
            c_ann_choke=1.3,
        )

        self.assertAlmostEqual(result[2], 9374537.900899751, delta=1000)

    def test_gl_valves_calc_pwf_pfl_choke_adapt(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером \
        и без коэффициента (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            p_wh=pwh,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_choke=None,
        )

        self.assertAlmostEqual(result[2], 7681295.468123101, delta=1000)

    def test_gl_valves_calc_pwf_pfl_ann_choke_adapt(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм со штуцером \
        на газ. линии и без коэффициента (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        p_ann = 95 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            p_ann=p_ann,
            c_ann_choke=None,
        )

        self.assertAlmostEqual(result[2], 6990405.073906656, delta=1000)

    def test_gl_valves_calc_pwf_pfl_double_choke_adapt(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм с двумя штуцерами \
        и без коэффициентов (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        p_ann = 95 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            p_wh=pwh,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            p_ann=p_ann,
            c_ann_choke=None,
            c_choke=None,
        )

        self.assertAlmostEqual(result[2], 7681295.468123101, delta=1000)

    def test_gl_valves_calc_pwf_pfl_double_choke_const(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм с двумя штуцерами \
        и постоянными перепадами (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["choke"] = {"d": 0.01}
        equipment_data["ann_choke"] = {"d": 0.01}

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        p_ann = 95 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            c_ann_choke={"const": p_gas_inj - p_ann},
            c_choke={"const": pwh - pfl},
        )

        self.assertAlmostEqual(result[2], 7679404.670816864, delta=1000)

    def test_gl_valves_calc_pwf_pfl_double_choke_extra(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм с двумя штуцерами \
        с доп. распределениями (гл. скв. с несколькими клапанами)
        """

        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            output_params=True,
        )
        self.assertAlmostEqual(result[2], 13144715.993175277, delta=1000)
        self.assertAlmostEqual(len(gl_well_.extra_output), 48)
        self.assertAlmostEqual(len(gl_well_.extra_output_annulus), 47)

    def test_gl_valves_calc_pwf_pfl_output(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм \
        c дополнительными атрибутами (гл. скв. с несколькими клапанами)
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400

        self.gl_well_vls.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            q_gas_inj=q_gas_inj,
            output_params=True,
        )

        self.assertIsInstance(self.gl_well_vls.extra_output, dict)
        self.assertIsInstance(self.gl_well_vls.extra_output_annulus, dict)
        self.assertEqual(len(self.gl_well_vls.extra_output), len(const.DISTRS) + 5)
        self.assertEqual(
            len(self.gl_well_vls.extra_output_annulus), len(const.DISTRS) + 4
        )

        for par in const.DISTRS:
            self.assertIsNotNone(self.gl_well_vls.extra_output.get(par))
            if (
                par != "rs"
                and par != "pb"
                and par != "muo"
                and par != "muw"
                and par != "bo"
                and par != "bw"
                and par != "compro"
                and par != "flow_pattern"
            ):
                self.assertIsNotNone(self.gl_well_vls.extra_output_annulus.get(par))
            else:
                self.assertFalse(all(self.gl_well_vls.extra_output_annulus.get(par)))

        self.assertTrue(
            True
            in [
                self.gl_well_vls.extra_output["valves"][i]["status"] == "OPEN_work"
                for i in range(len(self.gl_well_vls.extra_output["valves"]))
            ]
        )

    def test_gl_valves_extra_to_json(self):
        """
        GasLiftWellSeveralValves: Проверка конвертируемости распределений для НКТ и затруба в Json \
        (гл. скв. с несколькими клапанами)
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400

        self.gl_well_vls.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            q_gas_inj=q_gas_inj,
            output_params=True,
        )

        self.assertIsInstance(json.dumps(self.gl_well_vls.extra_output), str)
        self.assertIsInstance(json.dumps(self.gl_well_vls.extra_output_annulus), str)

    def test_gl_valves_negative_depth_calc_pwf_pfl(self):
        """
        GasLiftWellSeveralValves: Проверка отрицательности массива глубин при расчете забойного давления \
        (гл. скв. с несколькими клапанами)
        """

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400

        self.gl_well_vls.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, q_gas_inj=q_gas_inj
        )

        self.assertTrue(
            all(
                list(
                    map(
                        lambda x: x <= 0, self.gl_well_vls.extra_output_annulus["depth"]
                    )
                )
            )
        )
        self.assertTrue(
            all(list(map(lambda x: x <= 0, self.gl_well_vls.extra_output["depth"])))
        )

    def test_gl_valves_extra_to_json_hvl_eq_htub(self):
        """
        GasLiftWellSeveralValves: Проверка конвертируемости распределений в Json для случая, когда \
        глубина одного из клапанов = глубине НКТ (гл. скв. с несколькими клапанами)
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1400,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": uc.convert_pressure(60, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(40, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            },
        }

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, p_gas_inj=p_gas_inj, q_gas_inj=q_gas_inj
        )
        self.assertIsInstance(json.dumps(gl_well_.extra_output), str)
        self.assertIsInstance(json.dumps(gl_well_.extra_output_annulus), str)

    def test_gl_valves_nodes_distribution(self):
        """
        GasLiftWellSeveralValves: Тестирование создания распределений ключевых узлов для НКТ и затруба \
        (гл. скв. с несколькими клапанами)
        """
        equipment_data = copy.deepcopy(self.equipment_data_new)
        equipment_data["ann_choke"] = {"d": 0.01}
        equipment_data["choke"] = {"d": 0.01}
        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400

        gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            p_gas_inj=p_gas_inj,
            q_gas_inj=q_gas_inj,
            output_params=True,
            step_length=None,
        )

        self.assertEqual(
            gl_well_.extra_output.get("nodes"),
            [
                "Линия",
                None,
                "Буфер",
                None,
                None,
                None,
                None,
                "Рабочий газлифтный клапан 1",
                None,
                None,
                "Газлифтный клапан 2",
                None,
                "Газлифтный клапан 3",
                "Газлифтный клапан 4",
                None,
                None,
                None,
                "Башмак НКТ",
                None,
                None,
                None,
                None,
                None,
                "Верхние дыры перфорации",
            ],
        )
        self.assertEqual(
            gl_well_.extra_output_annulus.get("nodes"),
            [
                "Газовая линия",
                None,
                "Затруб",
                None,
                None,
                None,
                None,
                "Рабочий газлифтный клапан 1",
                "Газлифтный клапан 2",
                "Газлифтный клапан 3",
                "Газлифтный клапан 4",
                None,
            ],
        )

    def test_gl_valves_docstring_example(self):
        """
        GasLiftWellSeveralValves: Проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(
            sys.modules[gl_well.GasLiftWellSeveralValves.__module__].__file__
        )

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(example_string, exs.GL_WELL_VLS)

        # Инициализация исходных данных
        df = pd.DataFrame(
            columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]]
        )
        # Возможный способ задания инклинометрии через dict
        # df = {"MD": [0, 1000],
        #       "TVD": [0, 900]}
        # В словари с калибровками подается давление и температура калибровки.
        # Зачастую - это давление насыщения и пластовая температура
        fluid_data = {
            "q_fluid": uc.convert_rate(100, "m3/day", "m3/s"),
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "oil_correlations": {
                        "pb": "Standing",
                        "rs": "Standing",
                        "rho": "Standing",
                        "b": "Standing",
                        "mu": "Beggs",
                        "compr": "Vasquez",
                    },
                    "gas_correlations": {
                        "ppc": "Standing",
                        "tpc": "Standing",
                        "z": "Dranchuk",
                        "mu": "Lee",
                    },
                    "water_correlations": {
                        "b": "McCain",
                        "compr": "Kriel",
                        "rho": "Standing",
                        "mu": "McCain",
                    },
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                    "table_model_data": None,
                    "use_table_model": False,
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        well_trajectory_data = {"inclinometry": df}
        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1300,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": uc.convert_pressure(60, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(40, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            },
        }
        ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        # Инициализация объекта скважины
        well = gl_well.GasLiftWellSeveralValves(
            fluid_data,
            pipe_data,
            well_trajectory_data,
            ambient_temperature_data,
            equipment_data,
        )

        # Расчет забойного давления
        p_fl = 10 * 101325
        q_inj = 100 / 86400
        p_inj = 100 * 101325

        p_wf = well.calc_pwf_pfl(
            p_fl=p_fl,
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            q_gas_inj=q_inj,
            p_gas_inj=p_inj,
        )
        # Расчет с сохранением доп. атрибутов распределений свойств
        well.calc_pwf_pfl(
            p_fl=p_fl,
            q_liq=uc.convert_rate(100, "m3/day", "m3/s"),
            wct=0.1,
            q_gas_inj=q_inj,
            p_gas_inj=p_inj,
            output_params=True,
        )
        # Запрос всех значений доп. свойств в виде словаря
        result = well.extra_output
        result_annulus = well.extra_output_annulus
        self.assertAlmostEqual(p_wf[2], 7467940.7625692, delta=1000)

    def test_gl_valves_calc_pwf_pfl_no_s_wall(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм \
        при не заданном значении толщины стенки НКТ
        """
        pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": self.d,
                "roughness": 0.0001,
            },
        }
        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data_new,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 100 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl, q_liq=q_liq, wct=wct, q_gas_inj=q_gas_inj, p_gas_inj=p_gas_inj
        )
        self.assertAlmostEqual(result[2], 6990405.073906656, delta=1000)

    def test_gl_valves_calc_pwf_pfl_all_valves_closed(self):
        """
        GasLiftWellSeveralValves: Расчет забойного давления от линейного = 10 атм \
        Все клапаны закрыты.
        """

        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1300,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": uc.convert_pressure(90, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": uc.convert_pressure(90, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(90, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(90, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            },
        }

        gl_well_ = gl_well.GasLiftWellSeveralValves(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )

        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        p_gas_inj = 50 * 101325
        q_gas_inj = 10000 / 86400
        result = gl_well_.calc_pwf_pfl(
            p_fl=pfl,
            q_liq=q_liq,
            wct=wct,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            output_params=True,
            step_length=None,
        )
        self.assertAlmostEqual(result[2], 6959399.611450702, delta=1000)
        self.assertAlmostEqual(result[8], 0, delta=0.0001)
        self.assertFalse(
            True
            in [
                gl_well_.extra_output["valves"][i]["status"] == "OPEN_work"
                for i in range(len(gl_well_.extra_output["valves"]))
            ]
        )
        self.assertFalse(
            True
            in [
                gl_well_.extra_output["valves"][i]["status"] == "OPEN"
                for i in range(len(gl_well_.extra_output["valves"]))
            ]
        )
        self.assertIsNone(gl_well_.gl_system.valve_working)

        self.assertEqual(
            gl_well_.extra_output.get("nodes"),
            [
                "Буфер",
                None,
                "Газлифтный клапан 1",
                "Газлифтный клапан 2",
                None,
                "Газлифтный клапан 3",
                None,
                None,
                None,
                "Газлифтный клапан 4",
                None,
                None,
                None,
                None,
                None,
                "Башмак НКТ",
                None,
                None,
                None,
                None,
                None,
                "Верхние дыры перфорации",
            ],
        )
        self.assertEqual(
            gl_well_.extra_output_annulus.get("nodes"),
            [
                "Затруб",
                None,
                None,
                None,
                None,
                "Газлифтный клапан 1",
                "Газлифтный клапан 2",
                "Газлифтный клапан 3",
                "Газлифтный клапан 4",
                None,
            ],
        )


if __name__ == "__main__":
    unittest.main()
