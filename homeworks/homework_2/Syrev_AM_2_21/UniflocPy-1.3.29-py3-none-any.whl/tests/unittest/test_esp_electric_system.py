import ast
import os
import sys
import unittest

from tests.unittest.example_strings import ESP_ELECTRIC_SYSTEM
from unifloc.equipment.esp_electric_system import EspElectricSystem
from unifloc.tools import common_calculations as com


class TestEspElectricSystem(unittest.TestCase):
    def setUp(self) -> None:
        self.motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }

        self.electric_data = {
            "motor_data": self.motor_data,
            "pump_nom_freq": 50,
            "gassep_nom_power": 500,
            "protector_nom_power": 500,
            "transform_eff": 0.97,
            "cs_eff": 0.97,
            "cable_specific_resistance": 1.18,
            "cable_length": 2500,
        }

        self.pump_power = 40000
        self.fluid_power = 20000
        self.freq = 55
        self.t_cable = 303.15

        self.esp_electric_system = EspElectricSystem(**self.electric_data)
        print(self.shortDescription())

    def test_calc(self):
        """
        EspElectricSystem: Расчет электрических параметров
        """
        results = self.esp_electric_system.calc_electric_esp_system(
            self.pump_power,
            self.fluid_power,
            self.freq,
            self.t_cable,
        )

        self.assertAlmostEqual(0.46362511483154917, results["load"], delta=0.01)
        self.assertAlmostEqual(665.5000000000002, results["gassep_power"], delta=0.01)
        self.assertAlmostEqual(550.0, results["protector_power"], delta=0.01)
        self.assertAlmostEqual(40000, results["pump_power"], delta=0.01)
        self.assertAlmostEqual(50769.724640870816, results["motor_power"], delta=0.01)
        self.assertAlmostEqual(2490.086360611172, results["motor_voltage"], delta=0.01)
        self.assertAlmostEqual(16.22687901910422, results["motor_i"], delta=0.01)
        self.assertAlmostEqual(3.0068170000000003, results["cable_resistance"], delta=0.01)
        self.assertAlmostEqual(2574.5928154689987, results["transform_voltage"], delta=0.01)
        self.assertAlmostEqual(54739.26147228636, results["transform_power"], delta=0.01)
        self.assertAlmostEqual(56381.43931645495, results["cs_power"], delta=0.01)
        self.assertAlmostEqual(0.35472666612402337, results["esp_system_efficiency"], delta=0.01)

    def test_calc_esp_power_0(self):
        """
        EspElectricSystem: Расчет электрических параметров, мощность эцн = 0 и гидравлическая мощность = 0
        """
        self.pump_power = 0
        self.fluid_power = 0

        results = self.esp_electric_system.calc_electric_esp_system(
            self.pump_power,
            self.fluid_power,
            self.freq,
            self.t_cable,
        )

        self.assertEqual(0, results["load"])
        self.assertEqual(0, results["gassep_power"])
        self.assertEqual(0, results["protector_power"])
        self.assertEqual(0, results["pump_power"])
        self.assertEqual(0, results["motor_power"])
        self.assertEqual(0, results["motor_voltage"])
        self.assertEqual(0, results["motor_i"])
        self.assertAlmostEqual(3.0068170000000003, results["cable_resistance"], delta=0.01)
        self.assertEqual(0, results["transform_voltage"])
        self.assertEqual(0, results["transform_power"])
        self.assertEqual(0, results["cs_power"])
        self.assertEqual(0, results["esp_system_efficiency"])

    def test_calc_with_adaptation(self):
        """
        EspElectricSystem: Расчет электрических параметров c включенной адаптацией
        """
        electric_adaptation = {
            "cosf_fact": 0.83,
            "motor_i_fact": 35,
            "load_fact": 0.7,
            "transform_voltage_fact": 2800,
            "cs_power_fact": 100000,
        }

        coeff = com.adapt_elsys(
            self.esp_electric_system,
            self.pump_power,
            self.fluid_power,
            self.freq,
            self.t_cable,
            **electric_adaptation,
        )

        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        self.assertAlmostEqual(1.5253333333333332, coeff["c_pump_power"], delta=0.001)
        self.assertAlmostEqual(1.0374999999999999, coeff["c_cosf"], delta=0.001)
        self.assertAlmostEqual(1.4285714285714286, coeff["c_amperage"], delta=0.001)
        self.assertAlmostEqual(1.1528161286541025, coeff["c_transform_power"], delta=0.001)
        self.assertAlmostEqual(1.8625560429138996, coeff["c_motor_volt"], delta=0.001)

        results = self.esp_electric_system.calc_electric_esp_system(
            self.pump_power,
            self.fluid_power,
            self.freq,
            self.t_cable,
            c_pump_power,
            c_cosf,
            c_amperage,
            c_transform_power,
            c_motor_volt,
        )

        self.assertAlmostEqual(electric_adaptation["motor_i_fact"], results["motor_i"], delta=0.001)
        self.assertAlmostEqual(electric_adaptation["load_fact"], results["load"], delta=0.001)
        self.assertAlmostEqual(electric_adaptation["cs_power_fact"], results["cs_power"], delta=0.001)
        self.assertAlmostEqual(electric_adaptation["transform_voltage_fact"], results["transform_voltage"], delta=0.001)

    def test_docstring_example(self):
        """
        EspElectricSystem: проверка примера, представленного в docstring
        """

        file_path = os.path.abspath(sys.modules[EspElectricSystem.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)

        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )
        example_string = doc_string[doc_string.find("Examples"):]

        self.assertEqual(ESP_ELECTRIC_SYSTEM, example_string)

        # Исходные данные для ПЭД
        motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }
        # Гидравлическая мощность
        fluid_power = 20000
        # Мощность насоса
        pump_power = 50000
        # Номинальная мощность газосепаратора и протектора
        gassep_nom_power = 1000
        prot_nom_power = 1000
        # Параметры электрического кабеля
        t_cable = 90 + 273.15
        cable_length = 2800
        r_cable = 1.5
        # Номинальная частота вращения насоса
        pump_nom_freq = 50
        # Текущая частота вращения вала
        freq_shaft = 53
        # КПД трансформатора и станции управления
        transform_eff = 0.97
        cs_eff = 0.95
        # Параметры для адаптации
        adaptation_parameters = {
            "cosf_fact": 0.88,
            "motor_i_fact": 45,
            "load_fact": 0.85,
            "transform_voltage_fact": 2500,
            "cs_power_fact": 100000,
        }

        # Инициализация класса с расчетом электрики
        calc_electric = EspElectricSystem(
            motor_data,
            pump_nom_freq,
            cable_length,
            gassep_nom_power,
            prot_nom_power,
            transform_eff,
            cs_eff,
            r_cable,
        )
        # Расчет адаптационных коэффициентов
        coeff = com.adapt_elsys(
            calc_electric,
            pump_power,
            fluid_power,
            freq_shaft,
            t_cable,
            **adaptation_parameters,
        )

        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        # Расчет электрики
        results = calc_electric.calc_electric_esp_system(
            pump_power,
            fluid_power,
            freq_shaft,
            t_cable,
            c_pump_power,
            c_cosf,
            c_amperage,
            c_transform_power,
            c_motor_volt,
        )
        # Расчет на другой частоте
        freq_shaft_new = 60
        pump_power_new = pump_power * (freq_shaft_new / freq_shaft) ** 3
        fluid_power_new = fluid_power * (freq_shaft_new / freq_shaft) ** 3
        results_new = calc_electric.calc_electric_esp_system(
            pump_power_new,
            fluid_power_new,
            freq_shaft_new,
            t_cable,
            c_pump_power,
            c_cosf,
            c_amperage,
            c_transform_power,
            c_motor_volt,
        )
        # Вывод результатов
        print("Результаты на частоте 53 ГЦ", results)
        print("Результаты на частоте 60 ГЦ", results_new)

        self.assertAlmostEqual(0.85, results["load"], delta=0.01)
        self.assertAlmostEqual(1191.016, results["gassep_power"], delta=0.01)
        self.assertAlmostEqual(1060.0, results["protector_power"], delta=0.01)
        self.assertAlmostEqual(70564.80066666666, results["pump_power"], delta=0.1)
        self.assertAlmostEqual(83696.34099616858, results["motor_power"], delta=0.1)
        self.assertAlmostEqual(2090.69060776, results["motor_voltage"], delta=0.01)
        self.assertAlmostEqual(45.0, results["motor_i"], delta=0.01)
        self.assertAlmostEqual(5.251596, results["cable_resistance"], delta=0.01)
        self.assertAlmostEqual(2500, results["transform_voltage"], delta=0.01)
        self.assertAlmostEqual(95238.09523809524, results["transform_power"], delta=0.1)
        self.assertAlmostEqual(100000.0, results["cs_power"], delta=0.1)
        self.assertAlmostEqual(0.2, results["esp_system_efficiency"])


if __name__ == "__main__":
    unittest.main()
