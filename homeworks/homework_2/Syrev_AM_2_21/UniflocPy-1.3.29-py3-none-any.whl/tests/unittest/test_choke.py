import ast
import os
import sys
import unittest

import tests.unittest.example_strings as exs
import unifloc.equipment.choke as ch
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.exceptions as exc


class TestChoke(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        print(f"Test: {self.shortDescription()}")

        d_up = 0.062
        d_choke = 0.005
        fluid_data = {'q_fluid': 100 / 86400, 'wct': 0.1,
                      'pvt_model_data': {
                          'black_oil': {'gamma_gas': 0.6, 'gamma_wat': 1, 'gamma_oil': 0.8,
                                        'rp': 80,
                                        'oil_correlations': {'pb': 'Standing', 'rs': 'Standing',
                                                             'rho': 'Standing',
                                                             'b': 'Standing', 'mu': 'Beggs',
                                                             'compr': 'Vasquez',
                                                             'hc': 'const'},
                                        'gas_correlations': {'ppc': 'Standing', 'tpc': 'Standing',
                                                             'z': 'Dranchuk',
                                                             'mu': 'Lee', 'hc': 'const'},
                                        'water_correlations': {'b': 'McCain', 'compr': 'Kriel',
                                                               'rho': 'Standing',
                                                               'mu': 'McCain', 'hc': 'const'},
                                        'rsb': {'value': 50, 'p': 10000000, 't': 303.15},
                                        'muob': {'value': 0.5, 'p': 10000000, 't': 303.15},
                                        'bob': {'value': 1.5, 'p': 10000000, 't': 303.15},
                                        'table_model_data': None, 'use_table_model': False}}}
        qliq = fluid_data['q_fluid']
        wct = fluid_data['wct']
        pvt_model_data = fluid_data['pvt_model_data']
        self.fluid_flow = fl.FluidFlow(qliq, wct, pvt_model_data)
        self.choke = ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow)
        correlations_1 = {'subcritical': 'api14b', 'critical': 'mechanistic'}
        correlations_2 = {'subcritical': 'parampam', 'critical': 'mechanistic'}
        self.choke_api14b = ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow,
                                     correlations=correlations_1)
        self.choke_parampam = ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow,
                                       correlations=correlations_2)
        self.choke_without_temp_drop = ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow, temperature_drop=False)

    def test_calc_dp_pwh_pfl_calibr_mechanistic(self):
        """
        Choke: Расчет Рбуф при известном Рлин с калибровкой по механистической корреляции
        """
        c_choke = 0.9
        p_fl = 1000000
        t_fl = 303.15
        result = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6034887.551826581, delta=5000)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.9000190344157316, places=5)

    def test_calc_dp_pwh_pfl_calibr_mechanistic_none(self):
        """
        Choke: Расчет Рбуф при известном Рлин с незаданным c_choke по механистической корреляции
        """
        c_choke = None
        p_fl = 1000000
        t_fl = 303.15
        result = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 9444711.09657018, delta=1000)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.6000126896104877, places=5)

    # def test_calc_dp_pwh_pfl_calibr_mechanistic_up(self):
    #     """
    #     Choke: Расчет Рбуф при известном Рлин с c_choke выше верхней границы по механистической
    #     корреляции
    #     """
    #     c_choke = 5
    #     p_fl = 1000000
    #     t_fl = 303.15
    #     result = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1, c_choke=c_choke)
    #     self.assertAlmostEqual(result[0], 4200258.829998724, places=5)
    #     self.assertAlmostEqual(result[1], 303.15, places=5)
    #     self.assertAlmostEqual(self.choke.c_vl, 1.3, places=5)

    def test_calc_dp_pwh_pfl_calibr_api14b(self):
        """
        Choke: Расчет Рбуф при известном Рлин с калибровкой по корреляции API-14B
        """
        c_choke = 5
        p_fl = 1000000
        t_fl = 303.15
        result = self.choke_api14b.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1,
                                           c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6216349.427498432, delta=1000)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke_api14b.c_vl, 0.85, places=5)

    def test_calc_dp_pwh_pfl_critical_mechanistic(self):
        """
        Choke: Расчет Рбуф при известном Рлин для критического режима по механистической корреляции
        """
        p_fl = 1000000
        t_fl = 303.15
        result = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)
        self.assertAlmostEqual(result[0], 9444711.09657018, delta=1000)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(result[3], 152525.22483278462, places=5)

    def test_calc_dp_pwh_pfl_subcritical_mechanistic(self):
        """
        Choke: Расчет Рбуф при известном Рлин для докритического режима по механистической
        корреляции
        """
        p_fl = 10000000
        t_fl = 303.15
        result = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)
        self.assertAlmostEqual(result[0], 16370804.345563464, delta=1000)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(result[3], 0, places=5)

    def test_calc_dp_pwh_pfl_no_correlation(self):
        """
        Choke: Расчет Рбуф при известном Рлин по нереализованной корреляции
        """
        p_fl = 10000000
        t_fl = 303.15
        with self.assertRaises(exc.NotImplementedChokeCorrError):
            self.choke_parampam.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)

    def test_calc_dp_pwh_pfl_input_qliq(self):
        """
        Choke: Расчет Рбуф при известном Рлин при доп. задании дебита
        """
        p_fl = 10000000
        t_fl = 303.15
        qliq = 70 / 86400
        result_1 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)
        result_2 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, q_liq=qliq, flow_direction=1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_dp_pwh_pfl_input_wct(self):
        """
        Choke: Расчет Рбуф при известном Рлин при доп. задании обв.
        """
        p_fl = 10000000
        t_fl = 303.15
        wct = 0.2
        result_1 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)
        result_2 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, wct=wct, flow_direction=1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_dp_pwh_pfl_input_rp(self):
        """
        Choke: Расчет Рбуф при известном Рлин при доп. задании ГФ.
        """
        p_fl = 10000000
        t_fl = 303.15
        rp = 100
        result_1 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1)
        result_2 = self.choke.calc_pt(p_mes=p_fl, t_mes=t_fl, rp=rp, flow_direction=1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_dp_pfl_pwh_calibr_mechanistic(self):
        """
        Choke: Расчет Рлин при известном Рбуф с калибровкой по механистической корреляции
        """
        c_choke = 0.9
        p_wh = 10000000
        t_wh = 303.15
        result = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6732508.237161543, delta=100)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.9000190344157316, places=5)

    def test_calc_dp_pfl_pwh_calibr_mechanistic_none(self):
        """
        Choke: Расчет Рлин при известном Рбуф с незаданным c_choke по механистической корреляции
        """
        c_choke = None
        p_wh = 10000000
        t_wh = 303.15
        result = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 2090135.303204137, delta=100)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.6000126896104877, places=5)

    # def test_calc_dp_pfl_pwh_calibr_mechanistic_up(self):
    #     """
    #     Choke: Расчет Рлин при известном Рбуф с c_choke выше верхней границы по механистической
    #     корреляции
    #     """
    #     c_choke = 5
    #     p_wh = 10000000
    #     t_wh = 303.15
    #     result = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1, c_choke=c_choke)
    #     self.assertAlmostEqual(result[0], 8464336.923792996, places=5)
    #     self.assertAlmostEqual(result[1], 303.15, places=5)
    #     self.assertAlmostEqual(self.choke.c_vl, 1.3, places=5)

    def test_calc_dp_pfl_pwh_calibr_api14b(self):
        """
        Choke: Расчет Рлин при известном Рбуф с калибровкой по корреляции API-14B
        """
        c_choke = 5
        p_wh = 10000000
        t_wh = 303.15
        result = self.choke_api14b.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1,
                                           c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6389563.424477087, delta=100)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(self.choke_api14b.c_vl, 0.85, places=5)

    def test_calc_dp_pfl_pwh_subcritical_mechanistic(self):
        """
        Choke: Расчет Рлин при известном Рбуф для докритического режима по механистической
        корреляции
        """
        p_wh = 10000000
        t_wh = 303.15
        result = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)
        self.assertAlmostEqual(result[0], 2090135.303204137, delta=100)
        self.assertAlmostEqual(result[1], 303.15, places=5)
        self.assertAlmostEqual(result[3], 0, places=5)

    def test_calc_dp_pfl_pwh_critical_mechanistic_1(self):
        """
        Choke: Расчет Рлин при известном Рбуф для критического режима по механистической
        корреляции (Рлин принимается по нижней границе)
        """
        p_wh = 1000000
        t_wh = 303.15
        with self.assertRaises(exc.UniflocPyError):
            self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)

    def test_calc_dp_pfl_pwh_critical_mechanistic_2(self):
        """
        Choke: Расчет Рлин при известном Рбуф для критического режима по механистической
        корреляции (Рассчитыввется нефизичный перепад давления)
        """
        p_wh = 5000000
        t_wh = 303.15
        with self.assertRaises(exc.UniflocPyError):
            self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)

    def test_calc_dp_pfl_pwh_input_qliq(self):
        """
        Choke: Расчет Рлин при известном Рбуф при доп. задании дебита
        """
        p_wh = 10000000
        t_wh = 303.15
        qliq = 90 / 86400
        result_1 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)
        result_2 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, q_liq=qliq, flow_direction=-1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_dp_pfl_pwh_input_wct(self):
        """
        Choke: Расчет Рлин при известном Рбуф при доп. задании обв.
        """
        p_wh = 10000000
        t_wh = 303.15
        wct = 0.2
        result_1 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)
        result_2 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, wct=wct, flow_direction=-1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_dp_pfl_pwh_input_rp(self):
        """
        Choke: Расчет Рлин при известном Рбуф при доп. задании ГФ.
        """
        p_wh = 10000000
        t_wh = 303.15
        rp = 75
        result_1 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1)
        result_2 = self.choke.calc_pt(p_mes=p_wh, t_mes=t_wh, rp=rp, flow_direction=-1)
        self.assertNotEqual(result_1[0], result_2[0])

    def test_calc_qliq_calibr_mechanistic(self):
        """
        Choke: Расчет дебита жидкости с калибровкой по механистической корреляции
        """
        c_choke = 0.9
        p_wh = 10000000
        t_wh = 303.15
        p_fl = 5000000
        t_fl = 303.15
        q_liq = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl, c_choke=c_choke) * 86400
        self.assertAlmostEqual(q_liq, 122.26971961712198, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.9000190344157316, places=5)

    def test_calc_qliq_calibr_mechanistic_none(self):
        """
        Choke: Расчет дебита жидкости с незаданным c_choke по механистической корреляции
        """
        c_choke = None
        p_wh = 10000000
        t_wh = 303.15
        p_fl = 5000000
        t_fl = 303.15
        q_liq = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl, c_choke=c_choke) * 86400
        self.assertAlmostEqual(q_liq, 81.51314641141465, places=5)
        self.assertAlmostEqual(self.choke.c_vl, 0.6000126896104877, places=5)

    def test_calc_qliq_calibr_mechanistic_up(self):
        """
        Choke: Расчет дебита жидкости с c_choke выше верхней границы по механистической
        корреляции
        """
        c_choke = 1.3
        p_wh = 10000000
        t_wh = 303.15
        p_fl = 5000000
        t_fl = 303.15
        q_liq = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl, c_choke=c_choke) * 86400
        self.assertAlmostEqual(q_liq, 176.6080820784475, delta=1)
        self.assertAlmostEqual(self.choke.c_vl, 1.3, delta=1)

    def test_calc_qliq_calibr_api14b(self):
        """
        Choke: Расчет дебита жидкости с калибровкой по корреляции API-14B
        """
        c_choke = 1.3
        p_wh = 10000000
        t_wh = 303.15
        p_fl = 5000000
        t_fl = 303.15
        q_liq = self.choke_api14b.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl,
                                            c_choke=c_choke) * 86400
        self.assertAlmostEqual(q_liq, 116.66818762092934, places=5)
        self.assertAlmostEqual(self.choke_api14b.c_vl, 0.85, places=5)

    def test_calc_qliq_critical_mechanistic(self):
        """
        Choke: Расчет дебита жидкости для критического режима по механистической корреляции
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 100000
        t_fl = 303.15
        q_liq = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl) * 86400
        self.assertAlmostEqual(q_liq, 57.284584911527354, places=5)

    def test_calc_qliq_subcritical_mechanistic(self):
        """
        Choke: Расчет дебита жидкости для докритического режима по механистической
        корреляции
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 4000000
        t_fl = 303.15
        q_liq = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl) * 86400
        self.assertAlmostEqual(q_liq, 31.80118763181964, places=5)

    def test_calc_qliq_no_correlation(self):
        """
        Choke: Расчет дебита жидкости для докритического режима по не реализованной
        корреляции
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 4000000
        t_fl = 303.15
        with self.assertRaises(exc.NotImplementedChokeCorrError):
            self.choke_parampam.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl)

    def test_calc_qliq_mechanistic_pwh_equal_pfl_dchoke_less_dup(self):
        """
        Choke: Расчет дебита жидкости по механистической корреляции
        для случая Рбуф = Рлин, d_choke < d_up
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 5000000
        t_fl = 303.15
        with self.assertRaises(exc.UniflocPyError):
            self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl)

    def test_calc_qliq_mechanistic_pwh_less_pfl_dchoke_less_dup(self):
        """
        Choke: Расчет дебита жидкости по механистической корреляции
        для случая Рбуф < Рлин, d_choke < d_up
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 10000000
        t_fl = 303.15
        with self.assertRaises(exc.UniflocPyError):
            self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl)

    def test_calc_qliq_input_wct(self):
        """
        Choke: Расчет дебита жидкости при доп. задании обв.
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 1000000
        t_fl = 303.15
        wct = 0.2
        q_liq_1 = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl) * 86400
        q_liq_2 = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl, wct=wct) * 86400
        self.assertNotEqual(q_liq_1, q_liq_2)

    def test_calc_qliq_input_rp(self):
        """
        Choke: Расчет дебита жидкости при доп. задании ГФ.
        """
        p_wh = 5000000
        t_wh = 303.15
        p_fl = 1000000
        t_fl = 303.15
        rp = 100
        q_liq_1 = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl) * 86400
        q_liq_2 = self.choke.calc_qliq(p_in=p_wh, t_in=t_wh, p_out=p_fl, t_out=t_fl, rp=rp) * 86400
        self.assertNotEqual(q_liq_1, q_liq_2)

    def test_calc_init_choke_dchoke_equal_dup(self):
        """
        Choke: Инициализация класса Choke для случая d_choke = d_up
        """
        d_choke = 0.062
        d_up = 0.062
        with self.assertRaises(exc.UniflocPyError):
            ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow)

    def test_calc_init_choke_dchoke_above_dup(self):
        """
        Choke: Инициализация класса Choke для случая d_choke > d_up
        """
        d_choke = 0.1
        d_up = 0.062
        with self.assertRaises(exc.UniflocPyError):
            ch.Choke(0, d_choke, d_up, fluid=self.fluid_flow)

    def test_calc_q_liq_explicit(self):
        """
        Choke: явный расчет дебита жидкости в штуцере
        """

        fluid_data = {'q_fluid': 100 / 86400, 'wct': 0,
                      'pvt_model_data': {
                          'black_oil': {'gamma_gas': 0.6, 'gamma_wat': 1, 'gamma_oil': 0.8, 'rp': 80}}}
        fluid = fl.FluidFlow(**fluid_data)
        choke = ch.Choke(1000, 0.01, 0.062, fluid)
        q_liq_expl = choke.calc_qliq(120 * 101325, 303.15, 100 * 101325, 303.15, explicit=True, c_choke=1.3)
        q_liq_impl = choke.calc_qliq(120 * 101325, 303.15, 100 * 101325, 303.15, explicit=False, c_choke=1.3)

        self.assertAlmostEqual(q_liq_expl * 86400, 557.1691270367387, delta=1)
        self.assertAlmostEqual(q_liq_impl * 86400, q_liq_expl * 86400, delta=1)

    def test_calc_dp_pwh_pfl_off_temp_drop(self):
        """
        Choke: Расчет Рбуф при известном Рлин при отключенном расчете перпада давления
        """
        c_choke = 0.9
        p_fl = 1000000
        t_fl = 303.15
        result = self.choke_without_temp_drop.calc_pt(p_mes=p_fl, t_mes=t_fl, flow_direction=1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6034887.551826581, delta=5000)
        self.assertAlmostEqual(result[1], t_fl, places=5)

    def test_calc_dp_pfl_off_temp_drop(self):
        """
        Choke: Расчет Рлин при известном Рбуф при отключенном расчете перпада давления
        """
        c_choke = 0.9
        p_wh = 10000000
        t_wh = 303.15
        result = self.choke_without_temp_drop.calc_pt(p_mes=p_wh, t_mes=t_wh, flow_direction=-1, c_choke=c_choke)
        self.assertAlmostEqual(result[0], 6732508.237161543, delta=100)
        self.assertAlmostEqual(result[1], t_wh, places=5)

    def test_docstring_example(self):
        """
        Choke: проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[ch.Choke.__module__].__file__)

        with open(file_path, encoding='utf8') as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [node for node in module.body if isinstance(node, ast.ClassDef)]

        doc_string = ast.get_docstring(
            [node for node in class_definitions[0].body if isinstance(node, ast.FunctionDef)][0])

        example_string = doc_string[doc_string.find('Examples'):]

        self.assertEqual(exs.CHOKE, example_string)

        fluid_data = {'q_fluid': 100 / 86400, 'wct': 0.1,
                      'pvt_model_data': {
                          'black_oil': {'gamma_gas': 0.6, 'gamma_wat': 1, 'gamma_oil': 0.8,
                                        'rp': 80,
                                        'oil_correlations': {'pb': 'Standing', 'rs': 'Standing',
                                                             'rho': 'Standing',
                                                             'b': 'Standing', 'mu': 'Beggs',
                                                             'compr': 'Vasquez',
                                                             'hc': 'const'},
                                        'gas_correlations': {'ppc': 'Standing', 'tpc': 'Standing',
                                                             'z': 'Dranchuk',
                                                             'mu': 'Lee', 'hc': 'const'},
                                        'water_correlations': {'b': 'McCain', 'compr': 'Kriel',
                                                               'rho': 'Standing',
                                                               'mu': 'McCain', 'hc': 'const'},
                                        'rsb': {'value': 50, 'p': 10000000, 't': 303.15},
                                        'muob': {'value': 0.5, 'p': 10000000, 't': 303.15},
                                        'bob': {'value': 1.5, 'p': 10000000, 't': 303.15},
                                        'table_model_data': None, 'use_table_model': False}}}
        h_mes = 1000
        d_choke = 0.005
        d_up = 0.062

        p_fl = 1000000
        t_fl = 303.15

        fluid = fl.FluidFlow(**fluid_data)
        test = ch.Choke(h_mes=h_mes, d=d_choke, d_up=d_up, fluid=fluid)
        results = test.calc_pt(p_fl, t_fl, 1)

        self.assertAlmostEqual(9444711.09657018, results[0], delta=1000)


if __name__ == '__main__':
    unittest.main()
