import unittest

import unifloc.equipment.esp_system as esp_sys
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.exceptions as exc


class TestEspSystem(unittest.TestCase):
    def setUp(self) -> None:
        self.esp_data = {
            "ID": 99999,
            "source": "legacy",
            "manufacturer": "Reda",
            "name": "DN500",
            "stages_max": 400,
            "rate_nom_sm3day": 30,
            "rate_opt_min_sm3day": 20,
            "rate_opt_max_sm3day": 40,
            "rate_max_sm3day": 66,
            "slip_nom_rpm": 3000,
            "freq_Hz": 50,
            "eff_max": 0.4,
            "height_stage_m": 0.035,
            "Series": 4,
            "d_od_mm": 86,
            "d_cas_min_mm": 112,
            "d_shaft_mm": 17,
            "area_shaft_mm2": 227,
            "power_limit_shaft_kW": 72,
            "power_limit_shaft_high_kW": 120,
            "power_limit_shaft_max_kW": 150,
            "pressure_limit_housing_atma": 390,
            "d_motor_od_mm": 95,
            "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
            "head_points": [
                4.88,
                4.73,
                4.66,
                4.61,
                4.52,
                4.35,
                4.1,
                3.74,
                3.2800000000000002,
                2.73,
                2.11,
                1.45,
                0.77,
                0,
            ],
            "power_points": [
                0.02,
                0.022,
                0.025,
                0.027,
                0.03,
                0.032,
                0.035,
                0.038,
                0.041,
                0.043000000000000003,
                0.046,
                0.049,
                0.052000000000000005,
                0.055,
            ],
            "eff_points": [
                0,
                0.12,
                0.21,
                0.29,
                0.35000000000000003,
                0.38,
                0.4,
                0.39,
                0.37,
                0.32,
                0.26,
                0.19,
                0.1,
                0,
            ],
        }
        self.h_mes = 100
        self.stages = 100
        fluid_data = {
            "q_fluid": 40 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        self.fluid = fl.FluidFlow(**fluid_data)

        self.esp = {
            "h_mes": self.h_mes,
            "stages": self.stages,
            "esp_data": self.esp_data,
            "viscosity_correction": False,
            "gas_correction": False,
            "fluid": self.fluid,
        }
        print(self.shortDescription())

    def test_calc_sys_no_sep_no_electro(self):
        """
        EspSystem: Расчет всей системы ЭЦН без электрических расчета и адаптации
        """

        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        self.esp_system = esp_sys.EspSystem(self.esp)
        res = self.esp_system.calc_esp_system(
            q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq
        )
        self.assertAlmostEqual(res[0], 13147341.271568477, delta=1000)
        self.assertIsNone(res[7])

    def test_calc_sep_no_sep(self):
        """
        EspSystem: Расчет сепарации ЭЦН без сепаратора
        """

        self.esp_system = esp_sys.EspSystem(self.esp)
        k_sep_nat = 0.5
        k_sep_gen = self.esp_system.calc_general_separation(k_sep_nat)
        self.assertEqual(k_sep_gen, 0.5)

    def test_calc_sep_with_sep(self):
        """
        EspSystem: Расчет сепарации ЭЦН с неизвестным сепаратором
        """

        separator = {
            "k_gas_sep": 0.7,
            "h_mes": 100,
        }
        self.esp_system = esp_sys.EspSystem(self.esp, separator=separator)
        k_sep_nat = 0.5
        k_sep_gen = self.esp_system.calc_general_separation(k_sep_nat)
        self.assertAlmostEqual(k_sep_gen, 0.85, delta=0.01)

    def test_calc_sep_with_sep2(self):
        """
        EspSystem: Расчет сепарации ЭЦН с конкретным сепаратором
        """
        separator = {"k_gas_sep": 0.7, "h_mes": 100, "sep_name": "ГСАН5А"}
        self.esp_system = esp_sys.EspSystem(self.esp, separator=separator)
        k_sep_nat = 0.5
        k_sep_gen = self.esp_system.calc_general_separation(k_sep_nat, 0.1, 0.004, 60)
        self.assertAlmostEqual(k_sep_gen, 0.6460771993555999, delta=0.01)

    def test_calc_sep_with_sep3(self):
        """
        EspSystem: Расчет сепарации ЭЦН с неправильным названием сепаратора
        """
        separator = {"k_gas_sep": 0.7, "h_mes": 100, "sep_name": "Атутнеправильносовсем"}
        self.esp_system = esp_sys.EspSystem(self.esp, separator=separator)
        k_sep_nat = 0.5
        k_sep_gen = self.esp_system.calc_general_separation(k_sep_nat, 0.1, 0.004, 60)
        self.assertAlmostEqual(k_sep_gen, 0.7253519914334339, delta=0.01)

    def test_calc_sep_with_sep4(self):
        """
        EspSystem: Расчет сепарации ЭЦН с неизвестным сепаратором и коэф.ест.сепарации = 0
        """
        separator = {"k_gas_sep": 0.7, "h_mes": 100, "sep_name": "Сепаратор не из базы"}
        self.esp_system = esp_sys.EspSystem(self.esp, separator=separator)
        k_sep_nat = 0.0
        k_sep_gen = self.esp_system.calc_general_separation(k_sep_nat, 0.1, 0.004, 60)
        self.assertAlmostEqual(k_sep_gen, 0.45070398286686775, delta=0.01)

    def test_calc_sys_no_sep_with_electro(self):
        """
        EspSystem: Расчет всей системы ЭЦН с электрическим расчетом
        """

        self.motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }

        self.esp_electric_system = {
            "motor_data": self.motor_data,
            "pump_nom_freq": self.esp_data["freq_Hz"],
            "gassep_nom_power": 500,
            "protector_nom_power": 500,
            "transform_eff": 0.97,
            "cs_eff": 0.97,
            "cable_specific_resistance": 1.18,
            "cable_length": 1000,
        }

        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        t_cable = 20 + 273.15

        self.esp_system = esp_sys.EspSystem(self.esp, self.esp_electric_system)
        res = self.esp_system.calc_esp_system(
            q_liq=40 / 86400,
            wct=0.5,
            p=p_dis,
            t=t,
            direction_to="int",
            freq=freq,
            t_cable=t_cable,
        )
        self.assertAlmostEqual(res[0], 13147341.271568477, delta=1000)
        self.assertAlmostEqual(res[7], 6991.722749125865, delta=0.01)

    def test_calc_sys_with_electro_no_temp_cable_or_length_cable(self):
        """
        EspSystem: Расчет  ЭЦН с электрическим расчетом, если не задана температура
        на глубине спуска ПЭД или не указана длина кабеля - должна вылететь ошибка
        """
        self.motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }

        self.esp_electric_system = {
            "motor_data": self.motor_data,
            "pump_nom_freq": self.esp_data["freq_Hz"],
            "gassep_nom_power": 500,
            "protector_nom_power": 500,
            "transform_eff": 0.97,
            "cs_eff": 0.97,
            "cable_specific_resistance": 1.18,
            "cable_length": 1000,
        }

        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        t_cable = 20 + 273.15

        self.esp_system = esp_sys.EspSystem(self.esp, self.esp_electric_system)

        with self.assertRaises(exc.UniflocPyError):
            self.esp_system.calc_esp_system(
                q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq,
            )

    def test_set_fluid(self):
        """
        EspSystem: Тестирование установки обновленного флюида
        """
        self.esp_system = esp_sys.EspSystem(self.esp)
        fluid_data = {
            "q_fluid": 50 / 86400,
            "wct": 0.5,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 200,
                }
            },
        }
        self.fluid_new = fl.FluidFlow(**fluid_data)
        self.esp_system.fluid = self.fluid_new
        self.assertNotEqual(id(self.fluid), id(self.esp_system.fluid))
        self.assertEqual(id(self.fluid_new), id(self.esp_system.fluid))
        self.assertEqual(id(self.fluid_new), id(self.esp_system.esp.fluid))

    def test_extra_output(self):
        """
        EspSystem: Тестирование сохранения распределений
        """
        p_dis = 140 * 101325
        t = 20 + 273.15
        freq = 50
        self.esp_system = esp_sys.EspSystem(self.esp)
        res = self.esp_system.calc_esp_system(
            q_liq=40 / 86400,
            wct=0.5,
            p=p_dis,
            t=t,
            direction_to="int",
            freq=freq,
            extra_output=True,
        )
        self.assertAlmostEqual(res[0], 13147341.271568477, delta=0.01)
        self.assertIsNone(res[7])
        self.assertEqual(len(self.esp_system.distributions), 29)
        self.esp_system = esp_sys.EspSystem(self.esp)
        p_int = self.esp_system.calc_esp_system(
            q_liq=40 / 86400, wct=0.5, p=p_dis, t=t, direction_to="int", freq=freq,
        )
        self.assertEqual(len(self.esp_system.distributions), 3)


# тестирование расчета коэффициента сепарации газосепаратора с помощью pytest
# @pytest.fixture
def init_esp_system(sep_name=None):
    """
    EspSystem: инициализация
    """
    esp_data = {
        "ID": 99999,
        "source": "legacy",
        "manufacturer": "Reda",
        "name": "DN500",
        "stages_max": 400,
        "rate_nom_sm3day": 30,
        "rate_opt_min_sm3day": 20,
        "rate_opt_max_sm3day": 40,
        "rate_max_sm3day": 66,
        "slip_nom_rpm": 3000,
        "freq_Hz": 50,
        "eff_max": 0.4,
        "height_stage_m": 0.035,
        "Series": 4,
        "d_od_mm": 86,
        "d_cas_min_mm": 112,
        "d_shaft_mm": 17,
        "area_shaft_mm2": 227,
        "power_limit_shaft_kW": 72,
        "power_limit_shaft_high_kW": 120,
        "power_limit_shaft_max_kW": 150,
        "pressure_limit_housing_atma": 390,
        "d_motor_od_mm": 95,
        "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
        "head_points": [
            4.88,
            4.73,
            4.66,
            4.61,
            4.52,
            4.35,
            4.1,
            3.74,
            3.2800000000000002,
            2.73,
            2.11,
            1.45,
            0.77,
            0,
        ],
        "power_points": [
            0.02,
            0.022,
            0.025,
            0.027,
            0.03,
            0.032,
            0.035,
            0.038,
            0.041,
            0.043000000000000003,
            0.046,
            0.049,
            0.052000000000000005,
            0.055,
        ],
        "eff_points": [
            0,
            0.12,
            0.21,
            0.29,
            0.35000000000000003,
            0.38,
            0.4,
            0.39,
            0.37,
            0.32,
            0.26,
            0.19,
            0.1,
            0,
        ],
    }
    h_mes = 100
    stages = 100
    fluid_data = {
        "q_fluid": 65 / 86400,
        "wct": 0.5,
        "pvt_model_data": {
            "black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 1000,}
        },
    }
    fluid = fl.FluidFlow(**fluid_data)

    esp = {
        "h_mes": h_mes,
        "stages": stages,
        "esp_data": esp_data,
        "viscosity_correction": False,
        "gas_correction": False,
        "fluid": fluid,
    }
    motor_data = {
        "ID": 1,
        "manufacturer": "Centrilift",
        "name": "562Centrilift-KMB-130-2200B",
        "d_motor_mm": 142.7,
        "motor_nom_i": 35,
        "motor_nom_power": 96.98,
        "motor_nom_voltage": 2200,
        "motor_nom_eff": 80,
        "motor_nom_cosf": 0.82,
        "motor_nom_freq": 60,
        "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
        "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
        "rpm_points": [
            3568.604,
            3551.63,
            3534.656,
            3517.682,
            3500.708,
            3483.734,
            3466.76,
            3449.786,
            3432.812,
            3415.838,
        ],
    }

    esp_electric_system = {
        "motor_data": motor_data,
        "pump_nom_freq": esp_data["freq_Hz"],
        "gassep_nom_power": 500,
        "protector_nom_power": 500,
        "transform_eff": 0.97,
        "cs_eff": 0.97,
        "cable_specific_resistance": 1.18,
        "cable_length": 1000,
    }
    separator = {"k_gas_sep": 0.7, "h_mes": 100, "sep_name": sep_name}
    p_dis = 140 * 101325
    t = 20 + 273.15
    freq = 50
    t_cable = 20 + 273.15

    esp_system = esp_sys.EspSystem(esp, esp_electric_system, separator)
    res = esp_system.calc_esp_system(
        q_liq=65 / 86400,
        wct=0.5,
        p=p_dis,
        t=t,
        direction_to="int",
        freq=freq,
        t_cable=t_cable,
    )
    return res[2]



def test_esp_sys_sep1():
    """
    EspSystem: расчет с конкретным сепаратором
    """
    status = init_esp_system("3МНГБ5А.1-КМ")
    assert status is not None


def test_esp_sys_sep2():
    """
    EspSystem: расчет с неправильным названием сепаратора
    """
    status = init_esp_system("Нет тут названия и не будет.")
    assert status is not None


def test_esp_sys_sep3():
    """
    EspSystem: расчет без конкретного сепаратора
    """
    status = init_esp_system()
    assert status is not None


if __name__ == "__main__":
    unittest.main()
