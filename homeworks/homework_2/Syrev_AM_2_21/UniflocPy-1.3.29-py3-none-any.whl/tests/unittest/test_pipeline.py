import ast
import os
import sys
import unittest

import pandas as pd

import tests.unittest.example_strings as ex_str
import unifloc.common.ambient_temperature_distribution as amb
import unifloc.common.trajectory as traj
import unifloc.pipe._gray as gr
import unifloc.pipe.pipeline as pipel
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.units_converter as uc
import unifloc.tools.exceptions as exc


class TestPipeline(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования.

        Запускается до расчета тестов
        """
        self.pvt_model = {
            "q_fluid": uc.convert_rate(297.1, "m3/day", "m3/s"),
            "wct": 0.2871,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 401.9,
                    "rsb": {"value": 90, "p": 15000000, "t": 353.15},
                    "muob": {"value": 0.5, "p": 15000000, "t": 353.15},
                    "bob": {"value": 1.5, "p": 15000000, "t": 353.15},
                }
            },
        }

        self.fluid = fl.FluidFlow(**self.pvt_model)
        print(f"Test: {self.shortDescription()}")

    def test_pipeline_d_006_down_up(self):
        """
        Pipeline: Диаметр 0.06, расчет вниз, поток вверх
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "top"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = 1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        p = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(p[0], 26104509.723546654, delta=1000)

    def test_pipeline_d_006_down_down(self):
        """
        Pipeline: Диаметр 0.06, расчет вниз, поток вниз
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "top"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = -1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pt = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(pt[0], 22202411.923960403, delta=1000)
        self.assertAlmostEqual(pt[1], 303.15, delta=1)

    def test_pipeline_d_006_up_up(self):
        """
        Pipeline: Диаметр 0.06, расчет вверх, поток вверх
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "bottom"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = -1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pt = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(pt[0], 5608311.636481579, delta=1000)
        self.assertAlmostEqual(pt[1], 303.15, delta=1)

    def test_pipeline_d_006_up_down(self):
        """
        Pipeline: Диаметр 0.06, расчет вверх, поток вниз
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "bottom"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = 1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pt = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(pt[0], 10115692.564380566, delta=1000)
        self.assertAlmostEqual(pt[1], 303.15, delta=1)

    def test_pipeline_extra_output(self):
        """
        Pipeline: Запрос доп.параметров расчета
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "bottom"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = 1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            extra_output=True,
            steps=None,
        )
        self.assertNotIsInstance(self.pipeline_object.distributions['dp_dl'], type(None))
        self.assertEqual(len(self.pipeline_object.distributions), 46)

        self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "gray",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            extra_output=True,
            steps=None,
        )
        self.assertIsNone((self.pipeline_object.distributions['flow_pattern']))

    def test_pipeline_change_hydrcorr(self):
        """
        Pipeline: Смена гидравлической корреляции
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )

        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        self.pipeline_object.hydr_corr_type = "Gray"
        self.assertEqual(self.pipeline_object.hydr_corr_type, "Gray")
        self.assertIsInstance(self.pipeline_object.pipe_object.hydrcorr, gr.Gray)

    def test_pipeline_change_hydrcorr_not_implemented_error(self):
        """
        Pipeline: Смена гидравлической корреляции на нереализованную корреляцию LaLaLand
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        with self.assertRaises(exc.NotImplementedHydrCorrError):
            self.pipeline_object.hydr_corr_type = "LaLaLand"

    def test_pipeline_diameter_dataframe(self):
        """
        Pipeline: Непостоянный диаметр, заданный с помощью DataFrame
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.06], [1000, 0.08]])
        h_start = "bottom"
        p_mes = 120 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = -1
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pt = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(pt[0], 3139066.3671270227, delta=0.01)
        self.assertAlmostEqual(pt[1], 303.15, delta=0.01)

    def test_pipeline_diameter_dict(self):
        """
        Pipeline: Непостоянный диаметр, заданный с помощью словаря
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        h_start = "bottom"
        p_mes = 120 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = -1
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pt = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(pt[0], 3139066.3671270227, delta=0.01)
        self.assertAlmostEqual(pt[1], 303.15, delta=0.01)

    def test_pipeline_diameter_type_error(self):
        """
        Pipeline: Непостоянный диаметр, заданный с помощью нереализованного способа задания списка
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = [0.06, 0.08]
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        with self.assertRaises(TypeError):
            pipel.Pipeline(
                top_depth,
                bottom_depth,
                d,
                roughness,
                well_trajectory,
                self.fluid,
                amb_temp
            )

    def test_pipeline_steps(self):
        """
        Pipeline: С шагом 100 метров, проверка задания шага
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        h_start = "bottom"
        p_mes = 120 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 100
        integration_method = "RK23"
        flow_direction = -1
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )

        step_actual = (
                self.pipeline_object.distributions['depth'][1]
                - self.pipeline_object.distributions['depth'][0]
        )

        self.assertEqual(step_actual, step_lenth_calc_along_well)

    def test_pipeline_change_fluid(self):
        """
        Pipeline: Обновление флюида
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )
        pvt_model = {
            "q_fluid": uc.convert_rate(306.1, "m3/day", "m3/s"),
            "wct": 0.2871,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 401.9,
                    "rsb": {"value": 90, "p": 15000000, "t": 353.15},
                    "muob": {"value": 0.5, "p": 15000000, "t": 353.15},
                    "bob": {"value": 1.5, "p": 15000000, "t": 353.15},
                }
            },
        }

        fluid = fl.FluidFlow(**pvt_model)

        self.pipeline_object.fluid = fluid
        self.assertNotEqual(id(self.fluid), id(self.pipeline_object.fluid))

    def test_pipeline_horizontal(
            self,
    ):
        """
        Pipeline: Тестирование расчета давления в горизонтальной трубе
        :return:
        """
        wct = 0.627

        well_trajectory = {
            "inclinometry": pd.DataFrame(
                columns=["MD", "TVD"],
                data=[[float(0), float(0)], [float(85), float(0)]],
            )
        }
        fluid_data = {
            "q_fluid": uc.convert_rate(16.229, "m3/day", "m3/s"),
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.85,
                    "rp": 69.9992,
                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15},
                }
            },
        }

        traject = traj.Trajectory(well_trajectory["inclinometry"])
        fluid = fl.FluidFlow(**fluid_data)
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        pipe = pipel.Pipeline(
            0,
            85,
            d=0.01498,
            roughness=2.54 * 10 ** (-5),
            trajectory=traject,
            fluid=fluid,
            ambient_temperature_distribution=amb_temp,
            friction_factor=1,
            holdup_factor=1,
        )
        result = pipe.calc_pt("top", 17 * 101325, -1, 30 / 86400, wct)
        self.assertAlmostEqual(result[0], 514042.2031342272)
        self.assertAlmostEqual(result[2], 0)

    def test_q_liq_by_p_pipe_scipy(self):
        """
        Pipeline: Обратный пересчет дебита по перепаду давления для случая без max_rate
        """
        wct = 0.627

        well_trajectory = {
            "inclinometry": pd.DataFrame(
                columns=["MD", "TVD"],
                data=[[float(0), float(0)], [float(85), float(0)]],
            )
        }
        fluid_data = {
            "q_fluid": uc.convert_rate(16.229, "m3/day", "m3/s"),
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.85,
                    "rp": 69.9992,
                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15},
                }
            },
        }

        traject = traj.Trajectory(well_trajectory["inclinometry"])
        fluid = fl.FluidFlow(**fluid_data)
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        Pipe = pipel.Pipeline(
            0,
            85,
            d=0.01498,
            roughness=2.54 * 10 ** (-5),
            trajectory=traject,
            fluid=fluid,
            ambient_temperature_distribution=amb_temp,
            friction_factor=1,
            holdup_factor=1,
        )

        q = Pipe.calc_qliq(
            p_top=17.35524 * 101325,
            p_bottom=14.659864823951027 * 101325,
            flow_direction=-1,
            wct=wct,
            hydr_corr_type="BeggsBrill",
        )
        self.assertAlmostEqual(q[0], 16.339005536580153 / 86400, delta=0.0001)
        self.assertAlmostEqual(q[1], 0)

    def test_q_liq_by_p_pipe_scipy_max_rate(self):
        """
        Pipeline: Обратный пересчет дебита по перепаду давления для случая с max_rate
        """
        wct = 0.627

        well_trajectory = {
            "inclinometry": pd.DataFrame(
                columns=["MD", "TVD"],
                data=[[float(0), float(0)], [float(85), float(0)]],
            )
        }
        fluid_data = {
            "q_fluid": uc.convert_rate(16.229, "m3/day", "m3/s"),
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.85,
                    "rp": 69.9992,
                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15},
                }
            },
        }

        traject = traj.Trajectory(well_trajectory["inclinometry"])
        fluid = fl.FluidFlow(**fluid_data)
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        Pipe = pipel.Pipeline(
            0,
            85,
            d=0.01498,
            roughness=2.54 * 10 ** (-5),
            trajectory=traject,
            fluid=fluid,
            ambient_temperature_distribution=amb_temp,
            friction_factor=1,
            holdup_factor=1,
        )

        q = Pipe.calc_qliq(
            p_top=17.35524 * 101325,
            p_bottom=14.659864823951027 * 101325,
            flow_direction=-1,
            wct=wct,
            hydr_corr_type="BeggsBrill",
            max_rate=20 / 86400,
        )
        self.assertAlmostEqual(q[0], 16.339005536580153 / 86400, delta=0.0001)
        self.assertAlmostEqual(q[1], 0)

    def test_q_liq_by_p_pipe_scipy_stable(self):
        """
        Pipeline: Обратный пересчет дебита по перепаду давления на stable-режиме
        """
        wct = 0.627

        well_trajectory = {
            "inclinometry": pd.DataFrame(
                columns=["MD", "TVD"],
                data=[[float(0), float(0)], [float(85), float(85)]],
            )
        }
        fluid_data = {
            "q_fluid": uc.convert_rate(16.229, "m3/day", "m3/s"),
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.85,
                    "rp": 69.9992,
                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15},
                }
            },
        }

        traject = traj.Trajectory(well_trajectory["inclinometry"])
        fluid = fl.FluidFlow(**fluid_data)
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        Pipe = pipel.Pipeline(
            0,
            85,
            d=0.060,
            roughness=2.54 * 10 ** (-5),
            trajectory=traject,
            fluid=fluid,
            ambient_temperature_distribution=amb_temp,
            friction_factor=1,
            holdup_factor=1,
        )

        q = Pipe.calc_qliq(
            p_top=17 * 101325,
            p_bottom=23 * 101325,
            flow_direction=1,
            wct=wct,
            hydr_corr_type="BeggsBrill",
        )
        self.assertAlmostEqual(q[0], 555.8800583856271 / 86400, delta=0.0001)
        self.assertAlmostEqual(q[1], 0)

    def test_q_liq_by_p_pipe_scipy_unstable(self):
        """
        Pipeline: Обратный пересчет дебита по перепаду давления на unstable-режиме
        """
        wct = 0.627

        well_trajectory = {
            "inclinometry": pd.DataFrame(
                columns=["MD", "TVD"],
                data=[[float(0), float(0)], [float(85), float(85)]],
            )
        }
        fluid_data = {
            "q_fluid": uc.convert_rate(16.229, "m3/day", "m3/s"),
            "wct": wct,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.85,
                    "rp": 69.9992,
                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15},
                }
            },
        }

        traject = traj.Trajectory(well_trajectory["inclinometry"])
        fluid = fl.FluidFlow(**fluid_data)
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        Pipe = pipel.Pipeline(
            0,
            85,
            d=0.060,
            roughness=2.54 * 10 ** (-5),
            trajectory=traject,
            fluid=fluid,
            ambient_temperature_distribution=amb_temp,
            friction_factor=1,
            holdup_factor=1,
        )

        q = Pipe.calc_qliq(
            p_top=17 * 101325,
            p_bottom=23 * 101325,
            flow_direction=1,
            wct=wct,
            hydr_corr_type="BeggsBrill",
            unstable_rate=True,
        )
        self.assertAlmostEqual(q[0], 34.469367054668915 / 86400, delta=0.0001)
        self.assertAlmostEqual(q[1], 0)

    def test_docstring_example_calc_pt(self):
        """
        Pipeline: Проверка работоспособности примера calc_pt из docstring
        """
        file_path = os.path.abspath(sys.modules[pipel.Pipeline.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples"):]

        self.assertEqual(ex_str.PIPELINE_CALC_PT, example_string)

        import pandas as pd
        import unifloc.tools.units_converter as uc
        import unifloc.common.trajectory as traj
        import unifloc.common.ambient_temperature_distribution as amb
        import unifloc.pipe.pipeline as pipe
        import unifloc.pvt.fluid_flow as fl
        # Инициализация исходных данных класса Pipeline
        trajectory = traj.Trajectory(pd.DataFrame(columns=["MD", "TVD"],
                                                  data=[[float(0), float(0)],
                                                        [float(1800), float(1800)]]))
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 363.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        fluid_data = {"q_fluid": uc.convert_rate(297.1, "m3/day", "m3/s"), "wct": 0.2871,
                      "pvt_model_data": {"black_oil":
                                             {"gamma_gas": 0.7, "gamma_wat": 1,
                                              "gamma_oil": 0.8, "rp": 401,
                                              "rsb": {"value": 90, "p": 15000000, "t": 363.15},
                                              "muob": {"value": 0.5, "p": 15000000, "t": 363.15},
                                              "bob": {"value": 1.5, "p": 15000000, "t": 363.15}, }}}
        fluid = fl.FluidFlow(**fluid_data)
        # Так тоже возможно: d = pd.DataFrame(columns=["MD", "d"],
        #                                      data=[[0, 0.062], [1000, 0.082]])
        # Так тоже возможно: d= {"MD": [0, 1000], "d": [0.06, 0.08]}
        d = 0.06
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        p_wh = 20 * 101325  # Па
        flow_direction = 1
        # Инициализация объекта pvt-модели
        pipe = pipe.Pipeline(top_depth, bottom_depth, d, roughness, trajectory, fluid, amb_temp)
        # Расчет давления и температуры на забое от буфера
        results = pipe.calc_pt("top", p_wh, flow_direction)

        self.assertAlmostEqual(results[0], 11863253.420450963, delta=1000)
        self.assertAlmostEqual(results[1], 363.15)
        self.assertAlmostEqual(results[2], 0)

    def test_check_direction_calc(self):
        """
        Pipeline: Тестирование совпадения расчетов при в разные стороны
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "top"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = 1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 383.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        pvt_model = {
            "q_fluid": uc.convert_rate(297.1, "m3/day", "m3/s"),
            "wct": 0,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.858,
                    "rp": 100,
                }
            },
        }
        self.fluid = fl.FluidFlow(**pvt_model)

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )

        p1 = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            None,
            None,
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        p2 = self.pipeline_object.calc_pt(
            "bottom",
            p1[0],
            -1,
            None,
            None,
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        self.assertAlmostEqual(p2[0], p_mes, delta=5000)

    def test_triple_calc(self):
        """
        Pipeline: Тестирование совпадения расчетов при вызове 3 раза
        """
        top_depth = 0
        bottom_depth = 1800
        roughness = 0.0001
        d = 0.06
        h_start = "top"
        p_mes = 150 * 101325
        t_mes = 30 + 273.15
        step_lenth_calc_along_well = 10
        integration_method = "RK23"
        flow_direction = 1
        ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
        amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
        well_trajectory = traj.Trajectory(
            pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1800, 1800]])
        )
        pvt_model = {
            "q_fluid": uc.convert_rate(297.1, "m3/day", "m3/s"),
            "wct": 0,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.858,
                    "rp": 0,
                }
            },
        }
        self.fluid = fl.FluidFlow(**pvt_model)

        self.pipeline_object = pipel.Pipeline(
            top_depth, bottom_depth, d, roughness, well_trajectory, self.fluid, amb_temp
        )

        p1 = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        p2 = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )
        p3 = self.pipeline_object.calc_pt(
            h_start,
            p_mes,
            flow_direction,
            self.pvt_model["q_fluid"],
            self.pvt_model["wct"],
            None,
            t_mes,
            "beggsbrill",
            step_lenth_calc_along_well,
            integration_method,
            1,
            1,
            steps=None,
        )

        self.assertAlmostEqual(p1[0], p2[0], delta=1000)
        self.assertAlmostEqual(p2[0], p3[0], delta=1000)


if __name__ == "__main__":
    unittest.main()
