import unittest

from unifloc.pvt.black_oil_model import BlackOilModel
from unifloc.service._constants import WAT_CORRS, OIL_CORRS, GAS_CORRS


class TestBlackOilModel(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        self.gamma_wat = 1
        self.gamma_gas = 0.6
        self.gamma_oil = 0.8
        print(f"Test: {self.shortDescription()}")

    def test_calc_no_calibr_5_30(
        self,
    ):
        """
        BlackOilModel: Расчет всех свойств без калибровки для 5 МПа и 303.15 K
        """
        rp = 100
        self.pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp
        )
        p = 5 * 10 ** 6
        t = 303.15
        self.pvt_model.calc_pvt(p, t)

        self.assertAlmostEqual(self.pvt_model.bo, 1.0826912798324486, places=5)
        self.assertAlmostEqual(self.pvt_model.bg, 0.01926132038559829, places=3)
        self.assertAlmostEqual(self.pvt_model.bw, 1.0050320333498315, places=5)
        self.assertAlmostEqual(self.pvt_model.rho_oil, 763.0242919556292, places=5)
        self.assertAlmostEqual(self.pvt_model.rho_gas, 37.53525585230165, places=5)
        self.assertAlmostEqual(self.pvt_model.rho_wat, 994.9931612298373, places=5)
        self.assertAlmostEqual(self.pvt_model.rs, 35.63306212748365, places=5)
        self.assertAlmostEqual(self.pvt_model.pb, 11774213.158352406, places=5)
        self.assertAlmostEqual(self.pvt_model.compro, 1.2622738716260917e-11, places=5)
        self.assertAlmostEqual(self.pvt_model.muo, 1.7271930141598848, places=5)
        self.assertAlmostEqual(self.pvt_model.mug, 0.012101852555712622, places=5)
        self.assertAlmostEqual(self.pvt_model.muw, 0.7677088165725673, places=5)
        self.assertAlmostEqual(self.pvt_model.z, 0.9051974887985563, places=5)

    def test_calc_calibr_rs_equal(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой газосодержания rsb = rp = 100
        """
        rp = 100
        rsb = {"value": 100, "p": 10000000, "t": 363.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, rsb=rsb
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.1321945802005444, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 743.4830883136026, places=5)
        self.assertAlmostEqual(pvt_model.rs, 56.980059288182346, places=5)
        self.assertAlmostEqual(pvt_model.pb, 7974803.668951578, places=5)
        self.assertAlmostEqual(pvt_model.muo, 1.3074074898736976, places=5)

    def test_calc_calibr_rs_less(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой газосодержания rsb = 80 < rp = 100
        """
        rp = 100
        rsb = {"value": 80, "p": 10000000, "t": 363.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, rsb=rsb
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.105428876051132, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 753.9282142010818, places=5)
        self.assertAlmostEqual(pvt_model.rs, 45.58404743054587, places=5)
        self.assertAlmostEqual(pvt_model.pb, 9597437.90200118, places=5)
        self.assertAlmostEqual(pvt_model.muo, 1.4981864434228005, places=5)

    def test_calc_calibr_rs_up(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой газосодержания rsb = 120 > rp = 100
        """
        rp = 100
        rsb = {"value": 120, "p": 10000000, "t": 363.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, rsb=rsb
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.1596459936303039, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 733.0866767451856, places=5)
        self.assertAlmostEqual(pvt_model.rs, 68.37607114581881, places=5)
        self.assertAlmostEqual(pvt_model.pb, 6854875.410830839, places=5)
        self.assertAlmostEqual(pvt_model.muo, 1.1647207654007488, places=5)

    def test_calc_calibr_muo(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой вязкости
        """
        rp = 100
        muob = {"value": 0.5, "p": 10000000, "t": 303.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, muob=muob
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0826912798324486, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 763.0242919556292, places=5)
        self.assertAlmostEqual(pvt_model.rs, 35.63306212748365, places=5)
        self.assertAlmostEqual(pvt_model.pb, 11774213.158352406, places=5)
        self.assertAlmostEqual(pvt_model.muo, 0.9349701905842575, places=5)

    def test_calc_calibr_bo(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой объемного коэффициента
        """
        rp = 100
        bob = {"value": 1.2, "p": 10000000, "t": 303.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, bob=bob
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0854649300171226, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 761.0745629411136, places=5)
        self.assertAlmostEqual(pvt_model.muo, 1.7271930141598848, places=5)

    def test_calc_calibr_all(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками
        """
        rp = 100
        bob = {"value": 1.2, "p": 10000000, "t": 303.15}
        muob = {"value": 0.5, "p": 10000000, "t": 303.15}
        rsb = {"value": 120, "p": 10000000, "t": 303.15}

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 10000000
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.1586528897759794, delta=0.01)
        self.assertAlmostEqual(pvt_model.rs, 100, places=5)
        self.assertAlmostEqual(pvt_model.pb, 8595666.671417916, places=5)
        self.assertAlmostEqual(pvt_model.muo, 0.583049680479372, places=5)

    def test_calc_calibr_all_none(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками None
        """
        rp = 100
        bob = None
        muob = None
        rsb = None

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0826912798324486, places=5)

    def test_calc_calibr_all_val_none(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками value = None
        """
        rp = 100
        bob = {"value": None, "p": 10000000, "t": 303.15}
        muob = {"value": None, "p": 10000000, "t": 303.15}
        rsb = {"value": None, "p": 10000000, "t": 363.15}

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0826912798324486, places=5)

    def test_calc_calibr_all_p_none(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками p = None
        """
        rp = 100
        bob = {"value": 1.2, "p": None, "t": 303.15}
        muob = {"value": 0.5, "p": None, "t": 303.15}
        rsb = {"value": 120, "p": None, "t": 363.15}

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0826912798324486, places=5)

    def test_calc_calibr_all_t_none(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками t = None
        """
        rp = 100
        bob = {"value": 1.2, "p": 10000000, "t": None}
        muob = {"value": 0.5, "p": 10000000, "t": None}
        rsb = {"value": 120, "p": 10000000, "t": None}

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 5 * 10 ** 6
        t = 303.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.0826912798324486, places=5)

    def test_calc_calibr_change_correlations_none(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками correlation = None
        """
        rp = 100

        wat_corrs = {"b": None, "compr": None, "rho": None, "mu": None}
        gas_corrs = {"ppc": "standing", "tpc": "standing", "mu": None}
        oil_corrs = {"pb": "standing", "b": "standing", "compr": None}
        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            oil_correlations=oil_corrs,
            water_correlations=wat_corrs,
            gas_correlations=gas_corrs,
        )
        self.assertEqual(pvt_model.water_correlations, WAT_CORRS)
        self.assertEqual(pvt_model.oil_correlations, OIL_CORRS)
        self.assertEqual(pvt_model.gas_correlations, GAS_CORRS)

    def test_calc_calibr_all_different_temperature(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 К со всеми калибровками при разных температурах калибровки
        и расчетной
        """
        rp = 100
        bob = {"value": 1.2, "p": 10000000, "t": 303.15}
        muob = {"value": 0.5, "p": 10000000, "t": 303.15}
        rsb = {"value": 120, "p": 10000000, "t": 303.15}

        pvt_model = BlackOilModel(
            self.gamma_gas,
            self.gamma_oil,
            self.gamma_wat,
            rp,
            bob=bob,
            muob=muob,
            rsb=rsb,
        )
        p = 10000000
        t = 353.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.2151804692950332, delta=0.01)
        self.assertAlmostEqual(pvt_model.rs, 95.61071088051142, places=5)
        self.assertAlmostEqual(pvt_model.pb, 10379574.867090384, places=5)
        self.assertAlmostEqual(pvt_model.muo, 0.27612946760670265, places=5)

    def test_calc_calibr_muo_different_temperature(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой вязкости
        """
        rp = 100
        muob = {"value": 0.5, "p": 10000000, "t": 303.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, muob=muob
        )
        p = 5 * 10 ** 6
        t = 353.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.1192979546559967, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 733.3266891994892, places=5)
        self.assertAlmostEqual(pvt_model.rs, 28.390853340484504, places=5)
        self.assertAlmostEqual(pvt_model.pb, 14217783.407606237, places=5)
        self.assertAlmostEqual(pvt_model.muo, 0.4183213899779714, places=5)

    def test_calc_calibr_bo_different_temperature(self):
        """
        BlackOilModel: Расчет всех свойств для 5 МПа и 303.15 K с калибровкой объемного коэффициента
        """
        rp = 100
        bob = {"value": 1.2, "p": 10000000, "t": 303.15}
        pvt_model = BlackOilModel(
            self.gamma_gas, self.gamma_oil, self.gamma_wat, rp, bob=bob
        )
        p = 5 * 10 ** 6
        t = 353.15
        pvt_model.calc_pvt(p, t)
        self.assertAlmostEqual(pvt_model.bo, 1.1215078768717512, places=5)
        self.assertAlmostEqual(pvt_model.rho_oil, 731.8816748796718, places=5)
        self.assertAlmostEqual(pvt_model.rs, 28.390853340484504, places=5)
        self.assertAlmostEqual(pvt_model.pb, 14217783.407606237, places=5)
        self.assertAlmostEqual(pvt_model.muo, 0.6507754854686917, places=5)


if __name__ == "__main__":
    unittest.main()
