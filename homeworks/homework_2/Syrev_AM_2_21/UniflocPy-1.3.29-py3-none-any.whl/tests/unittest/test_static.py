import unittest

from numpy import NAN, isnan
from copy import deepcopy

from unifloc.pipe._static import Static
from unifloc.pvt.fluid_flow import FluidFlow


class TestStatic(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов

        Returns
        -------

        """
        self.p_sep = 4
        self.t_sep = 303.15
        self.k_sep = 0.5

        self.fluid_data = {
            "q_fluid": (10 ** (-7)) / 86400,
            "wct": 0.98,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 0,
                    "rsb": {"value": 100, "p": 20000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 20000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 20000000, "t": 303.15},
                }
            },
        }
        self.fluid = FluidFlow(**self.fluid_data)
        self.fluid.modify(self.p_sep, self.t_sep, self.k_sep, calc_type="annulus")
        self.fluid_gas = deepcopy(self.fluid)
        self.fluid_gas.fluid_type = "gas"
        self.d = 0.126
        self.static = Static(self.d)
        self.eps_m = 0.0001
        self.sigma_l_nm = 5.16443138806286e-02
        self.c_calibr_grav = 1
        self.c_calibr_fric = 1
        self.init_datasets = {
            1: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 20,
                "qg_rc_m3day": 2000,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
                "rho_mix_rc_kgm3": 800,
            },
            2: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 0,
                "qg_rc_m3day": 0,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
                "rho_mix_rc_kgm3": 20,
            },
            "NaN": {
                "theta_deg": NAN,
                "eps_m": NAN,
                "ql_rc_m3day": NAN,
                "qg_rc_m3day": NAN,
                "mul_rc_cp": NAN,
                "mug_rc_cp": NAN,
                "sigma_l_nm": NAN,
                "rho_lrc_kgm3": NAN,
                "rho_grc_kgm3": NAN,
                "c_calibr_grav": NAN,
                "c_calibr_fric": NAN,
                "rho_mix_rc_kgm3": NAN,
            },
        }
        print(self.shortDescription())

    def test_static_1(self):
        """
        Static: Расчет всех параметров для набора исходных данных № 1

        Returns
        -------

        """

        self.static.calc_grad(**self.init_datasets[1])
        self.assertAlmostEqual(self.static.dp_dl_gr, 7848.0, places=5)

    def test_static_2(self):
        """
        Static: Расчет всех параметров для набора исходных данных № 2

        Returns
        -------

        """

        self.static.calc_grad(**self.init_datasets[2])
        self.assertAlmostEqual(self.static.dp_dl_gr, 196.20000000000002, places=5)

    def test_static_nan(self):
        """
        Static: Расчет всех параметров для NaN

        Returns
        -------

        """

        self.static.calc_grad(**self.init_datasets["NaN"])
        self.assertTrue(isnan(self.static.dp_dl_gr))


if __name__ == "__main__":
    unittest.main()
