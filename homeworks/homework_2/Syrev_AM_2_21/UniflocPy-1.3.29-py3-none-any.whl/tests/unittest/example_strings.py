GL_WELL = """Examples:
--------
>>> import pandas as pd
>>> import unifloc.tools.units_converter as uc
>>> from unifloc.well.gaslift_well import GasLiftWell
>>> # Инициализация исходных данных
>>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]])
>>> # Возможный способ задания инклинометрии через dict
>>> # df = {"MD": [0, 1000],
>>> #       "TVD": [0, 900]}
>>>
>>> # В словари с калибровками подается давление и температура калибровки.
>>> # Зачастую - это давление насыщения и пластовая температура
>>> fluid_data = {"q_fluid": uc.convert_rate(100, "m3/day", "m3/s"), "wct": 0.1,
...               "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
...               "rp": 300,
...               "oil_correlations": {"pb": "Standing", "rs": "Standing","rho": "Standing",
...               "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
...               "gas_correlations":
...               {"ppc": "Standing","tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
...               "water_correlations": {"b": "McCain", "compr": "Kriel","rho": "Standing",
...               "mu": "McCain"},
...               "rsb": {"value": 300, "p": 10000000, "t": 303.15},
...               "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...               "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...               "table_model_data": None, "use_table_model": False}}}
>>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
>>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
>>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
>>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001}}
>>> well_trajectory_data = {"inclinometry": df}
>>> equipment_data = {"gl_system": {
...                   "valve1": {"h_mes": 800, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve2": {"h_mes": 850, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve3": {"h_mes": 900, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve4": {"h_mes": 1000, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"}
...                                               }
...                   }
>>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
>>>
>>> # Инициализация объекта скважины
>>> well = GasLiftWell(fluid_data, pipe_data, well_trajectory_data,
...                    ambient_temperature_data, equipment_data)

>>> # Расчет линейного давления
>>> parameters = well.calc_pfl_pwf(uc.convert_pressure(20, "MPa", "Pa"),
...                                uc.convert_rate(100, "m3/day", "m3/s"), 0.1,
...                                q_gas_inj=uc.convert_rate(10000, "m3/day", "m3/s"))

>>> # Расчет забойного давления
>>> p_fl = parameters[0]
>>> # Расчет с сохранением доп. атрибутов распределений свойств
>>> p_wf = well.calc_pwf_pfl(p_fl, uc.convert_rate(100, "m3/day", "m3/s"), 0.1,
...                          q_gas_inj=uc.convert_rate(100000, "m3/day", "m3/s"),
...                          output_params=True)
>>> # Запрос всех значений доп. свойств в виде словаря
>>> result = well.extra_output"""

ANNULUS = """Examples:
--------
>>> import pandas as pd
>>> import unifloc.pvt.fluid_flow as fl
>>> import unifloc.common.trajectory as traj
>>> import unifloc.common.ambient_temperature_distribution as amb
>>> import unifloc.pipe.annulus as ann
>>>
>>> # Инициализация исходных данных класса FluidFlow
>>> q_fluid = 100 / 86400
>>> wct = 0
>>> pvt_model_data = {
...     "black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
...                   "rp": 50,
...                   "oil_correlations": {"pb": "Standing", "rs": "Standing",
...                                        "rho": "Standing", "b": "Standing",
...                                         "mu": "Beggs", "compr": "Vasquez"},
...                   "gas_correlations": {"ppc": "Standing", "tpc": "Standing",
...                                        "z": "Dranchuk", "mu": "Lee"},
...                   "water_correlations": {"b": "McCain", "compr": "Kriel",
...                                          "rho": "Standing", "mu": "McCain"},
...                   "rsb": {"value": 50, "p": 10000000, "t": 303.15},
...                   "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...
...                   "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...                   "table_model_data": None, "use_table_model": False}}
>>> # Инициализация исходных данных класса WellTrajectory
>>> trajectory = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0],
...                                                        [2000, 2000], [2500, 2500]])
>>>
>>> well_trajectory_data = {"inclinometry": trajectory}
>>> well_trajectory = traj.Trajectory(**well_trajectory_data)
>>> # Задание параметров сепарации
>>> p_sep = 4 * (10 ** 6)
>>>
>>> t_sep = 303.15
>>> k_sep = 0.5
>>> # Создание объекта флюида
>>> fluid = fl.FluidFlow(q_fluid, wct, pvt_model_data)
>>>
>>> # Модификация флюида
>>> fluid.modify(p_sep, t_sep, k_sep, calc_type="annulus")
>>> bottom_depth = 2000
>>> d_casing = 0.146
>>> d_tubing = 0.062
>>>
>>> s_wall = 0.005
>>> roughness = 0.0001
>>> # Создание объекта с температурой породы
>>>
>>> ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
>>> amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
>>>
>>> # Создание объекта затрубного пространства
>>> annulus = ann.Annulus(fluid, amb_temp, bottom_depth, d_casing, d_tubing,
...                       s_wall, roughness, well_trajectory)
>>> # Инициализация исходных данных метода расчета динамического уровня calc_hdyn
>>> p_esp = 150 * 101325
>>> t_esp = 303.15
>>> p_ann = 20 * 101325
>>>
>>> t_ann = 303.15
>>> # Вызов метода расчета динамического уровня
>>> h_dyn, p_dyn = annulus.calc_hdyn(p_esp, t_esp, p_ann, t_ann, wct)"""

ESP = """Examples:
--------
>>> from unifloc.pvt.fluid_flow import FluidFlow
>>> from unifloc.equipment.esp import Esp
>>>
>>> # Инициализация исходных данных
>>> # Считывание из json-базы паспортных характеристик насоса
>>> esp_data = {"ID": 99999, "source": "legacy", "manufacturer": "Reda",
...             "name": "DN500", "stages_max": 400, "rate_nom_sm3day": 30,
...             "rate_opt_min_sm3day": 20,
...             "rate_opt_max_sm3day": 40, "rate_max_sm3day": 66,
...             "slip_nom_rpm": 3000, "freq_Hz": 50, "eff_max": 0.4,
...             "height_stage_m": 0.035, "Series": 4, "d_od_mm": 86,
...             "d_cas_min_mm": 112, "d_shaft_mm": 17, "area_shaft_mm2": 227,
...             "power_limit_shaft_kW": 72, "power_limit_shaft_high_kW": 120,
...             "power_limit_shaft_max_kW": 150, "pressure_limit_housing_atma": 390,
...             "d_motor_od_mm": 95,
...             "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
...             "head_points": [4.88, 4.73, 4.66, 4.61, 4.52, 4.35, 4.1, 3.74,
...                             3.2800000000000002, 2.73, 2.11, 1.45, 0.77, 0],
...             "power_points": [0.02, 0.022, 0.025, 0.027, 0.03, 0.032, 0.035,
...                              0.038, 0.041, 0.043000000000000003,
...                              0.046, 0.049, 0.052000000000000005, 0.055],
...             "eff_points": [0, 0.12, 0.21, 0.29, 0.35000000000000003, 0.38,
...                            0.4, 0.39, 0.37, 0.32, 0.26, 0.19, 0.1, 0]
...             }
>>>
>>> # Инициализация свойств флюида
>>> q_fluid = 20
>>> wct = 0.1
>>> fluid_data = {"q_fluid": q_fluid / 86400, "wct": wct,
...               "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1,
...               "gamma_oil": 0.95, "rp": 50}}}
>>> # Инициализация модели флюида
>>> fluid1 = FluidFlow(**fluid_data)
>>> # Инициализация класса ЭЦН
>>> h_mes = 1600
>>> stages = 100
>>> viscosity_correction = False
>>> gas_correction = False
>>> esp_calculation = Esp(h_mes, stages, esp_data,
...                       fluid1, viscosity_correction, gas_correction,
...                       )
>>> # Необходимо подать давление и температуру на приеме/выкиде
>>> # насоса в зависимости от направления расчета
>>> # (например, если расчет идет от устья к забою, то подаем параметр direction_to="in",
>>> # температуру и давление
>>> # на выкиде  и в результате получаем давление на приеме насоса)
>>> p = 120 * 101325
>>> t = 30 + 273.15
>>> freq = 50
>>> direction_to = "in"
>>> # Поправка на напор (опционально, по умолчанию None)
>>> head_factor = 1
>>> # Коэффициент проскальзывания (опционально, по умолчанию 0.97222)
>>> slippage_factor = 0.97222
>>> # Расчет давления и температуры на выкиде или на приеме
>>> # (в зависимости от направления расчета)
>>> pt_calc = esp_calculation.calc_pt(p, t, freq, q_fluid/86400, wct,
...                                   direction_to=direction_to,
...                                   head_factor=head_factor,
...                                   slippage_factor=slippage_factor)"""

ESP_ELECTRIC_SYSTEM = """Examples:
--------
>>> from unifloc.tools import common_calculations as com
>>> from unifloc.equipment import esp_electric_system as elsys
>>> # Исходные данные для ПЭД
>>> motor_data = {
...     "ID": 1,
...     "manufacturer": "Centrilift",
...     "name": "562Centrilift-KMB-130-2200B",
...     "d_motor_mm": 142.7,
...     "motor_nom_i": 35,
...     "motor_nom_power": 96.98,
...     "motor_nom_voltage": 2200,
...     "motor_nom_eff": 80,
...     "motor_nom_cosf": 0.82,
...     "motor_nom_freq": 60,
...     "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
...     "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
...     "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
...     "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
...     "rpm_points": [
...         3568.604,
...         3551.63,
...         3534.656,
...         3517.682,
...         3500.708,
...         3483.734,
...         3466.76,
...         3449.786,
...         3432.812,
...         3415.838,
...     ],
... }
>>> # Гидравлическая мощность
>>> fluid_power = 20000
>>> # Мощность насоса
>>> pump_power = 50000
>>> # Номинальная мощность газосепаратора и протектора
>>> gassep_nom_power = 1000
>>> prot_nom_power = 1000
>>> # Параметры электрического кабеля
>>> t_cable = 90 + 273.15
>>> length_cable = 2800
>>> r_cable = 1.5
>>> # Номинальная частота вращения насоса
>>> pump_nom_freq = 50
>>> # Текущая частота вращения вала
>>> freq_shaft = 53
>>> # КПД трансформатора и станции управления
>>> transform_eff = 0.97
>>> cs_eff = 0.95
>>> # Параметры для адаптации
>>> adaptation_parameters = {
...     "cosf_fact": 0.88,
...     "motor_i_fact": 45,
...     "load_fact": 0.85,
...     "transform_voltage_fact": 2500,
...     "cs_power_fact": 100000,
... }
>>>
>>> # Инициализация класса с расчетом электрики
>>> calc_electric = elsys.EspElectricSystem(
...     motor_data,
...     pump_nom_freq,
...     length_cable,
...     gassep_nom_power,
...     prot_nom_power,
...     transform_eff,
...     cs_eff,
...     r_cable,
... )
>>> # Расчет адаптационных коэффициентов
>>> coeff = com.adapt_elsys(
...     calc_electric,
...     pump_power,
...     fluid_power,
...     freq_shaft,
...     t_cable,
...     **adaptation_parameters,
... )
>>>
>>> c_pump_power = coeff["c_pump_power"]
>>> c_cosf = coeff["c_cosf"]
>>> c_amperage = coeff["c_amperage"]
>>> c_transform_power = coeff["c_transform_power"]
>>> c_motor_volt = coeff["c_motor_volt"]
>>>
>>> # Расчет электрики
>>> results = calc_electric.calc_electric_esp_system(
...     pump_power,
...     fluid_power,
...     freq_shaft,
...     t_cable,
...     c_pump_power,
...     c_cosf,
...     c_amperage,
...     c_transform_power,
...     c_motor_volt,
... )
>>> # Расчет на другой частоте
>>> freq_shaft_new = 60
>>> pump_power_new = pump_power * (freq_shaft_new / freq_shaft) ** 3
>>> fluid_power_new = fluid_power * (freq_shaft_new / freq_shaft) ** 3
>>> results_new = calc_electric.calc_electric_esp_system(
...     pump_power_new,
...     fluid_power_new,
...     freq_shaft_new,
...     t_cable,
...     c_pump_power,
...     c_cosf,
...     c_amperage,
...     c_transform_power,
...     c_motor_volt,
... )"""

PIPELINE_CALC_PT = """Examples:
--------
>>> import pandas as pd
>>> import unifloc.tools.units_converter as uc
>>> import unifloc.common.trajectory as traj
>>> import unifloc.common.ambient_temperature_distribution as amb
>>> import unifloc.pipe.pipeline as pipel
>>> import unifloc.pvt.fluid_flow as fl
>>>
>>> # Инициализация исходных данных класса Pipeline
>>> trajectory = traj.Trajectory(pd.DataFrame(columns=["MD", "TVD"],
...                                      data=[[float(0), float(0)],
...                                            [float(1800), float(1800)]]))
>>> ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 363.15]}
>>> amb_temp = amb.AmbientTemperatureDistribution(ambient_temperature_data)
>>> fluid_data = {"q_fluid": uc.convert_rate(297.1, "m3/day", "m3/s"), "wct": 0.2871,
...               "pvt_model_data": {"black_oil":
...                    {"gamma_gas": 0.7, "gamma_wat": 1,
...                     "gamma_oil": 0.8, "rp": 401,
...                     "rsb": {"value": 90, "p": 15000000, "t": 363.15},
...                     "muob": {"value": 0.5, "p": 15000000, "t": 363.15},
...                     "bob": {"value": 1.5, "p": 15000000, "t": 363.15}, }}}
>>> fluid = fl.FluidFlow(**fluid_data)
>>> # Так тоже возможно: d = pd.DataFrame(columns=["MD", "d"],
>>> #                                     data=[[0, 0.062], [1000, 0.082]])
>>> # Так тоже возможно: d= {"MD": [0, 1000], "d": [0.06, 0.08]}
>>> d = 0.06
>>> top_depth = 0
>>> bottom_depth = 1800
>>> roughness = 0.0001
>>> p_wh = 20 * 101325  # Па
>>> flow_direction = 1
>>> # Инициализация объекта pvt-модели
>>> pipe = pipel.Pipeline(top_depth, bottom_depth, d, roughness,
...                       trajectory, fluid, amb_temp)
>>>
>>> # Расчет давления и температуры на забое от буфера
>>> results = pipe.calc_pt("top", p_wh, flow_direction)"""

PIPELINE_CALC_QLIQ = """Examples:
--------
>>> from unifloc.common.trajectory import Trajectory
>>> from unifloc.common.ambient_temperature_distribution import AmbientTemperatureDistribution
>>> from unifloc.pipe.pipeline import Pipeline
>>> from unifloc.pvt.fluid_flow import FluidFlow
>>> wct = 0.627
>>>
>>> well_trajectory = {"inclinometry": pd.DataFrame(columns=["MD", "TVD"], data=[[float(0), float(0)],
>>>                                                                              [float(85), float(0)]])}
>>> fluid_data = {"q_fluid": 16.229/86400, "wct": wct,
>>>               "pvt_model_data":
>>>                   {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.85, "rp": 69.9992,
>>>                    "rsb": {"value": 70, "p": 5000000, "t": 293.15},
>>>                    "muob": {"value": 0.5, "p": 5000000, "t": 293.15},
>>>                    "bob": {"value": 1.1, "p": 5000000, "t": 293.15}, }}}
>>>
>>> traject = Trajectory(well_trajectory["inclinometry"])
>>> fluid = FluidFlow(**fluid_data)
>>> ambient_temperature_data = {"MD": [0, 1000], "T": [303.15, 303.15]}
>>> amb_temp = AmbientTemperatureDistribution(ambient_temperature_data)
>>> Pipe = Pipeline(0, 85, d=0.01498, roughness=2.54 * 10 ** (-5), trajectory=traject,
>>>                 fluid=fluid, ambient_temperature_distribution=amb_temp, friction_factor=1, holdup_factor=1)
>>>
>>> q = Pipe.calc_qliq(p_top=17.35524*101325, p_bottom=14.659864823951027*101325,
>>>                              flow_direction=-1, wct=wct, hydr_corr_type="BeggsBrill", max_rate=20/86400)"""

ESP_WELL = """Examples:
--------
>>> # Пример исходных данных для насоса
>>> import pandas as pd
>>> import unifloc.tools.units_converter as uc
>>> from unifloc.well.esp_well import EspWell

>>> # Если мы хотим задать насос вручную, то нам соответственно нужно заполнить все строки
>>> # Например, при помощи словаря:
>>> esp_data = {"ID": 99999,
...         "source": "legacy",
...         "manufacturer": "Reda",
...         "name": "DN500",
...         "stages_max": 400,
...         "rate_nom_sm3day": 30,
...         "rate_opt_min_sm3day":20,
...         "rate_opt_max_sm3day":40,
...         "rate_max_sm3day": 66,
...         "slip_nom_rpm": 3000,
...         "freq_Hz": 50,
...         "eff_max": 0.4,
...         "height_stage_m": 0.035,
...         "Series": 4,
...         "d_od_mm": 86,
...         "d_cas_min_mm": 112,
...         "d_shaft_mm": 17,
...         "area_shaft_mm2": 227,
...         "power_limit_shaft_kW": 72,
...         "power_limit_shaft_high_kW": 120,
...         "power_limit_shaft_max_kW": 150,
...         "pressure_limit_housing_atma": 390,
...         "d_motor_od_mm": 95,
...         "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
...         "head_points": [4.88, 4.73, 4.66, 4.61, 4.52, 4.35, 4.1, 3.74, 3.28, 2.73, 2.11, 1.45, 0.77, 0],
...         "power_points": [0.02, 0.022, 0.025, 0.027, 0.03, 0.032, 0.035, 0.038, 0.041, 0.043, 0.046, 0.049,
...                            0.052000000000000005, 0.055],
...         "eff_points": [0, 0.12, 0.21, 0.29, 0.35, 0.38, 0.4, 0.39, 0.37, 0.32, 0.26, 0.19, 0.1, 0]
...         }
>>> # Можно задавать с помощью dict - esp_data = data
>>> esp_data = pd.Series(esp_data,name=esp_data["ID"])
>>> print(esp_data)
ID                                                                         99999
source                                                                    legacy
manufacturer                                                                Reda
name                                                                       DN500
stages_max                                                                   400
rate_nom_sm3day                                                               30
rate_opt_min_sm3day                                                           20
rate_opt_max_sm3day                                                           40
rate_max_sm3day                                                               66
slip_nom_rpm                                                                3000
freq_Hz                                                                       50
eff_max                                                                      0.4
height_stage_m                                                             0.035
Series                                                                         4
d_od_mm                                                                       86
d_cas_min_mm                                                                 112
d_shaft_mm                                                                    17
area_shaft_mm2                                                               227
power_limit_shaft_kW                                                          72
power_limit_shaft_high_kW                                                    120
power_limit_shaft_max_kW                                                     150
pressure_limit_housing_atma                                                  390
d_motor_od_mm                                                                 95
rate_points                    [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55,...
head_points                    [4.88, 4.73, 4.66, 4.61, 4.52, 4.35, 4.1, 3.74...
power_points                   [0.02, 0.022, 0.025, 0.027, 0.03, 0.032, 0.035...
eff_points                     [0, 0.12, 0.21, 0.29, 0.35, 0.38, 0.4, 0.39, 0...
Name: 99999, dtype: object

>>> # Исходные данные для ПЭД
>>> motor_data ={"ID": 1,
...         "manufacturer": "Centrilift",
...         "name": "562Centrilift-KMB-130-2200B",
...         "d_motor_mm": 142.7,
...         "motor_nom_i": 35,
...         "motor_nom_power": 96.98,
...         "motor_nom_voltage": 2200,
...         "motor_nom_eff": 80,
...         "motor_nom_cosf": 0.82,
...         "motor_nom_freq": 60,
...         "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
...         "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
...         "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
...         "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
...         "rpm_points": [3568.604, 3551.63, 3534.656, 3517.682, 3500.708, 3483.734, 3466.76, 3449.786,
...                       3432.812, 3415.838]
...         }

>>> # Инициализация исходных данных
>>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1200], [1800, 1542.85]])
>>> # Возможный способ задания инклинометрии через dict
>>> # df = {"MD": [0, 1000],
>>> #       "TVD": [0, 900]}
>>>
>>> # В словари с калибровками подается давление и температура калибровки.
>>> # Зачастую - это давление насыщения и пластовая температура
>>> fluid_data = {"q_fluid": uc.convert_rate(40, "m3/day", "m3/s"), "wct": 0,
...      "pvt_model_data": {
...          "black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 20,
...                "oil_correlations": {"pb": "Standing", "rs": "Standing", "rho": "Standing",
...                                     "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
...                "gas_correlations": {"ppc": "Standing", "tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
...                "water_correlations": {"b": "McCain", "compr": "Kriel", "rho": "Standing", "mu": "McCain"},
...                "rsb": {"value": 50, "p": 10000000, "t": 303.15},
...                "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...                "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...                "table_model_data": None, "use_table_model": False}}}
>>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
>>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
>>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
>>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005}}
>>> well_trajectory_data = {"inclinometry": df}
>>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
>>> equipment_data = {"esp_system": {"esp": {"esp_data": esp_data,
...                                         "stages": 345,
...                                         "viscosity_correction": True,
...                                         "gas_correction": True,
...                                         },
...                                 "esp_electric_system": {"motor_data": motor_data,
...                                                         "gassep_nom_power": 500,
...                                                         "protector_nom_power": 500,
...                                                         "transform_eff": 0.97,
...                                                         "cs_eff": 0.97,
...                                                         "cable_specific_resistance": 1.18,
...                                                         "cable_length": 1450,
...                                                         },
...                                 "separator": {"k_gas_sep": 0.7,
                                                "sep_name": '3МНГДБ5'}},
...                     "packer": False}
>>> # Текущая частота
>>> freq = 53
>>> # Затрубное давление
>>> p_ann = 10 * 101325

>>> # Инициализация объекта скважины
>>> well = EspWell(fluid_data, pipe_data, equipment_data, well_trajectory_data,
...                ambient_temperature_data)
>>> # Расчет с сохранением доп. атрибутов распределений свойств
>>> result = well.calc_pwf_pfl(uc.convert_pressure(12, "atm", "Pa"),
...                          uc.convert_rate(40, "m3/day", "m3/s"),
...                          0.1, freq, p_ann=p_ann, output_params=True)
>>> # Запрос всех значений доп. свойств в виде словаря
>>> extra_results = well.extra_output"""

TRAJ = """Examples:
--------
>>> import pandas as pd
>>> from unifloc.common.trajectory import Trajectory
>>> inclinometry = pd.DataFrame(columns=["MD", "TVD"],
...                             data=[[0, 0], [1400, 1400],
...                             [1800, 1542.85], [2000, 1700]])
>>> trajectory = Trajectory(inclinometry)
>>> tvd = trajectory.calc_tvd(1000)"""

SEP = """Examples:
--------
>>> from unifloc.equipment.natural_separation import NaturalSeparation
>>> from unifloc.equipment.separator import Separator
>>> # Расчет естественной сепарации
>>> # Инициализация исходных данных для расчета естественной сепарации
>>> h_mes_ = 1800
>>> d_tub = 0.063
>>> d_cas = 0.130
>>> q_fluid = 100 / 86400
>>> q_gas = 0
>>> sigma_l = 24
>>> rho_liq = 836
>>> rho_gas = 0.84
>>> # Инициализация класса расчета естественной сепарации
>>> k_sep_nat_calc = NaturalSeparation(h_mes_)
>>> # Расчет коэффициента естественной сепарации
>>> k_sep_natural = k_sep_nat_calc.calc_separation(d_tub, d_cas, q_fluid, q_gas,
...                                                sigma_l, rho_liq, rho_gas)
>>> # Инициализация исходных данных для расчета общей сепарации
>>> k_gas_sep = 0.7
>>> # Инициализация класса расчета общей сепарации
>>> k_gassep_calc = Separator(h_mes_, k_gas_sep)
>>> # Расчет коэффициента общей сепарации
>>> k_sep_total = k_gassep_calc.calc_general_separation(k_sep_natural)"""

NATSEP = """Examples:
--------
>>> from unifloc.equipment.natural_separation import NaturalSeparation
>>> # Инициализация исходных данных
>>> h_mes_ = 1800
>>> d_tub = 0.063
>>> d_cas = 0.130
>>> q_fluid = 100/86400
>>> q_gas = 0
>>> sigma_l = 24
>>> rho_liq = 836
>>> rho_gas = 0.84
>>> # Инициализация объекта для расчета естественной сепарации
>>> k_sep_nat_calc = NaturalSeparation(h_mes_)
>>> # Расчет коэффициента естественной сепарации
>>> k_sep_natural = k_sep_nat_calc.calc_separation(d_tub, d_cas, q_fluid, q_gas,
...                                                sigma_l, rho_liq, rho_gas)"""

FLUID_FLOW = """Examples:
--------
>>> import pandas as pd
>>> from unifloc.pvt.fluid_flow import FluidFlow
>>> # Инициализация исходных данных класса FluidFlow
>>> q_fluid = 100 / 86400
>>> wct = 0
>>> dmuo = {"p": [1, 3398818, 3898840, 4898883, 5898926, 6898978, 7699015],
...         "274.15": [1876, 1348.31, 1274.77, 1138.84, 1017.39, 909.557, 832.379],
...         "278.15": [1180, 848.084, 801.83, 716.331, 639.933, 572.11, 523.565],
...         "283.15": [828, 595.097, 562.64, 502.646, 449.039, 401.446, 367.383],
...         "288.15": [537, 385.95, 364.901, 325.991, 291.224, 260.358, 238.266],
...         "293.15": [250.341, 179.924, 170.111, 151.972, 135.764, 121.375, 111.076],}
>>> dfmuo = pd.DataFrame(dmuo)
>>> dmul = {"wct": [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
...         "274.15": [1876, 2000, 2200, 2650, 3500, 5800, 7000, 4200, 1500, 700],
...         "278.15": [1180, 1300, 1500, 2000, 2900, 4700, 5600, 3100, 1000, 600],
...         "283.15": [828, 1000, 1500, 1700, 2500, 4200, 5200, 3000, 700, 500],
...         "288.15": [537, 700, 1000, 1200, 1800, 2600, 3000, 2000, 800, 250],
...         "293.15": [250.341, 500, 600, 900, 1200, 2200, 2800, 1500, 420, 240],}
>>> dfmul = pd.DataFrame(dmul)
>>> pvt_model_data = {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
...                                 "rp": 50,
...                                 "oil_correlations":
...                                  {"pb": "Standing", "rs": "Standing",
...                                   "rho": "Standing","b": "Standing",
...                                   "mu": "Beggs", "compr": "Vasquez"},
...                     "gas_correlations": {"ppc": "Standing", "tpc": "Standing",
...                                          "z": "Dranchuk", "mu": "Lee"},
...                     "water_correlations": {"b": "McCain", "compr": "Kriel",
...                                            "rho": "Standing", "mu": "McCain"},
...                     "rsb": {"value": 50, "p": 10000000, "t": 303.15},
...                     "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...                     "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...                     "table_model_data": None, "use_table_model": False,
...                     "table_mu": {"mul": dfmul, "muo": dfmuo}}}
>>>
>>> # Инициализация исходных данных метода расчета pvt-свойств флюидов
>>> p = 4 * (10 ** 6)
>>> t = 350
>>>
>>> # Инициализация объекта pvt-модели
>>> fluid_flow = FluidFlow(q_fluid, wct, pvt_model_data)
>>>
>>> # Пересчет всех свойств для данного давления и температуры
>>> fluid_flow.calc_flow(p, t)
>>>
>>> # Вывод параметра вязкости жидкости
>>> mul = fluid_flow.mul"""

CHOKE = """Examples:
--------
>>> # Пример исходных данных для штуцера
>>> from unifloc.pvt.fluid_flow import FluidFlow
>>> from unifloc.equipment.choke import Choke
>>>
>>>
>>> fluid_data = {"q_fluid": 100 / 86400, "wct": 0.1,
...              "pvt_model_data": {
...              "black_oil": {"gamma_gas": 0.6, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 80,
...                            "oil_correlations": {"pb": "Standing", "rs": "Standing",
... "rho": "Standing",
...                                                 "b": "Standing", "mu": "Beggs",
... "compr": "Vasquez",
...                                                 "hc": "const"},
...                            "gas_correlations": {"ppc": "Standing", "tpc": "Standing",
... "z": "Dranchuk",
...                                                 "mu": "Lee", "hc": "const"},
...                            "water_correlations": {"b": "McCain", "compr": "Kriel",
... "rho": "Standing",
...                                                    "mu": "McCain", "hc": "const"},
...                            "rsb": {"value": 50, "p": 10000000, "t": 303.15},
...                            "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...                            "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...                            "table_model_data": None, "use_table_model": False}}}
>>> h_mes = 1000
>>> d_choke = 0.005
>>> d_up = 0.062
>>>
>>> p_fl = 1000000
>>> t_fl = 303.15
>>>
>>> fluid = FluidFlow(**fluid_data)
>>> test = Choke(h_mes=h_mes, d=d_choke, d_up=d_up, fluid=fluid)
>>> results = test.calc_pt(p_fl, t_fl, 1)"""

GL_WELL_VL = """Examples:
--------
>>> import pandas as pd
>>> import unifloc.tools.units_converter as uc
>>> from unifloc.well.gaslift_well_one_valve import GasLiftWellOneValve
>>> # Инициализация исходных данных
>>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]])
>>> # Возможный способ задания инклинометрии через dict
>>> # df = {"MD": [0, 1000],
>>> #       "TVD": [0, 900]}
>>>
>>> # В словари с калибровками подается давление и температура калибровки.
>>> # Зачастую - это давление насыщения и пластовая температура
>>> fluid_data = {"q_fluid": uc.convert_rate(100, "m3/day", "m3/s"), "wct": 0.1,
...               "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
...               "rp": 300,
...               "oil_correlations": {"pb": "Standing", "rs": "Standing","rho": "Standing",
...               "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
...               "gas_correlations":
...               {"ppc": "Standing","tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
...               "water_correlations": {"b": "McCain", "compr": "Kriel","rho": "Standing",
...               "mu": "McCain"},
...               "rsb": {"value": 300, "p": 10000000, "t": 303.15},
...               "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...               "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...               "table_model_data": None, "use_table_model": False}}}
>>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
>>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
>>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
>>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001, "s_wall": 0.005},
...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005}}
>>> well_trajectory_data = {"inclinometry": df}
>>> equipment_data = {"gl_system": {
...                   "valve1": {"h_mes": 800, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve2": {"h_mes": 850, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve3": {"h_mes": 900, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"},
...                   "valve4": {"h_mes": 1000, "d": 0.006,
...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
...                              "valve_type": "ЦКсОК"}
...                                               }
...                   }
>>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
>>>
>>> # Инициализация объекта скважины
>>> well = GasLiftWellOneValve(fluid_data, pipe_data, well_trajectory_data,
...                    ambient_temperature_data, equipment_data)
>>> # Расчет линейного давления
>>> parameters = well.calc_pwh_pwf(p_wf=uc.convert_pressure(20, "MPa", "Pa"),
...                                q_liq=uc.convert_rate(100, "m3/day", "m3/s"), wct=0.1,
...                                p_gas_inj=uc.convert_pressure(15, "MPa", "Pa"))
>>> # Расчет забойного давления
>>> p_fl = parameters[0]
>>> q_inj = well.gl_system.q_inj
>>> # Расчет с сохранением доп. атрибутов распределений свойств
>>> p_wf = well.calc_pwf_pfl(p_fl=p_fl, q_liq=uc.convert_rate(100, "m3/day", "m3/s"), wct=0.1,
...                          q_gas_inj=q_inj,
...                          output_params=True)
>>> # Запрос всех значений доп. свойств в виде словаря
>>> result = well.extra_output
>>> result_ann = well.extra_output_annulus"""

GL_WELL_VLS = """Examples:
--------
>>> import pandas as pd
>>> import unifloc.tools.units_converter as uc
>>> from unifloc.well.gaslift_well_several_valves import GasLiftWellSeveralValves
>>> # Инициализация исходных данных
>>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]])
>>> # Возможный способ задания инклинометрии через dict
>>> # df = {"MD": [0, 1000],
>>> #       "TVD": [0, 900]}
>>>
>>> # В словари с калибровками подается давление и температура калибровки.
>>> # Зачастую - это давление насыщения и пластовая температура
>>> fluid_data = {"q_fluid": uc.convert_rate(100, "m3/day", "m3/s"), "wct": 0.1,
...               "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
...               "rp": 300,
...               "oil_correlations": {"pb": "Standing", "rs": "Standing","rho": "Standing",
...               "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
...               "gas_correlations":
...               {"ppc": "Standing","tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
...               "water_correlations": {"b": "McCain", "compr": "Kriel","rho": "Standing",
...               "mu": "McCain"},
...               "rsb": {"value": 300, "p": 10000000, "t": 303.15},
...               "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
...               "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
...               "table_model_data": None, "use_table_model": False}}}
>>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
>>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
>>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
>>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001, "s_wall": 0.005},
...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005}}
>>> well_trajectory_data = {"inclinometry": df}
>>> equipment_data = {"gl_system": {
...    "valve1": {"h_mes": 1300, "d": 0.003, "s_bellow": 0.000199677,
...               "p_valve": uc.convert_pressure(50, "atm", "Pa"),
...               "valve_type": "ЦКсОК"},
...    "valve2": {"h_mes": 1100, "d": 0.004, "s_bellow": 0.000195483,
...               "p_valve": uc.convert_pressure(60, "atm", "Pa"),
...               "valve_type": "ЦКсОК"},
...    "valve3": {"h_mes": 800, "d": 0.005, "s_bellow": 0.000199032,
...               "p_valve": uc.convert_pressure(40, "atm", "Pa"),
...               "valve_type": "ЦКсОК"},
...    "valve4": {"h_mes": 900, "d": 0.004, "s_bellow": 0.000199032,
...               "p_valve": uc.convert_pressure(50, "atm", "Pa"),
...               "valve_type": "ЦКсОК"}},
...    }
>>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
>>>
>>> # Инициализация объекта скважины
>>> well = GasLiftWellSeveralValves(fluid_data, pipe_data, well_trajectory_data,
...                    ambient_temperature_data, equipment_data)
>>> # Расчет забойного давления
>>> p_fl = 10 * 101325
>>> q_inj = 100 / 86400
>>> p_inj = 100 * 101325
>>> # Расчет с сохранением доп. атрибутов распределений свойств
>>> p_wf = well.calc_pwf_pfl(p_fl=p_fl, q_liq=uc.convert_rate(100, "m3/day", "m3/s"), wct=0.1,
...                          q_gas_inj=q_inj, p_gas_inj=p_inj,
...                          output_params=True)
>>> # Запрос всех значений доп. свойств в виде словаря
>>> result = well.extra_output
>>> result_ann = well.extra_output_annulus"""