import unittest

from unifloc.tools.common_calculations import PipePressSep


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.fluid_data = {
            "q_fluid": 100 / 86400,
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        self.d = {"MD": [0, 1400], "d": [0.062, 0.082]}
        self.pipe_data = {
                "top_depth": 1400,
                "bottom_depth": 1800,
                "d": 0.128,
                "roughness": 0.0001,
        }

        self.trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
        self.well_trajectory_data = {"inclinometry": self.trajectory}

        self.equipment_data = {"packer": False, "separator": None}

        self.ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        self.potential = PipePressSep(
            self.fluid_data,
            self.pipe_data,
            self.equipment_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        print(self.shortDescription())

    def test_calc_pressure_and_sep(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем
        """
        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq = 100 / 86400
        h_top = 1500

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top
        )

        self.assertAlmostEqual(p_wf, 6899745.427282498, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.5391400960841555, delta=0.01)

    def test_calc_pressure_and_sep_h_top_none(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем, если не указана
        глубина верхнего конца трубы
        """
        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq = 100 / 86400
        h_top = None

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top
        )

        self.assertAlmostEqual(p_wf, 7509930.60352168, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.5391400960841555, delta=0.01)

    def test_calc_pressure_and_sep_t_top_none(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем, если не указана
        температура на верхнем конце трубы
        """
        p_top = 50 * 101325
        q_liq = 100 / 86400
        h_top = None
        t_top = None

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top
        )

        self.assertAlmostEqual(p_wf, 7509930.60352168, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.5342652262987506, delta=0.01)

    def test_calc_pressure_and_sep_init_fluid(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем при разных
        значениях дебита
        """
        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq1 = 100 / 86400
        q_liq2 = 400 / 86400
        h_top = 1500

        p_wf1, gas_frac1 = self.potential.calc_pressure_and_sep(
            q_liq1, p_top, t_top, h_top
        )
        p_wf2, gas_frac2 = self.potential.calc_pressure_and_sep(
            q_liq2, p_top, t_top, h_top
        )

        self.assertNotEqual(p_wf1, p_wf2)
        self.assertAlmostEqual(gas_frac1, gas_frac2, delta=0.01)

    def test_calc_pressure_and_sep_packer(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем при наличии
        пакера (отключается ествественная сепарация)
        """
        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq = 100 / 86400
        h_top = 1500

        equipment_data_new = self.equipment_data.copy()
        equipment_data_new.update({"packer": True})

        self.potential = PipePressSep(
            self.fluid_data,
            self.pipe_data,
            equipment_data_new,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top
        )

        self.assertAlmostEqual(p_wf, 6899745.427282498, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.7007321739696472, delta=0.01)

    def test_calc_pressure_and_sep_separator(self):
        """
        PipePressSep: Расчет давления на нижнем конце трубы и доли газа на верхнем c учетом
        сепаратора
        """

        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq = 100 / 86400
        h_top = 1500

        equipment_data_new = self.equipment_data.copy()
        equipment_data_new.update({"separator": 0.7})

        self.potential = PipePressSep(
            self.fluid_data,
            self.pipe_data,
            equipment_data_new,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top
        )

        self.assertAlmostEqual(p_wf, 6899745.427282498, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.25910918844771846, delta=0.01)

    def test_calc_pressure_and_sep_c_grav(self):
        """
        PipePressSep:Расчет давления на нижнем конце трубы и доли газа на верхнем с учетом
        коэффициента на гравитацию
        """
        p_top = 50 * 101325
        t_top = 30 + 273.15
        q_liq = 100 / 86400
        h_top = 1500
        grav_holdup_factor = 1.8

        p_wf, gas_frac = self.potential.calc_pressure_and_sep(
            q_liq, p_top, t_top, h_top, grav_holdup_factor=grav_holdup_factor
        )

        self.assertAlmostEqual(p_wf, 7061335.328640401, delta=0.01)
        self.assertAlmostEqual(gas_frac, 0.5391400960841555, delta=0.01)


if __name__ == "__main__":
    unittest.main()