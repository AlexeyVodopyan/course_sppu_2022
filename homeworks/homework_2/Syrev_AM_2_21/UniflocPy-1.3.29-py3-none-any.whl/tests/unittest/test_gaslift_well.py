import ast
import copy
import json
import os
import sys
import unittest

import pandas as pd
import numpy.testing as npt

import tests.unittest.example_strings as exs
import unifloc.service._constants as const
import unifloc.tools.units_converter as uc
import unifloc.tools.exceptions as exc
import unifloc.well.gaslift_well as gl_well


class TestGasLiftWell(unittest.TestCase):
    def setUp(self) -> None:
        self.fluid_data = {
            "q_fluid": 100 / 86400,
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        self.d = {"MD": [0, 1000], "d": [0.062, 0.082]}
        self.pipe_data = {
            "casing": {
                "bottom_depth": 1800,
                "d": 0.146,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
            "tubing": {
                "bottom_depth": 1400,
                "d": self.d,
                "roughness": 0.0001,
                "s_wall": 0.005,
            },
        }
        self.trajectory = {"MD": [0, 1000], "TVD": [0, 900]}
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1000,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        self.equipment_data_new = {
            "gl_system": {
                "valve1": {
                    "h_mes": 1300,
                    "d": 0.003,
                    "s_bellow": 0.000199677,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 1100,
                    "d": 0.004,
                    "s_bellow": 0.000195483,
                    "p_valve": uc.convert_pressure(60, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 800,
                    "d": 0.005,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(40, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 900,
                    "d": 0.004,
                    "s_bellow": 0.000199032,
                    "p_valve": uc.convert_pressure(50, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            },
        }
        self.ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )

        print(self.shortDescription())

    def test_set_inclinometry_dataframe_with_zeros(self):
        """
        GasLiftWell: Установка инклинометрии DataFrame-ом с нулями
        """
        self.trajectory.update({"MD": [0, 1000], "TVD": [0, 900]})
        self.well_trajectory_data = {
            "inclinometry": pd.DataFrame.from_dict(self.trajectory)
        }
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        self.assertTrue(
            (self.gl_well.well_trajectory_data["inclinometry"].iloc[0] == [0, 0]).all()
        )

    def test_set_inclinometry_dict_with_zeros(self):
        """
        GasLiftWell: Установка инклинометрии dict-ом с нулями
        """
        self.trajectory.update({"MD": [0, 1000], "TVD": [0, 900]})
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        self.assertTrue(
            self.gl_well.well_trajectory_data["inclinometry"]["MD"][0]
            == 0 & self.gl_well.well_trajectory_data["inclinometry"]["TVD"][0]
            == 0
        )

    def test_set_inclinometry_dict_no_zeros(self):
        """
        GasLiftWell: Установка инклинометрии dict-ом без нулей
        """
        self.trajectory.update({"MD": [1000], "TVD": [900]})
        self.well_trajectory_data = {"inclinometry": self.trajectory}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        self.assertTrue(
            self.gl_well.well_trajectory_data["inclinometry"]["MD"][0]
            == 0 & self.gl_well.well_trajectory_data["inclinometry"]["TVD"][0]
            == 0
        )

    def test_set_inclinometry_dataframe_no_zeros(self):
        """
        GasLiftWell: Установка инклинометрии DataFrame-ом без нулей
        """
        self.trajectory.update({"MD": [1000], "TVD": [900]})
        self.well_trajectory_data = {
            "inclinometry": pd.DataFrame.from_dict(self.trajectory)
        }
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        self.assertTrue(
            (self.gl_well.well_trajectory_data["inclinometry"].iloc[0] == [0, 0]).all()
        )

    def test_calc_pwf_pfl(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 6930868.812543625, delta=1000)

    def test_calc_pwf_pfl_choke_1(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного и коэффициента
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 11299529.110610481, delta=1000)

    def test_calc_pwf_pfl_choke_2(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного
        с с_choke = 1.3
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj, c_choke=1.3)
        self.assertAlmostEqual(pwf, 8468684.279821225, delta=1000)

    def test_calc_pwf_pfl_choke_adapt(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм с штуцером, с буферным и
        адаптацией штуцера
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        pwh = 15 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, c_choke=None, p_wh=pwh
        )
        self.assertAlmostEqual(pwf, 7603132.659629892, delta=1000)

    def test_calc_pwf_pfl_choke_adapt_const(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм с штуцером без буферного
        и с постоянным перепадом на штуцере
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        pwh = 12 * 101325
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, c_choke={"const": pwh - pfl}
        )
        self.assertAlmostEqual(pwf, 7177886.489120067, delta=1000)

    def test_calc_pwf_pfl_choke_extra(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм с штуцером с доп. распределениями
        """

        equipment_data = copy.deepcopy(self.equipment_data)
        equipment_data["choke"] = {"d": 0.01}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        pwf = self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )
        self.assertAlmostEqual(pwf, 11299529.110610481, delta=1000)
        self.assertAlmostEqual(len(self.gl_well.extra_output), 47)

    def test_calc_pwf_pfl_output1(self):
        """
        GasLiftWell: расчет забойного давления от линейного = 10 атм c дополнительными атрибутами
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400

        self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )

        self.assertIsInstance(self.gl_well.extra_output, dict)
        self.assertEqual(len(self.gl_well.extra_output), len(const.DISTRS) + 4)

        for par in const.DISTRS:
            self.assertIsNotNone(self.gl_well.extra_output.get(par))

    def test_calc_pfl_pwf(self):
        """
        GasLiftWell: Расчет линейного давления от забойного = 200 атм
        """
        pwf = 200 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        q_gas_inj = 10000 / 86400
        pfl = self.gl_well.calc_pfl_pwf(pwf, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pfl[0], 9900225.55167614, delta=1000)
        self.assertEqual(pfl[1], 0)

    def test_calc_pfl_pwf_before_p_in(self):
        """
        GasLiftWell: Расчет линейного давления от забойного для случая не доходя до башмака НКТ
        """
        pwf = 2 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        q_gas_inj = 10000 / 86400
        pfl = self.gl_well.calc_pfl_pwf(
            pwf, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )
        self.assertAlmostEqual(pfl[0], 89999.99999999997, delta=1000)
        self.assertEqual(pfl[1], 1)

    def test_calc_pfl_pwf_before_p_inj(self):
        """
        GasLiftWell: Расчет линейного давления от забойного для случая не доходя до клапана
        """
        pwf = 20 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        q_gas_inj = 10000 / 86400
        pfl = self.gl_well.calc_pfl_pwf(
            pwf, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )
        self.assertAlmostEqual(pfl[0], 90000.00000000023, delta=1000)
        self.assertEqual(pfl[1], 1)

    def test_calc_pfl_pwf_before_p_wh(self):
        """
        GasLiftWell: Расчет линейного давления от забойного для случая не дохода до буфера
        """
        pwf = 50 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        q_gas_inj = 10000 / 86400
        pfl = self.gl_well.calc_pfl_pwf(
            pwf, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )
        self.assertAlmostEqual(pfl[0], 90000.00000000067, delta=1000)
        self.assertEqual(pfl[1], 1)

    def test_extra_to_json(self):
        """
        GasLiftWell: Проверка конвертируемости распределений в Json для случая
        глубина клапана < глубины НКТ
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )

        self.assertIsInstance(json.dumps(self.gl_well.extra_output), str)

    def test_extra_to_json_gray(self):
        """
        GasLiftWell: Проверка конвертируемости распределений в Json для случая
        глубина клапана < глубины НКТ и корреляции Gray
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.gl_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            q_gas_inj=q_gas_inj,
            output_params=True,
            hydr_corr_type="gray",
        )

        self.assertIsInstance(json.dumps(self.gl_well.extra_output), str)

    def test_calc_pwf_pfl_gl_error(self):
        """
        GasLiftWell: Расчет забойного давления от линейного = 10 атм для глубины клапана больше
        глубины НКТ
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 10000,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        with self.assertRaises(exc.GlValveError):
            self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)

    def test_negative_depth_calc_pwf_pfl(self):
        """
        GasLiftWell: Проверка отрицательности массива глубин при расчете забойного давления
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)

        self.assertTrue(
            all(list(map(lambda x: x <= 0, self.gl_well.extra_output["depth"])))
        )

    def test_negative_depth_calc_pfl_pwf(self):
        """
        GasLiftWell: Проверка отрицательности массива глубин при расчете линейного давления
        """
        pwf = 200 * 101325
        wct = 0.1
        q_liq = 100 / 86400
        q_gas_inj = 10000 / 86400
        self.gl_well.calc_pfl_pwf(pwf, q_liq, wct, q_gas_inj=q_gas_inj)

        self.assertTrue(
            all(list(map(lambda x: x <= 0, self.gl_well.extra_output["depth"])))
        )

    def test_calc_pwf_pfl_output_check(self):
        """
        GasLiftWell: Проверка создания доп.атрибутов для корреляции Gray, задание с помощью "all"
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        hydr_corr_type = "gray"
        self.gl_well.calc_pwf_pfl(
            pfl,
            q_liq,
            wct,
            q_gas_inj=q_gas_inj,
            hydr_corr_type=hydr_corr_type,
            output_params=True,
        )

        for par in const.DISTRS:
            if par != "flow_pattern":
                self.assertIsNotNone(self.gl_well.extra_output.get(par))
            else:
                self.assertIsNone(self.gl_well.extra_output.get(par))

    def test_check_not_nan(self):
        """
        GasLiftWell: Проверка конвертируемости распределений в Json для случая
        глубина клапана = глубине НКТ
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1400,
                    "d": 0.006,
                    "p_valve": 3 * 10125,
                    "valve_type": "ЦКсОК",
                },
            }
        }
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            self.equipment_data,
        )
        self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertIsInstance(json.dumps(self.gl_well.extra_output), str)

    def test_self_flow_well_equipment_data_none(self):
        """
        SelfFlowWell: Проверка расчета забойного давления для фонтанной скважины для
        equipment_data=None
        """
        equipment_data = None
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 6961742.840518642, delta=1000)

    def test_self_flow_well_gl_system_none(self):
        """
        SelfFlowWell: Проверка расчета забойного давления для фонтанной скважины для gl_system=None
        """
        equipment_data = {"gl_system": None}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 6961742.840518642, delta=1000)

    def test_self_flow_well_no_gl_system(self):
        """
        SelfFlowWell: Проверка расчета забойного давления для фонтанной скважины для словаря
        без gl_system
        """
        equipment_data = {}
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
            equipment_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 6961742.840518642, delta=1000)

    def test_self_flow_well_no_equipment_data(self):
        """
        SelfFlowWell: Проверка расчета забойного давления для фонтанной скважины без equipment_data
        """
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        pwf = self.gl_well.calc_pwf_pfl(pfl, q_liq, wct, q_gas_inj=q_gas_inj)
        self.assertAlmostEqual(pwf, 6961742.840518642, delta=1000)

    def test_p_array(self):
        """
        SelfFlowWell: Проверка распределения давления
        """
        self.gl_well = gl_well.GasLiftWell(
            self.fluid_data,
            self.pipe_data,
            self.well_trajectory_data,
            self.ambient_temperature_data,
        )
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 0
        pwf = self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )
        results = self.gl_well.extra_output
        print(results.get("p"))
        npt.assert_almost_equal(
            results.get("p"),
            [
                1013250.0,
                1013645.0198883562,
                1017593.5404701773,
                1056822.535756074,
                1400928.016161528,
                1814882.797435424,
                2581460.2710668584,
                3841729.7424735175,
                4441238.16397735,
                4441238.16397735,
                4442604.482990086,
                4456266.847621784,
                4592807.174369787,
                5949280.971333808,
                6960880.909925072,
            ],
            decimal=2,
        )

    def test_docstring_example(self):
        """
        GasLiftWell: Проверка работоспособности примера из docstring
        """
        file_path = os.path.abspath(sys.modules[gl_well.GasLiftWell.__module__].__file__)

        with open(file_path, encoding="utf8") as f:
            file_contents = f.read()

        module = ast.parse(file_contents)
        class_definitions = [
            node for node in module.body if isinstance(node, ast.ClassDef)
        ]

        doc_string = ast.get_docstring(
            [
                node
                for node in class_definitions[0].body
                if isinstance(node, ast.FunctionDef)
            ][0]
        )

        example_string = doc_string[doc_string.find("Examples") :]

        self.assertEqual(example_string, exs.GL_WELL)

        # Инициализация исходных данных
        df = pd.DataFrame(
            columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]]
        )
        # Возможный способ задания инклинометрии через dict
        # df = {"MD": [0, 1000],
        #       "TVD": [0, 900]}
        # В словари с калибровками подается давление и температура калибровки.
        # Зачастую - это давление насыщения и пластовая температура
        fluid_data = {
            "q_fluid": uc.convert_rate(100, "m3/day", "m3/s"),
            "wct": 0.1,
            "pvt_model_data": {
                "black_oil": {
                    "gamma_gas": 0.7,
                    "gamma_wat": 1,
                    "gamma_oil": 0.8,
                    "rp": 300,
                    "oil_correlations": {
                        "pb": "Standing",
                        "rs": "Standing",
                        "rho": "Standing",
                        "b": "Standing",
                        "mu": "Beggs",
                        "compr": "Vasquez",
                    },
                    "gas_correlations": {
                        "ppc": "Standing",
                        "tpc": "Standing",
                        "z": "Dranchuk",
                        "mu": "Lee",
                    },
                    "water_correlations": {
                        "b": "McCain",
                        "compr": "Kriel",
                        "rho": "Standing",
                        "mu": "McCain",
                    },
                    "rsb": {"value": 300, "p": 10000000, "t": 303.15},
                    "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
                    "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
                    "table_model_data": None,
                    "use_table_model": False,
                }
            },
        }
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        pipe_data = {
            "casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
            "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001},
        }
        well_trajectory_data = {"inclinometry": df}
        equipment_data = {
            "gl_system": {
                "valve1": {
                    "h_mes": 800,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve2": {
                    "h_mes": 850,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve3": {
                    "h_mes": 900,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
                "valve4": {
                    "h_mes": 1000,
                    "d": 0.006,
                    "p_valve": uc.convert_pressure(3, "atm", "Pa"),
                    "valve_type": "ЦКсОК",
                },
            }
        }
        ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}

        # Инициализация объекта скважины
        well = gl_well.GasLiftWell(
            fluid_data,
            pipe_data,
            well_trajectory_data,
            ambient_temperature_data,
            equipment_data,
        )
        # Расчет линейного давления
        parameters = well.calc_pfl_pwf(
            uc.convert_pressure(20, "MPa", "Pa"),
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            q_gas_inj=uc.convert_rate(10000, "m3/day", "m3/s"),
        )
        # Расчет забойного давления
        p_fl = parameters[0]
        self.assertAlmostEqual(p_fl, 8695158.85234786, delta=1000)

        p_wf = well.calc_pwf_pfl(
            p_fl,
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            q_gas_inj=uc.convert_rate(100000, "m3/day", "m3/s"),
        )
        # Расчет с сохранением доп. атрибутов распределений свойств
        well.calc_pwf_pfl(
            p_fl,
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            q_gas_inj=uc.convert_rate(100000, "m3/day", "m3/s"),
            output_params=True,
        )
        # Или можно указать что "all", тогда рассчитаются все возможные
        p_wf = well.calc_pwf_pfl(
            p_fl,
            uc.convert_rate(100, "m3/day", "m3/s"),
            0.1,
            q_gas_inj=uc.convert_rate(100000, "m3/day", "m3/s"),
            output_params=True,
        )
        # Запрос всех значений доп. свойств в виде словаря
        result = well.extra_output
        self.assertAlmostEqual(p_wf, 18089553.333663046, delta=1000)

    def test_nodes_distribution(self):
        """
        GasLiftWell: Тестирование создания распределения ключевых узлов
        """
        pfl = 10 * 101325
        q_liq = 100 / 86400
        wct = 0.1
        q_gas_inj = 10000 / 86400
        self.gl_well.calc_pwf_pfl(
            pfl, q_liq, wct, q_gas_inj=q_gas_inj, output_params=True
        )

        self.assertEqual(
            self.gl_well.extra_output.get("nodes"),
            [
                "Буфер",
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                "Точка ввода газа",
                None,
                None,
                None,
                None,
                None,
                "Башмак НКТ",
                None,
                None,
                None,
                None,
                None,
                "Верхние дыры перфорации",
            ],
        )


if __name__ == "__main__":
    unittest.main()
