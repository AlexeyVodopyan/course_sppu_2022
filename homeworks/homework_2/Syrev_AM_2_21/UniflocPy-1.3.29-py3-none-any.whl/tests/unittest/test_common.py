import unittest

import unifloc.equipment.choke as ch
from unifloc.equipment import esp_electric_system as esys
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.common_calculations as com


class TestChokeAdapt(unittest.TestCase):
    def setUp(self) -> None:
        fluid_data = {"q_fluid": 40 / 86400, "wct": 0,
             "pvt_model_data": {
                 "black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 50}}}

        self.fluid = fl.FluidFlow(**fluid_data)

    def test_choke_adaptation_brentq(self):
        """Choke: адаптация с отработкой через brentq"""
        choke = ch.Choke(0, 0.01, 0.062, self.fluid)
        p_fl = 10 * 101325
        p_wh = 15 * 101325
        t_fl = 303.15
        q_liq = 300 / 86400
        wct = 0

        c_choke = com.adapt_choke(choke, p_fl, p_wh, t_fl, q_liq, wct)
        self.assertEqual(c_choke, 2.6845620896319633)

    def test_choke_adaptation_dict(self):
        """Choke: адаптация с результатом = const"""
        choke = ch.Choke(0, 0.05, 0.062, self.fluid)
        p_fl = 10 * 101325
        p_wh = 100 * 101325
        t_fl = 303.15
        q_liq = 300 / 86400
        wct = 0

        c_choke = com.adapt_choke(choke, p_fl, p_wh, t_fl, q_liq, wct)
        self.assertIsInstance(c_choke, dict)
        self.assertAlmostEqual(c_choke["const"], 90*101325, delta=0.01)

    # def test_choke_adaptation_minimize_scalar(self):
    #     """Choke: адаптация с отработкой через minimize_scalar"""
    #     choke = ch.Choke(0, 0.01, 0.04, self.fluid)
    #     p_fl = 68 * 101325
    #     p_wh = 72 * 101325
    #     t_fl = 303.15
    #     q_liq = 254 / 86400
    #     wct = 0.77
    #
    #     c_choke = com.adapt_choke(choke, p_fl, p_wh, t_fl, q_liq, wct)
    #     self.assertAlmostEqual(c_choke, 4.999996385724912, delta=0.01)


class TestElSySAdapt(unittest.TestCase):
    def setUp(self) -> None:
        motor_data = {
            "ID": 1,
            "manufacturer": "Centrilift",
            "name": "562Centrilift-KMB-130-2200B",
            "d_motor_mm": 142.7,
            "motor_nom_i": 35,
            "motor_nom_power": 96.98,
            "motor_nom_voltage": 2200,
            "motor_nom_eff": 80,
            "motor_nom_cosf": 0.82,
            "motor_nom_freq": 60,
            "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
            "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
            "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
            "rpm_points": [
                3568.604,
                3551.63,
                3534.656,
                3517.682,
                3500.708,
                3483.734,
                3466.76,
                3449.786,
                3432.812,
                3415.838,
            ],
        }

        electric_data = {
            "motor_data": motor_data,
            "pump_nom_freq": 50,
            "gassep_nom_power": 400,
            "protector_nom_power": 300,
            "transform_eff": 0.98,
            "cs_eff": 0.95,
            "cable_specific_resistance": 2.16,
            "cable_length": 3000,
        }

        self.el_sys = esys.EspElectricSystem(**electric_data)
        self.pump_power = 60000
        self.fluid_power = 35000
        self.freq = 54
        self.nom_esp_freq = 50
        self.t_cable = 303.15

    def test_el_sys_adaptation_full(self):
        """ElectricSystem: адаптация с наличием всех замерных параметров"""

        electric_adaptation = {
            "cosf_fact": 0.83,
            "motor_i_fact": 35,
            "load_fact": 0.7,
            "transform_voltage_fact": 2800,
            "cs_power_fact": 100000,
        }

        # Расчет адаптационых коэффициентов
        coeff = com.adapt_elsys(
            esp_electric_system=self.el_sys,
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            **electric_adaptation)

        # Рассчитанные адаптационные коэффициенты
        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        # Проверяем полученные коэффициенты
        self.assertAlmostEqual(0.7973980719402528, c_pump_power, delta=0.001)
        self.assertAlmostEqual(1.0374999999999999, c_cosf, delta=0.001)
        self.assertAlmostEqual(1.4285714285714286, c_amperage, delta=0.001)
        self.assertAlmostEqual(0.9964692177258025, c_transform_power, delta=0.001)
        self.assertAlmostEqual(1.7389850524958546, c_motor_volt, delta=0.001)

        res = self.el_sys.calc_electric_esp_system(
                pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
                fluid_power=self.fluid_power,
                freq_shaft=self.freq,
                t_cable=self.t_cable,
                c_pump_power=c_pump_power,
                c_cosf=c_cosf,
                c_amperage=c_amperage,
                c_transform_power=c_transform_power,
                c_motor_volt=c_motor_volt,
            )

        # Проверяем качество адаптации
        self.assertAlmostEqual(electric_adaptation["motor_i_fact"], res["motor_i"], delta=0.1)
        self.assertAlmostEqual(electric_adaptation["load_fact"], res["load"], delta=0.01)
        self.assertAlmostEqual(electric_adaptation["cs_power_fact"], res["cs_power"], delta=1)
        self.assertAlmostEqual(electric_adaptation["transform_voltage_fact"], res["transform_voltage"], delta=0.5)

    def test_el_sys_adaptation_only_power_cs(self):
        """ElectricSystem: адаптация при наличии замера только активной мощности на СУ"""

        electric_adaptation = {
            "cs_power_fact": 100000,
        }

        # Расчет адаптационых коэффициентов
        coeff = com.adapt_elsys(
            esp_electric_system=self.el_sys,
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            **electric_adaptation,
        )

        # Рассчитанные адаптационные коэффициенты
        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        # Проверяем полученные коэффициенты
        self.assertAlmostEqual(0.8939424117299936, c_pump_power, delta=0.001)
        self.assertEqual(1, c_cosf)
        self.assertEqual(1, c_amperage)
        self.assertEqual(1, c_transform_power)
        self.assertEqual(1, c_motor_volt)

        res = self.el_sys.calc_electric_esp_system(
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        # Проверяем качество адаптации
        self.assertAlmostEqual(electric_adaptation["cs_power_fact"], res["cs_power"], delta=1)

    def test_el_sys_adaptation_motor_i_load(self):
        """ElectricSystem: адаптация при наличии замера загрузки и силы тока"""

        electric_adaptation = {
            "motor_i_fact": 28,
            "load_fact": 0.65,
        }

        self.freq = 48

        # Расчет адаптационых коэффициентов
        coeff = com.adapt_elsys(
            esp_electric_system=self.el_sys,
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            **electric_adaptation,
        )

        # Рассчитанные адаптационные коэффициенты
        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        # Проверяем полученные коэффициенты
        self.assertAlmostEqual(0.937901355131173, c_pump_power, delta=0.001)
        self.assertEqual(1, c_cosf)
        self.assertAlmostEqual(1.2307692307692308, c_amperage, delta=0.001)
        self.assertEqual(1, c_transform_power)
        self.assertEqual(1, c_motor_volt)

        res = self.el_sys.calc_electric_esp_system(
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        # Проверяем качество адаптации
        self.assertAlmostEqual(electric_adaptation["motor_i_fact"], res["motor_i"], delta=0.1)
        self.assertAlmostEqual(electric_adaptation["load_fact"], res["load"], delta=0.01)

    def test_el_sys_adaptation_pump_power_zero(self):
        """ElectricSystem: адаптация электрики при неработающем насосе"""

        electric_adaptation = {
            "cosf_fact": 0.83,
            "motor_i_fact": 35,
            "load_fact": 0.7,
            "transform_voltage_fact": 2800,
            "cs_power_fact": 100000,
        }

        self.pump_power = 0

        # Расчет адаптационых коэффициентов
        coeff = com.adapt_elsys(
            esp_electric_system=self.el_sys,
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            **electric_adaptation)

        # Рассчитанные адаптационные коэффициенты
        c_pump_power = coeff["c_pump_power"]
        c_cosf = coeff["c_cosf"]
        c_amperage = coeff["c_amperage"]
        c_transform_power = coeff["c_transform_power"]
        c_motor_volt = coeff["c_motor_volt"]

        # Проверяем полученные коэффициенты
        self.assertEqual(1, c_pump_power)
        self.assertEqual(1, c_cosf)
        self.assertEqual(1, c_amperage)
        self.assertEqual(1, c_transform_power)
        self.assertEqual(1, c_motor_volt)

        res = self.el_sys.calc_electric_esp_system(
            pump_power=self.pump_power * (self.freq / self.nom_esp_freq) ** 3,
            fluid_power=self.fluid_power,
            freq_shaft=self.freq,
            t_cable=self.t_cable,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        # Проверяем качество адаптации
        self.assertEqual(0, res["motor_i"])
        self.assertEqual(0, res["load"])
        self.assertEqual(0, res["cs_power"])
        self.assertEqual(0, res["transform_voltage"])



