import unittest

import pandas as pd

import unifloc.tools.units_converter as uc
from unifloc.well.gas_well import GasWell


class GasWellTest(unittest.TestCase):

    def test_calc_pwf_pfl(self):
        """
        GasWell: Тестирование расчета забойного давления
        """
        # Инициализация исходных данных
        df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1500]])
        # Возможный способ задания инклинометрии через dict
        # df = {"MD": [0, 1000],
        #       "TVD": [0, 1000]}

        # В словари с калибровками подается давление и температура калибровки.
        # Зачастую - это давление насыщения и пластовая температура
        fluid_data = {"q_fluid": uc.convert_rate(100, "m3/day", "m3/s"), "wct": 0,
                      "pvt_model_data": {"black_oil": {"gamma_gas": 0.78, "gamma_wat": 1, "gamma_oil": 0.8}},
                      "fluid_type": "gas"}
        # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.062]])
        # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
                     "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001}}
        well_trajectory_data = {"inclinometry": df}
        equipment_data = None
        ambient_temperature_data = {"MD": [0, 1800], "T": [303.15, 303.15]}

        # Инициализация объекта скважины
        well = GasWell(fluid_data, pipe_data, well_trajectory_data,
                       ambient_temperature_data, equipment_data)
        # Расчет забойного давления
        p_fl = 10 * 101325
        q_gas = 500000 / 86400
        p_wh = None
        d_ch = None
        friction_factor = None
        c_choke = None
        output_params = True
        step_length = 100
        # Расчет с сохранением доп. атрибутов распределений свойств
        p_wf = well.calc_pwf_pfl(p_fl, q_gas, d_ch, p_wh, friction_factor,
                                 c_choke, step_length, output_params)
        self.assertAlmostEqual(129.98764907887687, p_wf/101325, delta=0.01)
