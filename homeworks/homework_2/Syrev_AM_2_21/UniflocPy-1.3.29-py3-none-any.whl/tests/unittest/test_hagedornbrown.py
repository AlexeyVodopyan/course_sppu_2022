import unittest

from numpy import NAN, isnan

from unifloc.pipe._hagedornbrown import HagedornBrown


class TestHagedornBrown(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов
        """
        self.d = 0.126
        self.hagedornbrown = HagedornBrown(self.d)
        self.eps_m = 0.0001
        self.sigma_l_nm = 5.16443138806286e-02
        self.c_calibr_grav = 1
        self.c_calibr_fric = 1
        self.init_datasets = {
            1: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 20 / 86400,
                "qg_rc_m3day": 2000 / 86400,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
                "p": 1 * 101325,
            },
            2: {
                "theta_deg": 90,
                "eps_m": self.eps_m,
                "ql_rc_m3day": 0,
                "qg_rc_m3day": 0,
                "mul_rc_cp": 1,
                "mug_rc_cp": 0.01,
                "sigma_l_nm": self.sigma_l_nm,
                "rho_lrc_kgm3": 800,
                "rho_grc_kgm3": 20,
                "c_calibr_grav": self.c_calibr_grav,
                "c_calibr_fric": self.c_calibr_fric,
                "p": 100 * 101325,
            },
            "NaN": {
                "theta_deg": NAN,
                "eps_m": NAN,
                "ql_rc_m3day": NAN,
                "qg_rc_m3day": NAN,
                "mul_rc_cp": NAN,
                "mug_rc_cp": NAN,
                "sigma_l_nm": NAN,
                "rho_lrc_kgm3": NAN,
                "rho_grc_kgm3": NAN,
                "c_calibr_grav": NAN,
                "c_calibr_fric": NAN,
                "p": NAN,
            },
        }
        print(self.shortDescription())

    def test_hagedornbrown_1(self):
        """
        HagedornBrown: Расчет всех параметров для набора исходных данных № 1 c Qж = 20, Qг = 2000
        """
        self.hagedornbrown.calc_grad(**self.init_datasets[1])
        self.assertAlmostEqual(self.hagedornbrown.dp_dl, 506.29741350757274, places=5)
        self.assertAlmostEqual(self.hagedornbrown.vsl, 0.01856458686846043, places=5)
        self.assertAlmostEqual(self.hagedornbrown.vsg, 1.8564586868460429, places=5)
        self.assertAlmostEqual(self.hagedornbrown.ff, 0.01922181356518668, places=5)
        self.assertAlmostEqual(
            self.hagedornbrown.dp_dl_gr, 502.27200000000005, places=5
        )
        self.assertAlmostEqual(self.hagedornbrown.dp_dl_fr, 4.025413507572692, places=7)
        self.assertAlmostEqual(self.hagedornbrown.hl, 0.04, places=7)

    def test_hagedornbrown_2(self):
        """
        HagedornBrown: Расчет всех параметров для набора исходных данных № 2 c Qж = 0, Qг = 0
        """
        self.hagedornbrown.calc_grad(**self.init_datasets[2])
        self.assertAlmostEqual(self.hagedornbrown.dp_dl, 7848.0, places=5)
        self.assertAlmostEqual(self.hagedornbrown.vsl, 0, places=5)
        self.assertAlmostEqual(self.hagedornbrown.vsg, 0, places=5)
        self.assertAlmostEqual(self.hagedornbrown.ff, 0, places=5)
        self.assertAlmostEqual(self.hagedornbrown.dp_dl_gr, 7848.0, places=5)
        self.assertAlmostEqual(self.hagedornbrown.dp_dl_fr, 0, places=7)
        self.assertAlmostEqual(self.hagedornbrown.hl, 1, places=7)

    def test_hagedornbrown_nan(self):
        """
        HagedornBrown: Расчет всех параметров для NaN
        """
        self.hagedornbrown.calc_grad(**self.init_datasets["NaN"])
        self.assertTrue(isnan(self.hagedornbrown.dp_dl))
        self.assertTrue(isnan(self.hagedornbrown.vsl))
        self.assertTrue(isnan(self.hagedornbrown.vsg))
        self.assertTrue(isnan(self.hagedornbrown.ff))
        self.assertTrue(isnan(self.hagedornbrown.dp_dl_gr))
        self.assertTrue(isnan(self.hagedornbrown.dp_dl_fr))
        self.assertTrue(isnan(self.hagedornbrown.hl))


if __name__ == "__main__":
    unittest.main()
