import unittest
import numpy as np
from unifloc.pvt._oil_correlations import OilCorrelations
from unifloc.tools.exceptions import NotImplementedPvtCorrError
from unifloc.service._constants import OIL_CORRS


class TestOilCorrelations(unittest.TestCase):
    def setUp(self):
        """
        Инициализация класса для тестирования. Запускается до расчета тестов

        Returns
        -------

        """
        self.gamma_gas = 0.6
        self.gamma_oil = 0.8
        oil_correlations = OIL_CORRS.copy()
        self.oil_correlations = OilCorrelations(oil_correlations)
        print(f"Test: {self.shortDescription()}")

    def test_pb_standing_30_80(self):
        """
        OilCorrs: Давление насыщения по корреляции Standing для 30 С и 80 м3/м3
        """
        t = 303.15
        rsb = 80
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["pb"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_pb(t, rsb, self.gamma_oil, self.gamma_gas),
            9783552.574449905,
            places=5,
        )

    def test_pb_standing_30_0(self):
        """
        OilCorrs: Давление насыщения по корреляции Standing для 30 С и 0 м3/м3
        """
        t = 303.15
        rsb = 0
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["pb"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertEqual(
            self.oil_correlations.calc_pb(t, rsb, self.gamma_oil, self.gamma_gas),
            101325,
        )

    def test_pb_not_implemented_error(self):
        """
        OilCorrs: Давление насыщения для нереализованной корреляции LaLaLand
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["pb"] = correlation
        with self.assertRaises(NotImplementedError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_pb_standing_nan(self):
        """
        OilCorrs: Давление насыщения по корреляции Standing для NaN
        """
        t = np.NAN
        rsb = np.NAN
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["pb"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_pb(t, rsb, self.gamma_oil, self.gamma_gas)
            )
        )

    def test_pb_standing_max(self):
        """
        OilCorrs: Давление насыщения по корреляции Standing на максимальное значение
        """
        t = 303.15
        rsb = 99999
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["pb"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertEqual(
            min(
                self.oil_correlations.calc_pb(t, rsb, self.gamma_oil, self.gamma_gas),
                137895145.863367,
            ),
            137895145.863367,
        )

    def test_rs_standing_5_30(self):
        """
        OilCorrs: Газосодержание по корреляции Standing для 30 С и 5 МПа
        """
        p = 5 * 10 ** 6
        t = 303.15
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["rs"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_rs(p, t, self.gamma_oil, self.gamma_gas),
            35.63306212748365,
            places=5,
        )

    def test_rs_not_implemented_error(self):
        """
        OilCorrs: Газосодержание для нереализованной корреляции LaLaLand
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["rs"] = correlation
        with self.assertRaises(NotImplementedError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_rs_standing_nan(self):
        """
        OilCorrs: Газосодержание по корреляции Standing для NaN
        """
        p = np.NAN
        t = np.NAN
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["rs"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_rs(p, t, self.gamma_oil, self.gamma_gas)
            )
        )

    def test_oil_compr_vasquez_5_30(self):
        """
        OilCorrs: Сжимаемость по корреляции Vasquez для 30 C и 5 МПа
        """
        t = 303.15
        rsb = 80
        p = 5
        oil_correlations = OIL_CORRS.copy()
        correlation = "vasquez"
        oil_correlations["compr"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_compressibility(
                t, self.gamma_oil, self.gamma_gas, rsb, p
            ),
            2.9797708060682887e-05,
            places=5,
        )

    def test_oil_compr_vasquez_nan(self):
        """
        OilCorrs: Сжимаемость по корреляции Vasquez для NaN
        """
        t = np.NAN
        rsb = np.NAN
        p = np.NAN
        oil_correlations = OIL_CORRS.copy()
        correlation = "vasquez"
        oil_correlations["compr"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_oil_compressibility(
                    t, self.gamma_oil, self.gamma_gas, rsb, p
                )
            )
        )

    def test_oil_compr_not_implemented_error(self):
        """
        OilCorrs: Сжимаемость для нереализованной корреляции LaLaLand
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["compr"] = correlation
        with self.assertRaises(NotImplementedError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_oil_compr_min(self):
        """
        OilCorrs: Сжимаемость по корреляции Vasquez на минимальное значение
        """
        t = 303.15
        rsb = 0.01
        p = 5 * 10 ** 6
        oil_correlations = OIL_CORRS.copy()
        correlation = "vasquez"
        oil_correlations["compr"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertEqual(
            self.oil_correlations.calc_oil_compressibility(
                t, self.gamma_oil, self.gamma_gas, rsb, p
            ),
            2 * 10 ** -12,
        )

    def test_bo_standing_5_30_lower(self):
        """
        OilCorrs: Объемный коэффициент нефти по корреляции Standing для 30 C и 5 МПа ниже Pнас=10 МПа
        """
        p = 5 * 10 ** 6
        t = 303.15
        rs = 50
        compr = 1e-5
        pb = 10 * 10 ** 6
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["b"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_fvf(
                p, t, rs, self.gamma_oil, self.gamma_gas, compr, pb
            ),
            1.1157137718525298,
            places=5,
        )

    def test_bo_not_implemented_error(self):
        """
        OilCorrs: Объемный коэффициент нефти для нереализованной корреляции LaLaLand ниже давления насыщения
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["b"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_bo_standing_15_30_upper(self):
        """
        OilCorrs: Объемный коэффициент нефти по корреляции Standing для 30 C и 15 МПа выше Pнас=10 МПа
        """
        p = 15 * 10 ** 6
        t = 303.15
        bob = 1.1
        rs = 50
        compr = 1e-11
        pb = 10 * 10 ** 6
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["b"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_fvf(
                p, t, rs, self.gamma_oil, self.gamma_gas, compr, pb, bob
            ),
            1.0920517790574082,
            places=5,
        )

    def test_bo_standing_nan(self):
        """
        OilCorrs: Объемный коэффициент нефти по корреляции Standing для nan
        """
        p = np.NAN
        t = np.NAN
        rs = np.NAN
        compr = np.NAN
        pb = np.NAN
        oil_correlations = OIL_CORRS.copy()
        correlation = "standing"
        oil_correlations["b"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_oil_fvf(
                    p, t, rs, self.gamma_oil, self.gamma_gas, compr, pb
                )
            )
        )

    def test_rho_oil_standing_5_30(self):
        """
        OilCorrs: Плотность нефти для 30 С и 5 МПа
        """
        rs = 50
        bo = 1.1
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_density(
                rs, bo, self.gamma_oil, self.gamma_gas
            ),
            760.5918181818182,
            places=5,
        )

    def test_rho_oil_standing_nan(self):
        """
        OilCorrs: Плотность нефти по корреляции Standing для NaN
        """
        rs = np.NAN
        bo = np.NAN
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_oil_density(
                    rs, bo, self.gamma_oil, self.gamma_gas
                )
            )
        )

    def test_muo_beggs_5_30_lower(self):
        """
        OilCorrs: Вязкость нефти по корреляции Beggs для 30 C и 5 МПа ниже Pнас=10 МПа
        """
        p = 5 * 10 ** 6
        t = 303.15
        pb = 10 * 10 ** 6
        rs = 50
        calibr_muo = 1
        oil_correlations = OIL_CORRS.copy()
        correlation = "beggs"
        oil_correlations["mud"] = correlation
        oil_correlations["mus"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_viscosity(
                p, t, pb, self.gamma_oil, rs, calibr_muo
            ),
            1.417059549469286,
            places=5,
        )

    def test_muo_beggs_15_30_upper(self):
        """
        OilCorrs: Вязкость нефти по корреляции Beggs для 30 C и 15 МПа выше Pнас=10 МПа
        """
        p = 15 * 10 ** 6
        t = 303.15
        pb = 10 * 10 ** 6
        rs = 50
        calibr_muo = 1
        oil_correlations = OIL_CORRS.copy()
        correlation = "beggs"
        oil_correlations["mud"] = correlation
        oil_correlations["mus"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_viscosity(
                p, t, pb, self.gamma_oil, rs, calibr_muo
            ),
            1.534221877253656,
            places=5,
        )

    def test_muo_beggs_5_30_dead(self):
        """
        OilCorrs: Вязкость дегазированной нефти по корреляции Beggs для 30 C и 5 МПа
        """
        p = 5 * 10 ** 6
        t = 303.15
        pb = 10 * 10 ** 6
        rs = 0
        calibr_muo = 1
        oil_correlations = OIL_CORRS.copy()
        correlation = "beggs"
        oil_correlations["mud"] = correlation
        oil_correlations["mus"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertAlmostEqual(
            self.oil_correlations.calc_oil_viscosity(
                p, t, pb, self.gamma_oil, rs, calibr_muo
            ),
            4.397849634729217,
            places=5,
        )

    def test_muo_beggs_nan(self):
        """
        OilCorrs: Вязкость нефти по корреляции Beggs для NaN
        """
        p = np.NAN
        t = np.NAN
        pb = np.NAN
        rs = np.NAN
        calibr_muo = np.NAN
        oil_correlations = OIL_CORRS.copy()
        correlation = "beggs"
        oil_correlations["mud"] = correlation
        oil_correlations["mus"] = correlation
        self.oil_correlations = OilCorrelations(oil_correlations)
        self.assertTrue(
            np.isnan(
                self.oil_correlations.calc_oil_viscosity(
                    p, t, pb, self.gamma_oil, rs, calibr_muo
                )
            )
        )

    def test_muos_not_implemented_error(self):
        """
        OilCorrs: Вязкость насыщенной нефти для нереализованной корреляции LaLaLand
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["mud"] = "beggs"
        oil_correlations["mus"] = correlation
        with self.assertRaises(NotImplementedPvtCorrError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_muod_not_implemented_error(self):
        """
        OilCorrs: Вязкость дегазированной нефти для нереализованной корреляции LaLaLand
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["mud"] = correlation
        oil_correlations["mus"] = "beggs"
        with self.assertRaises(NotImplementedPvtCorrError):
            self.oil_correlations = OilCorrelations(oil_correlations)

    def test_exception_detail(self):
        """
        OilCorrs: Вязкость нефти тестирование сохранения нереализованной корреляции в контекст ошибки
        """
        oil_correlations = OIL_CORRS.copy()
        correlation = "LaLaLand"
        oil_correlations["mud"] = correlation
        try:
            self.oil_correlations = OilCorrelations(oil_correlations)
        except NotImplementedPvtCorrError as e:
            print(e.detail)
            self.assertEqual(e.detail, correlation)


if __name__ == "__main__":
    unittest.main()
