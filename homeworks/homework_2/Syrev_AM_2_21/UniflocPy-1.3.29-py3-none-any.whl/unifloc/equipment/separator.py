"""
Модуль, описывающий класс по работе с сепаратором
"""
import json
import os
from typing import Optional

import unifloc.equipment.equipment as eq


class Separator(eq.Equipment):
    """
    Класс для расчета общего коэффициента сепарации газа на насосе
    c учетом газосепаратора и естественной сепарации
    """

    __slots__ = ["k_gas_sep", "k_gassep_general", "num_sep", "seps_db"]

    def __init__(
        self, h_mes: float, k_gas_sep: float = 0, sep_name: Optional[str] = None,
    ):
        """

        Parameters
        ----------
        :param h_mes: глубина установки газосепаратора, м - float
        :param k_gas_sep: коэффициент сепарации насоса (газосепаратора), д.ед - float, optional
        :param sep_name: название сепаратора в соответствии с БД, строка

        Examples:
        --------
        >>> from unifloc.equipment.natural_separation import NaturalSeparation
        >>> from unifloc.equipment.separator import Separator
        >>> # Расчет естественной сепарации
        >>> # Инициализация исходных данных для расчета естественной сепарации
        >>> h_mes_ = 1800
        >>> d_tub = 0.063
        >>> d_cas = 0.130
        >>> q_fluid = 100 / 86400
        >>> q_gas = 0
        >>> sigma_l = 24
        >>> rho_liq = 836
        >>> rho_gas = 0.84
        >>> # Инициализация класса расчета естественной сепарации
        >>> k_sep_nat_calc = NaturalSeparation(h_mes_)
        >>> # Расчет коэффициента естественной сепарации
        >>> k_sep_natural = k_sep_nat_calc.calc_separation(d_tub, d_cas, q_fluid, q_gas,
        ...                                                sigma_l, rho_liq, rho_gas)
        >>> # Инициализация исходных данных для расчета общей сепарации
        >>> k_gas_sep = 0.7
        >>> # Инициализация класса расчета общей сепарации
        >>> k_gassep_calc = Separator(h_mes_, k_gas_sep)
        >>> # Расчет коэффициента общей сепарации
        >>> k_sep_total = k_gassep_calc.calc_general_separation(k_sep_natural)
        """

        super().__init__(h_mes)

        self.num_sep = None if sep_name is None else self._get_separator(sep_name)
        self.k_gas_sep = k_gas_sep
        self.k_gassep_general = 0

    @property
    def __seps_db(self) -> list:
        """
        Метод подгрузки БД сепараторов

        Parameters
        ----------
        :return: БД сепараторов
        -------
        """
        with open(
            os.path.join(os.path.dirname(__file__), "seps.json"), encoding="utf-8"
        ) as jsonFile:
            seps_db = json.load(jsonFile)
            jsonFile.close()
        return seps_db

    def calc_general_separation(
        self,
        k_gas_sep_nat: float,
        gf: Optional[float] = None,
        q_liq: Optional[float] = None,
        freq: Optional[float] = None,
    ) -> float:
        """
        Функция расчета общего коэффициента сепарации с учетом
        газосепаратора и естественной сепарации

        Parameters
        ----------
        :param k_gas_sep_nat: коэффициент естественной сепарации, д.ед
        :param gf: доля газа на приеме ГС, д.ед.
        :param q_liq: дебит жидкости, м3/с
        :param freq: частота вращения вала ЭЦН, Гц

        :return k_gassep_general: коэффициент общей сепарации, д.ед
        -------
        """
        # Коэффициент газосепарации газосепаратора
        if self.num_sep is not None:
            self.k_gas_sep = self.calc_k_gas_sep(
                self.num_sep, gf=gf, q_liq=q_liq, freq=freq
            )

        # Общий коэффициент газосепарации
        self.k_gassep_general = k_gas_sep_nat + (1 - k_gas_sep_nat) * self.k_gas_sep

        return self.k_gassep_general

    def _get_separator(self, sep_name: str) -> str:
        """
        Метод определения соответствия сепаратора БД

        Parameters
        ----------
        :param sep_name: название сепаратора(диспергатора), в соответсвии с БД

        :return num_sep: номер газосепаратора в соответсвие с БД
        -------
        """
        # подгружаем БД сепараторов
        self.seps_db = self.__seps_db

        for key, value in self.seps_db[0].items():
            for i in value:
                if i == sep_name:
                    num_sep = key
                    return num_sep
                else:
                    num_sep = str(29)
        return num_sep

    def _sepfactor_approx(
        self, num_sep: str, gf: float, qu: float, f: float, dif_flag: int = 0
    ) -> float:
        """
        Метод вычисления коэффициента сепарации по аппроксимированной зависимости

        Parameters
        ----------
        :param num_sep:  номер газосепаратора в соответсвие с БД
        :param gf: доля газа на входе в газосепаратор, %
        :param qu: дебит жидкости, м3/сутки
        :param f: число оборотов вала ГС(ЭЦН) в минуту
        :param dif_flag: флаг отвечающий за тип возвращаемой функции (default = "0")
            0   - сама функция
            1   - частная производная функции по газосодержание
            2   - частная производная функции по дебиту

        :return my_sepfactor_approx: коэффициента сепарации по аппроксимированной зависимости, дол.ед
        -------
        """
        theta_array = self.seps_db[1][num_sep]
        if dif_flag == 0:
            my_sepfactor_approx = (
                theta_array[0] * gf ** 4
                + theta_array[1] * gf ** 3
                + theta_array[2] * gf ** 2 * qu
                + theta_array[3] * gf ** 2
                + theta_array[4] * gf * qu
                + theta_array[5] * gf * f
                + theta_array[6] * qu ** 2
                + theta_array[7] * qu * f
                + theta_array[8] * gf
                + theta_array[9] * qu
                + theta_array[10] * f
                + theta_array[11]
            )
        # Вычисление производной функции по газосодержанию
        elif dif_flag == 1:
            my_sepfactor_approx = (
                4 * theta_array[0] * gf ** 3
                + 3 * theta_array[1] * gf ** 2
                + 2 * theta_array[2] * gf * qu
                + 2 * theta_array[3] * gf
                + theta_array[4] * qu
                + theta_array[5] * f
                + theta_array[8]
            )
        # Вычисление производной функции по дебиту
        elif dif_flag == 2:
            my_sepfactor_approx = (
                theta_array[2] * gf ** 2
                + theta_array[4] * gf
                + 2 * theta_array[6] * qu
                + theta_array[7] * f
                + theta_array[9]
            )
        return my_sepfactor_approx

    @staticmethod
    def _inarea_f(
        my_gfmin: float,
        my_gfmax: float,
        my_qmin: float,
        my_qmax: float,
        gf: float,
        qu: float,
        param_flag: float,
    ) -> bool:
        """
        Определяет принадлежность точки к измеренной области

        Parameters
        ----------
        :param my_gfmin: Минимальное замеренные газосодержания сепаратора, %
        :param my_gfmax: Максимальные замеренные газосодержания сепаратора, %
        :param my_qmin: Минимальные замеренные дебиты сепаратора, м3/сутки
        :param my_qmax: Максимальные замеренные дебиты сепаратора, м3/сутки
        :param gf: доля газа на входе в газосепаратор, %
        :param qu: дебит жидкости, м3/сутки
        :param param_flag:  флаг отвечающий за тип проверки
                        "GQ"   - проверка по газу, дебиту
                        "Q"   - проверка по дебиту
                        "G"   - проверка по газу

        :return my_inarea: возвращает True если принадледит области, False если не принадлежит
        -------
        """
        my_inarea = True
        if param_flag == "GQ":
            if not my_gfmin <= gf <= my_gfmax or not my_qmin <= qu <= my_qmax:
                my_inarea = False
        elif param_flag == "Q":
            if not my_qmin <= qu <= my_qmax:
                my_inarea = False
        elif param_flag == "G":
            if not my_gfmin <= gf <= my_gfmax:
                my_inarea = False
        return my_inarea

    def calc_k_gas_sep(
        self,
        num_sep: str,
        gf: float,
        q_liq: float,
        freq: float = 50,
        k_gas_sep: float = 0.7,
    ) -> float:
        """
        Вычисление коэффициента сепрации газосепаратора в точке

        Parameters
        ----------
        :param num_sep:  номер газосепаратора в соответсвие с БД
        :param gf: доля газа, д.ед.
        :param q_liq: дебит жидкости, м3/с
        :param freq: частота вращения вала ЭЦН, Гц
        :param k_gas_sep:  коэффициент сепарации газосепаратора(паспортный), д.ед

        :return my_sepfactor: коэффициент сепарации газосепаратора(расчетный), д.ед
        -------
        """
        # приводим данные в размерности для расчета
        gf = gf * 100
        qu = q_liq * 86400
        f = freq * 60

        sep_par = self.seps_db[2][num_sep]

        my_gfmin = sep_par[0]
        my_gfmax = sep_par[1]
        my_qmin = sep_par[2]
        my_qmax = sep_par[3]

        mult = 1.3

        in_area_gq = self._inarea_f(my_gfmin, my_gfmax, my_qmin, my_qmax, gf, qu, "GQ")
        in_area_g = self._inarea_f(my_gfmin, my_gfmax, my_qmin, my_qmax, gf, qu, "G")
        in_area_q = self._inarea_f(my_gfmin, my_gfmax, my_qmin, my_qmax, gf, qu, "Q")

        if in_area_gq:
            my_sepfactor = self._sepfactor_approx(num_sep, gf, qu, f)
        # Если точка лежит вне замеренной области, используем сшивки
        # (1) Сшивка с параболическим цилиндром только по дебиту в области нуля
        elif qu < my_qmax and in_area_g:
            mx = my_qmax
            func = self._sepfactor_approx(num_sep, gf, mx, f)
            dfunc = self._sepfactor_approx(num_sep, gf, mx, f, 2)
            ka = dfunc / mx
            kb = -1 * dfunc
            kc = func
            my_sepfactor = ka * qu ** 2 + kb * qu + kc
        # (2) Сшивка с параболическим цилиндром только по дебиту в области максимума
        elif qu > my_qmax and in_area_g:
            mx = my_qmax
            # mQ2
            mX2 = mult * mx
            if qu > mX2:
                my_sepfactor = 0
            else:
                func = self._sepfactor_approx(num_sep, gf, mx, f)
                dfunc = self._sepfactor_approx(num_sep, gf, mx, f, 2)
                r = mx - mX2
                ka = (dfunc * r - func) / r / r
                kb = dfunc - 2 * ka * mx
                kc = -ka * mX2 ** 2 - kb * mX2
                my_sepfactor = ka * qu ** 2 + kb * qu + kc
        # (3) Сшивка с параболическим цилиндром только по газу в области нуля
        elif gf < my_gfmin and in_area_q:
            mx = my_gfmin
            func = self._sepfactor_approx(num_sep, mx, qu, f)
            dfunc = self._sepfactor_approx(num_sep, mx, qu, f, 1)
            ka = (mx * dfunc - func) / mx / mx
            kb = dfunc - 2 * mx * ka
            my_sepfactor = ka * gf ** 2 + kb * gf
        # (4) Сшивка с параболическим цилиндром только по газу в области максимума
        elif gf > my_gfmax and in_area_q:
            mx = my_gfmax
            # mG2
            mX2 = 100
            if gf > mX2:
                my_sepfactor = 0
            else:
                func = self._sepfactor_approx(num_sep, mx, qu, f)
                dfunc = self._sepfactor_approx(num_sep, mx, qu, f, 1)
                r = mx - mX2
                ka = (dfunc * r - func) / r / r
                kb = dfunc - 2 * ka * mx
                kc = -ka * mX2 ** 2 - kb * mX2
                my_sepfactor = ka * gf ** 2 + kb * gf + kc
        # (5) Сшивка с параболоидом вращения по газу в области нуля и по дебиту в области нуля
        elif gf < my_gfmin and qu < my_qmax:
            mx = my_qmax
            mD = my_gfmin
            func = self._sepfactor_approx(num_sep, mD, mx, f)
            dfunc = self._sepfactor_approx(num_sep, mD, mx, f, 2)
            ka = dfunc / mx
            kb = -dfunc
            kc = func
            func = ka * qu ** 2 + kb * qu + kc
            mx = my_gfmin
            mD = my_qmax
            dfunc = self._sepfactor_approx(num_sep, mx, mD, f, 1)
            ka = (mx * dfunc - func) / mx / mx
            kb = dfunc - 2 * mx * ka
            my_sepfactor = ka * gf ** 2 + kb * gf
        # (6) Сшивка с параболоидом вращения по газу в области нуля и по дебиту в области максимума
        elif gf < my_gfmin and qu > my_qmax:
            mx = my_qmax
            # mQ2
            mX2 = mult * mx
            if qu > mX2:
                my_sepfactor = 0
            else:
                mD = my_gfmin
                func = self._sepfactor_approx(num_sep, mD, mx, f)
                dfunc = self._sepfactor_approx(num_sep, mD, mx, f, 2)
                r = mx - mX2
                ka = (dfunc * r - func) / r / r
                kb = dfunc - 2 * ka * mx
                kc = -ka * mX2 ** 2 - kb * mX2
                func = ka * qu ** 2 + kb * qu + kc
                mx = my_gfmin
                mD = my_qmax
                dfunc = self._sepfactor_approx(num_sep, mx, mD, f, 1)
                ka = (mx * dfunc - func) / mx / mx
                kb = dfunc - 2 * mx * ka
                my_sepfactor = ka * gf ** 2 + kb * gf
        # (7) Сшивка с параболоидом вращения по газу в области максимума и по дебиту в области нуля
        elif gf > my_gfmax and qu < my_qmax:
            mx = my_qmax
            mD = my_gfmax
            func = self._sepfactor_approx(num_sep, mD, mx, f)
            dfunc = self._sepfactor_approx(num_sep, mD, mx, f, 2)
            ka = dfunc / mx
            kb = -dfunc
            kc = func
            func = ka * qu ** 2 + kb * qu + kc
            mx = my_gfmax
            mD = my_qmax
            # mG2
            mX2 = 100
            if gf > mX2:
                my_sepfactor = 0
            else:
                dfunc = self._sepfactor_approx(num_sep, mx, mD, f, 1)
                r = mx - mX2
                ka = (dfunc * r - func) / r / r
                kb = dfunc - 2 * ka * mx
                kc = -ka * mX2 ** 2 - kb * mX2
                my_sepfactor = ka * gf ** 2 + kb * gf + kc
        # (8) Сшивка с параболоидом вращения по газу в области максимума и по дебиту в области максимума
        elif gf > my_gfmax and qu > my_qmax:
            mx = my_qmax
            # mQ2
            mX2 = mult * mx
            if qu > mX2:
                my_sepfactor = 0
            else:
                mD = my_gfmax
                func = self._sepfactor_approx(num_sep, mD, mx, f)
                dfunc = self._sepfactor_approx(num_sep, mD, mx, f, 2)
                r = mx - mX2
                ka = (dfunc * r - func) / r / r
                kb = dfunc - 2 * ka * mx
                kc = -ka * mX2 ** 2 - kb * mX2
                func = ka * qu ** 2 + kb * qu + kc
                mx = my_gfmax
                mD = my_qmax
                # mG2
                mX2 = 100
                if gf > mX2:
                    my_sepfactor = 0
                else:
                    dfunc = self._sepfactor_approx(num_sep, mx, mD, f, 1)
                    r = mx - mX2
                    ka = (dfunc * r - func) / r / r
                    kb = dfunc - 2 * ka * mx
                    kc = -ka * mX2 ** 2 - kb * mX2
                    my_sepfactor = ka * gf ** 2 + kb * gf + kc
        else:
            my_sepfactor = k_gas_sep * 100

        # Обрезка по значению
        if my_sepfactor < 0:
            my_sepfactor = 0
        elif my_sepfactor > 100:
            my_sepfactor = 100

        return my_sepfactor / 100
