import copy
from copy import deepcopy
from typing import Optional, Union

import scipy.optimize as opt

import unifloc.equipment.esp_system as esp_sys
import unifloc.pipe.annulus as ann
import unifloc.service._constants as const
import unifloc.service._tools as tls
import unifloc.tools.common_calculations as com
import unifloc.tools.exceptions as exc
import unifloc.well._well as abw


class EspWell(abw.AbstractWell):
    """
    Класс для расчета скважины с ЭЦН

    Принимает на вход словари с исходными данными.

    Структура словарей исходных данных:

    * fluid_data ("ключ" - определение - тип) - dict
        * "q_fluid" - дебит жидкости в ст.у., ст. м/c - float
        * "wct" - объемная обводненность, доли ед. - float
        * "pvt_model_data" - словарь с флюидами - dict
            * "black_oil" - словарь с свойствами нефти, газа и воды для модели Black Oil - dict
                * "gamma_gas" - относительная плотность газа по воздуху в ст.у.
                (плотность воздуха = 1.2217 кг/м3)-float
                * "gamma_oil" - относительная плотность нефти по воде в ст.у.
                (плотность воды = 1000 кг/м3) - float
                * "gamma_wat" - относительная плотность воды по воде в ст.у.
                (плотность воды = 1000 кг/м3) - float
                * "rp" - газовый фактор, ст. м3 газа/ст. м3 нефти - float
                * "oil_correlations" - словарь с набором корреляций для нефти - dict, optional
                    * "pb" - название корреляции для давления насыщения - string, optional
                        * Возможные значения: "Standing"
                    * "rs" - название корреляции для газосодержания - string, optional
                        * Возможные значения: "Standing"
                    * "rho" - название корреляции для плотности нефти - string, optional
                        * Возможные значения: "Standing"
                    * "mu" - название корреляции для вязкости нефти - string, optional
                        * Возможные значения: "Beggs"
                    * "b" - название корреляции для объемного коэффициента нефти - string, optional
                        * Возможные значения: "Standing"
                    * "compr" - название корреляции для сжимаемости нефти - string, optional
                        * Возможные значения: "Vasquez"
                * "gas_correlations" - словарь с набором корреляций для газа - dict, optional
                    * "ppc" - название корреляции для критического давления - string, optional
                        * Возможные значения: "Standing"
                    * "tpc" - название корреляции для критической температуры - string, optional
                        * Возможные значения: "Standing"
                    * "z" - название корреляции для z-фактора - string, optional
                        * Возможные значения: "Kareem", "Dranchuk"
                    * "mu" - название корреляции для вязкости газа - string, optional
                        * Возможные значения: "Lee"
                * "water_correlations" - словарь с набором корреляций для газа - dict, optional
                    * "b" - название корреляции для объемного коэффициента воды - string, optional
                        * Возможные значения: "McCain"
                    * "rho" - название корреляции для плотности воды - string, optional
                        * Возможные значения: "Standing", "IAPWS"
                    * "mu" - название корреляции для вязкости воды - string, optional
                        * Возможные значения: "McCain", "IAPWS"
                    * "compr" - название корреляции для сжимаемости воды - string, optional
                        * Возможные значения: "Kriel"
                * "salinity" - минерализация воды, ppm - float, optional
                * "rsb" - словарь с калибровочным значением газосодержания при давлении насыщения -
                dict, optional
                    * "value" - калибровочное значение газосодержания при давлении насыщения,
                    ст. м3 газа/ст. м3 нефти - float
                    * "p" - давление калибровки, Па абс. - float
                    * "t" - температура калибровки газосодержания, К - float
                * "bob" - словарь с калибровочным значением объемного коэффициента нефти при
                давлении насыщения - dict, optional
                    * "value" - калибровочное значение объемного коэффициента нефти при давлении
                    насыщения, ст. м3/ст. м3 - float
                    * "p" - давление калибровки, Па изб. - float
                    * "t" - температура калибровки объемного коэффициента нефти, К - float
                * "muob" - словарь с калибровочным значением вязкости нефти при давлении насыщения
                - dict, optional
                    * "value" - калибровочное значение вязкости нефти при давлении насыщения, сПз - float
                    * "p" - давление калибровки, Па изб. - float
                    * "t" - температура калибровки вязкости нефти, К - float
                * "table_model_data" - словарь с исходными данными табличной модели - dict, optional
                    * "pvt_dataframes_dict" - словарь с таблицами с исходными данными -
                     dict of DataFrames
                    * "interp_type" -  тип интерполяции (по умолчанию - линейный) - string, optional
                * "use_table_model" - флаг использования табличной модели - boolean, optional
    * pipe_data ("ключ" - определение - тип) - dict
        * "casing" - словарь с исходными данными для создания ЭК - dict
            * "bottom_depth" - измеренная глубина верхних дыр перфорации, м - float
            * "d" - внутренний диаметр ЭК, м - float, pd.DataFrame("MD", "d")
            * ! можно задавать как числом, так и таблицей с распределением по глубине или словарем,
             см. пример
            * "roughness" - шероховатость, м - float
        * "tubing" - словарь с исходными данными для создания колонны НКТ - dict
            * "bottom_depth" - измеренная глубина спуска колонны НКТ, м - float
            * "d" - внутренний диаметр колонны НКТ, м - float, pd.DataFrame("MD", "d")
            * ! можно задавать как числом, так и таблицей с распределением по глубине или словарем,
             см. пример
            * "roughness" - шероховатость, м - float
            * "s_wall" - толщина стенки, м - float
    * well_trajectory_data ("ключ" - определение - тип) - dict
        * "inclinometry" - таблица с инклинометрией, две колонки: "MD","TVD", индекс по умолчанию,
         см.пример - DataFrame
        * или возможно с помощью dict с ключами "MD", "TVD"
        * Важно!: физичность вводимых данных пока не проверяется, поэтому нужно смотреть чтобы
         TVD <= MD, dTVD <= dMD
    * ambient_temperature_data ("ключ" - определение - тип) - словарь с распределением температуры
     породы по MD - dict
        * обязательные ключи MD, T - list
    * equipment_data ("ключ" - определение - тип) - dict
        * "choke" - словарь с исходными данными для создания объекта штуцера - dict, optional
            * "d" - диаметр штуцера, м - float
        * "packer" - флаг наличия пакера, True/False, optional
        * "esp_system" - словарь с исходными данными для создания объекта системы УЭЦН - dict
            * "esp" - словарь с данными для объекта ЭЦН
                * "h_mes" - глубина на которой установлен насос, м - float
                * "stages" - количество ступеней насоса - integer
                * "esp_data" - паспортные данные ЭЦН из базы насосов - pd.Series или dict,
                 см.ниже пример
                * "viscosity_correction" - флаг учета поправки на вязкость - boolean
                * "gas_correction" - флаг учета поправки на газ - boolean
            * "esp_electric_system" - словарь с исходными данными для электрической части
             УЭЦН - dict, optional
                * "motor_data" - паспортные данные ПЭД - dict
                * "gassep_nom_power" - номинальная мощность газосепаратора, Вт - float, optional
                * "protector_nom_power" - номинальная мощность протектора, Вт - float, optional
                * "transform_eff" - КПД трансформатора, д.ед. - float, optional
                * "cs_eff" - КПД станции управления, д.ед. - float, optional
                * "cable_specific_resistance" - удельное сопротивление  электрического кабеля, Ом/1000 м  - float,
                 optional
                * "cable_length" - длина электрического кабеля, м - float, optional
            * "separator" - словарь с исходными данными для объекта газосепаратор - dict, optional
                * "k_gas_sep" - коэффициент газосепарации сепаратора, доли ед. - float
                * "sep_name" - наименование сепаратора в соответсвие с БД - str
    """

    def __init__(
        self,
        fluid_data: dict,
        pipe_data: dict,
        equipment_data: dict,
        well_trajectory_data: dict,
        ambient_temperature_data: dict,
    ):
        """
        Parameters
        ----------
        :param fluid_data: словарь с исходными данными для создания флюида
        :param pipe_data: словарь с исходными данными для создания колонн труб
        :param equipment_data: словарь с исходными данными для создания различного оборудования
        :param well_trajectory_data: словарь с исходными данными для создания инклинометрии скважины
        :param ambient_temperature_data: словарь с распределением температуры породы по MD

        Examples:
        --------
        >>> # Пример исходных данных для насоса
        >>> import pandas as pd
        >>> import unifloc.tools.units_converter as uc
        >>> from unifloc.well.esp_well import EspWell

        >>> # Если мы хотим задать насос вручную, то нам соответственно нужно заполнить все строки
        >>> # Например, при помощи словаря:
        >>> esp_data = {"ID": 99999,
        ...         "source": "legacy",
        ...         "manufacturer": "Reda",
        ...         "name": "DN500",
        ...         "stages_max": 400,
        ...         "rate_nom_sm3day": 30,
        ...         "rate_opt_min_sm3day":20,
        ...         "rate_opt_max_sm3day":40,
        ...         "rate_max_sm3day": 66,
        ...         "slip_nom_rpm": 3000,
        ...         "freq_Hz": 50,
        ...         "eff_max": 0.4,
        ...         "height_stage_m": 0.035,
        ...         "Series": 4,
        ...         "d_od_mm": 86,
        ...         "d_cas_min_mm": 112,
        ...         "d_shaft_mm": 17,
        ...         "area_shaft_mm2": 227,
        ...         "power_limit_shaft_kW": 72,
        ...         "power_limit_shaft_high_kW": 120,
        ...         "power_limit_shaft_max_kW": 150,
        ...         "pressure_limit_housing_atma": 390,
        ...         "d_motor_od_mm": 95,
        ...         "rate_points": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 66],
        ...         "head_points": [4.88, 4.73, 4.66, 4.61, 4.52, 4.35, 4.1, 3.74, 3.28, 2.73, 2.11, 1.45, 0.77, 0],
        ...         "power_points": [0.02, 0.022, 0.025, 0.027, 0.03, 0.032, 0.035, 0.038, 0.041, 0.043, 0.046, 0.049,
        ...                            0.052000000000000005, 0.055],
        ...         "eff_points": [0, 0.12, 0.21, 0.29, 0.35, 0.38, 0.4, 0.39, 0.37, 0.32, 0.26, 0.19, 0.1, 0]
        ...         }
        >>> # Можно задавать с помощью dict - esp_data = data
        >>> esp_data = pd.Series(esp_data,name=esp_data["ID"])
        >>> print(esp_data)
        ID                                                                         99999
        source                                                                    legacy
        manufacturer                                                                Reda
        name                                                                       DN500
        stages_max                                                                   400
        rate_nom_sm3day                                                               30
        rate_opt_min_sm3day                                                           20
        rate_opt_max_sm3day                                                           40
        rate_max_sm3day                                                               66
        slip_nom_rpm                                                                3000
        freq_Hz                                                                       50
        eff_max                                                                      0.4
        height_stage_m                                                             0.035
        Series                                                                         4
        d_od_mm                                                                       86
        d_cas_min_mm                                                                 112
        d_shaft_mm                                                                    17
        area_shaft_mm2                                                               227
        power_limit_shaft_kW                                                          72
        power_limit_shaft_high_kW                                                    120
        power_limit_shaft_max_kW                                                     150
        pressure_limit_housing_atma                                                  390
        d_motor_od_mm                                                                 95
        rate_points                    [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55,...
        head_points                    [4.88, 4.73, 4.66, 4.61, 4.52, 4.35, 4.1, 3.74...
        power_points                   [0.02, 0.022, 0.025, 0.027, 0.03, 0.032, 0.035...
        eff_points                     [0, 0.12, 0.21, 0.29, 0.35, 0.38, 0.4, 0.39, 0...
        Name: 99999, dtype: object

        >>> # Исходные данные для ПЭД
        >>> motor_data ={"ID": 1,
        ...         "manufacturer": "Centrilift",
        ...         "name": "562Centrilift-KMB-130-2200B",
        ...         "d_motor_mm": 142.7,
        ...         "motor_nom_i": 35,
        ...         "motor_nom_power": 96.98,
        ...         "motor_nom_voltage": 2200,
        ...         "motor_nom_eff": 80,
        ...         "motor_nom_cosf": 0.82,
        ...         "motor_nom_freq": 60,
        ...         "load_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        ...         "amperage_points": [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3],
        ...         "cosf_points": [0.7, 0.74, 0.77, 0.8, 0.83, 0.85, 0.86, 0.87, 0.88, 0.88],
        ...         "eff_points": [0.78, 0.83, 0.85, 0.88, 0.87, 0.87, 0.87, 0.87, 0.86, 0.86],
        ...         "rpm_points": [3568.604, 3551.63, 3534.656, 3517.682, 3500.708, 3483.734, 3466.76, 3449.786,
        ...                       3432.812, 3415.838]
        ...         }

        >>> # Инициализация исходных данных
        >>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1200], [1800, 1542.85]])
        >>> # Возможный способ задания инклинометрии через dict
        >>> # df = {"MD": [0, 1000],
        >>> #       "TVD": [0, 900]}
        >>>
        >>> # В словари с калибровками подается давление и температура калибровки.
        >>> # Зачастую - это давление насыщения и пластовая температура
        >>> fluid_data = {"q_fluid": uc.convert_rate(40, "m3/day", "m3/s"), "wct": 0,
        ...      "pvt_model_data": {
        ...          "black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8, "rp": 20,
        ...                "oil_correlations": {"pb": "Standing", "rs": "Standing", "rho": "Standing",
        ...                                     "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
        ...                "gas_correlations": {"ppc": "Standing", "tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
        ...                "water_correlations": {"b": "McCain", "compr": "Kriel", "rho": "Standing", "mu": "McCain"},
        ...                "rsb": {"value": 50, "p": 10000000, "t": 303.15},
        ...                "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
        ...                "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
        ...                "table_model_data": None, "use_table_model": False}}}
        >>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        >>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        >>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        >>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001},
        ...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005}}
        >>> well_trajectory_data = {"inclinometry": df}
        >>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
        >>> equipment_data = {"esp_system": {"esp": {"esp_data": esp_data,
        ...                                         "stages": 345,
        ...                                         "viscosity_correction": True,
        ...                                         "gas_correction": True,
        ...                                         },
        ...                                 "esp_electric_system": {"motor_data": motor_data,
        ...                                                         "gassep_nom_power": 500,
        ...                                                         "protector_nom_power": 500,
        ...                                                         "transform_eff": 0.97,
        ...                                                         "cs_eff": 0.97,
        ...                                                         "cable_specific_resistance": 1.18,
        ...                                                         "cable_length": 1450,
        ...                                                         },
        ...                                 "separator": {"k_gas_sep": 0.7,
                                                        "sep_name": '3МНГДБ5'}},
        ...                     "packer": False}
        >>> # Текущая частота
        >>> freq = 53
        >>> # Затрубное давление
        >>> p_ann = 10 * 101325

        >>> # Инициализация объекта скважины
        >>> well = EspWell(fluid_data, pipe_data, equipment_data, well_trajectory_data,
        ...                ambient_temperature_data)
        >>> # Расчет с сохранением доп. атрибутов распределений свойств
        >>> result = well.calc_pwf_pfl(uc.convert_pressure(12, "atm", "Pa"),
        ...                          uc.convert_rate(40, "m3/day", "m3/s"),
        ...                          0.1, freq, p_ann=p_ann, output_params=True)
        >>> # Запрос всех значений доп. свойств в виде словаря
        >>> extra_results = well.extra_output
        """
        # Считаем что скважина ЭЦН всегда без пакера и в ней есть естественная сепарация
        super().__init__(
            fluid_data,
            pipe_data,
            equipment_data,
            well_trajectory_data,
            ambient_temperature_data,
        )

        if "esp_system" in equipment_data:
            equipment_data["esp_system"]["esp"].update(
                {"fluid": self.fluid, "h_mes": self.tubing.bottom_depth}
            )

            if "esp_electric_system" in equipment_data["esp_system"]:
                self.__freq_base = equipment_data["esp_system"]["esp"]["esp_data"][
                    "freq_Hz"
                ]
                equipment_data["esp_system"]["esp_electric_system"].update(
                    {"pump_nom_freq": self.__freq_base}
                )
                self.__q_liq_max = (
                    max(equipment_data["esp_system"]["esp"]["esp_data"]["rate_points"])
                    / 86400
                )

                if equipment_data["esp_system"]["esp_electric_system"].get(
                    "cable_length"
                ):
                    if (
                        equipment_data["esp_system"]["esp_electric_system"][
                            "cable_length"
                        ]
                        < self.tubing.bottom_depth
                    ):
                        equipment_data["esp_system"]["esp_electric_system"][
                            "cable_length"
                        ] = self.tubing.bottom_depth
                else:
                    equipment_data["esp_system"]["esp_electric_system"].update(
                        {"cable_length": self.tubing.bottom_depth}
                    )

            if "separator" in equipment_data["esp_system"]:
                if equipment_data["esp_system"]["separator"]:
                    equipment_data["esp_system"]["separator"].update(
                        {"h_mes": self.tubing.bottom_depth}
                    )

            self.esp_system = esp_sys.EspSystem(**equipment_data["esp_system"])
        else:
            self.esp_system = None

        if self.natural_sep:
            self.annulus = ann.Annulus(
                fluid=self.fluid,
                bottom_depth=pipe_data["tubing"]["bottom_depth"],
                ambient_temperature_distribution=self.amb_temp_dist,
                d_casing=pipe_data["casing"]["d"],
                d_tubing=pipe_data["tubing"]["d"],
                s_wall=pipe_data["tubing"]["s_wall"],
                roughness=pipe_data["casing"]["roughness"],
                trajectory=self.well_trajectory,
            )
        else:
            self.annulus = None

        self.__output_objects = dict()

    @property
    def extra_output(self):
        """
        Сборный атрибут со всеми требуемыми распределениями
        """
        self._extra_output.update(
            {
                "rate_points_corr": self.esp_system.rate_points_corr.tolist(),
                "head_points_corr": self.esp_system.head_points_corr.tolist(),
                "power_points_corr": self.esp_system.power_points_corr.tolist(),
                "eff_points_corr": self.esp_system.eff_points_corr.tolist(),
            }
        )
        return self._extra_output

    def __make_nodes(self):
        """
        Создание распределений ключевых узлов

        :return: распределение ключевых узлов
        """
        nodes_tub = [None for _ in self.tubing.distributions["depth"]]
        nodes_tub[0] = "Буфер"
        nodes_esp = [None for _ in self.esp_system.distributions["depth"]]
        nodes_esp[0] = "Выкид ЭЦН"
        nodes_esp[-1] = "Прием ЭЦН"
        nodes_cas = [None for _ in self.casing.distributions["depth"]]
        nodes_cas[-1] = "Верхние дыры перфорации"
        result = nodes_tub + nodes_esp + nodes_cas

        if self.choke and "depth" in self.choke.distributions:
            nodes_ch = [None for _ in self.choke.distributions["depth"]]
            nodes_ch[0] = "Линия"
            result = nodes_ch + result
        return result

    def __calc_p_dis_error_abs(
        self,
        p_in: float,
        p_fl: float,
        t_in: float,
        q_liq: float,
        wct: float,
        freq: float,
        hydr_corr_type: str,
        head_factor: float,
        c_choke: float,
        step_length: float,
        output_params: bool,
        heat_balance: bool,
        c_pump_power: float,
        c_cosf: float,
        c_amperage: float,
        c_transform_power: float,
        c_motor_volt: float,
    ):
        return abs(
            self.__calc_p_dis_error(
                p_in,
                p_fl,
                t_in,
                q_liq,
                wct,
                freq,
                hydr_corr_type,
                head_factor,
                c_choke,
                step_length,
                output_params,
                heat_balance,
                c_pump_power,
                c_cosf,
                c_amperage,
                c_transform_power,
                c_motor_volt,
            )
        )

    def __calc_p_dis_error(
        self,
        p_in: float,
        p_fl: float,
        t_in: float,
        q_liq: float,
        wct: float,
        freq: float,
        hydr_corr_type: str,
        head_factor: float,
        c_choke: float,
        step_length: float,
        output_params: bool,
        heat_balance: bool,
        c_pump_power: float,
        c_cosf: float,
        c_amperage: float,
        c_transform_power: float,
        c_motor_volt: float,
    ):
        """
        Расчет ошибки в давлении на выкиде
        :return: невязка в давлении на выкиде
        """
        self.fluid.reinit()
        self.fluid.calc_flow(p_in, t_in)

        if self.natural_sep:
            # ! Временная заглушка до проверки расчета естественной сепарации
            k_sep_nat = 0.5
        else:
            k_sep_nat = 0

        k_sep = self.esp_system.calc_general_separation(
            k_sep_nat, self.fluid.gf, q_liq, freq
        )
        # Модификация флюида и обновление объектов
        self.fluid.modify(p_in, t_in, k_sep)

        self.tubing.fluid = copy.deepcopy(self.fluid)
        self.esp_system.esp.fluid = copy.deepcopy(self.fluid)

        # Расчет давления и температуры на выкиде от приема
        t_cable = t_in
        res = self.esp_system.calc_esp_system(
            q_liq=q_liq,
            wct=wct,
            p=p_in,
            t=t_in,
            freq=freq,
            t_cable=t_cable,
            direction_to="dis",
            head_factor=head_factor,
            extra_output=output_params,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        p_dis_down = res[0]
        t_fl = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()

        # Расчет давления и температуры на буфере
        if self.choke:

            if isinstance(c_choke, dict) and "const" in c_choke:
                p_wh, t_wh = p_fl + c_choke["const"], t_fl
            else:
                self.choke.fluid = copy.deepcopy(self.fluid)
                self.__output_objects["choke"] = self.choke
                p_wh, t_wh, *_ = self.choke.calc_pt(
                    p_fl, t_fl, 1, q_liq, wct, None, c_choke, extra_output=output_params
                )
        else:
            p_wh, t_wh = p_fl, t_fl

        # Расчет давления и температуры на выкиде от буфера
        p_dis_top, *_ = self.tubing.calc_pt(
            "top",
            p_wh,
            1,
            q_liq,
            wct,
            None,
            t_wh,
            hydr_corr_type,
            step_length,
            extra_output=output_params,
            heat_balance=heat_balance,
        )

        return p_dis_top - p_dis_down

    def __calc_p_in(
        self,
        p_fl: float,
        q_liq: float,
        wct: float,
        freq: float,
        p_ann: float,
        hydr_corr_type: str,
        head_factor: float,
        step_length: float,
        output_params: bool,
        heat_balance: bool,
        c_choke: float,
        c_pump_power: float,
        c_cosf: float,
        c_amperage: float,
        c_transform_power: float,
        c_motor_volt: float,
    ):
        """
        Функция расчета давления на приеме итеративно по давлению в линии
        """
        t_in = self.amb_temp_dist.calc_temp(self.tubing.bottom_depth).item()

        try:
            p_in = opt.brenth(
                self.__calc_p_dis_error,
                a=101325,
                b=const.P_UP_LIMIT,  # 700 атм
                args=(
                    p_fl,
                    t_in,
                    q_liq,
                    wct,
                    freq,
                    hydr_corr_type,
                    head_factor,
                    c_choke,
                    step_length,
                    False,
                    heat_balance,
                    c_pump_power,
                    c_cosf,
                    c_amperage,
                    c_transform_power,
                    c_motor_volt,
                ),
                xtol=10000,
            )
            convergence = 1
        except ValueError:
            p_in = opt.minimize_scalar(
                self.__calc_p_dis_error_abs,
                method="bounded",
                bounds=(101325, const.P_UP_LIMIT),  # 700 атм
                args=(
                    p_fl,
                    t_in,
                    q_liq,
                    wct,
                    freq,
                    hydr_corr_type,
                    head_factor,
                    c_choke,
                    step_length,
                    False,
                    heat_balance,
                    c_pump_power,
                    c_cosf,
                    c_amperage,
                    c_transform_power,
                    c_motor_volt,
                ),
                options={"xatol": 50000},
            )
            p_in = p_in.x
            convergence = 0
        results = list(
            self.calc_pfl_pin(
                p_in=p_in,
                t_in=t_in,
                q_liq=q_liq,
                wct=wct,
                freq=freq,
                p_ann=p_ann,
                hydr_corr_type=hydr_corr_type,
                head_factor=head_factor,
                c_choke=c_choke,
                step_length=step_length,
                output_params=output_params,
                heat_balance=heat_balance,
                optimizer=False,
                finalize=True,
                c_pump_power=c_pump_power,
                c_cosf=c_cosf,
                c_amperage=c_amperage,
                c_transform_power=c_transform_power,
                c_motor_volt=c_motor_volt,
            )
        )
        results[-1] = convergence

        return results

    def calc_pfl_pin(
        self,
        p_in: float,
        t_in: float,
        q_liq: float,
        wct: float,
        freq: float,
        p_ann: float,
        hydr_corr_type: str,
        head_factor: float,
        c_choke: Optional[Union[float, dict]],
        step_length: float,
        output_params: bool,
        heat_balance: bool,
        optimizer: bool = False,
        finalize: bool = False,
        c_pump_power: float = 1,
        c_cosf: float = 1,
        c_amperage: float = 1,
        c_transform_power: float = 1,
        c_motor_volt: float = 1,
    ):

        """
        Расчет линейного давления по давлению на приеме

        :param p_in: давление на приеме, Па абс.
        :param t_in: температура на приеме, К
        :param q_liq: дебит жидкости, м3/с
        :param wct: обводненность, доли ед.
        :param freq: частота вращения вала ЭЦН, Гц
        :param p_ann: затрубное давление, Па изб.
        :param hydr_corr_type: тип гидравлической корреляции
        :param head_factor: к-т адаптации на напор ЭЦН
        :param c_choke: адаптационный коэффициент штуцера
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг для расчета распределений параметров
        :param heat_balance: опция расчета теплопотерь
        :param optimizer: опция считать ли доп. параметры (False) \
         или считать только необходимое (для оптимизатора-True)
        :param finalize: рассчитать общие распределения для скважины
        :param c_pump_power: адаптационный коэффициент для мощности насоса
        :param c_cosf: корректировочный коэффициент для зависимости загрузка-косинус мощности
        :param c_amperage: корректировочный коэффициент для зависимости загрузка-сила тока
        :param c_transform_power: адаптационный коэффициент для мощности на трансформаторе
        :param c_motor_volt: адаптационный коэффициент для напряжение на ПЭД

        :return: линейное давление, Па абс.
        :return: мощность на станции управления, Вт
        :return: динамический уровень, м
        :return: напряжение на трансформаторе, В
        :return: сила тока ПЭД, А
        :return: загрузка ПЭД, доли ед.
        :return: КПД насоса факт., доли ед.
        :return: КПД системы, доли ед.
        :return: Коэффициент сепарации общий, доли ед.
        :return: давление на приеме, Па изб.
        :return: температура ПЭД, К
        :return: мощность ЭЦН, Вт
        :return: мощность ПЭД, Вт
        :return: доля газа на приеме насоса, доли ед.
        :return: флаг сходимости расчета, 1 - сошлось, 0 - нет
        """

        self.fluid.reinit()
        self.fluid.calc_flow(p_in, t_in)

        if self.natural_sep:
            # ! Временная заглушка до проверки расчета естественной сепарации
            k_sep_nat = 0.5
        else:
            k_sep_nat = 0

        k_sep_gen = self.esp_system.calc_general_separation(
            k_sep_nat, self.fluid.gf, q_liq, freq
        )

        # Модификация флюида и обновление объектов
        self.fluid.modify(p_in, t_in, k_sep_gen)
        self.fluid.calc_flow(p_in, t_in)
        gas_fraction = self.fluid.gf

        self.tubing.fluid = copy.deepcopy(self.fluid)
        self.esp_system.esp.fluid = copy.deepcopy(self.fluid)
        if self.choke and not isinstance(self.choke, dict):
            self.choke.fluid = copy.deepcopy(self.fluid)

        # Расчет давления и температуры на выкиде
        t_cable = t_in
        res = self.esp_system.calc_esp_system(
            q_liq=q_liq,
            wct=wct,
            p=p_in,
            t=t_in,
            freq=freq,
            t_cable=t_cable,
            direction_to="dis",
            head_factor=head_factor,
            extra_output=output_params,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        p_dis = res[0]
        t_dis = res[1]
        el_params = res[3:]

        # Расчет давления и температуры на буфере
        p_wh, t_wh, status = self.tubing.calc_pt(
            "bottom",
            p_dis,
            -1,
            q_liq,
            wct,
            None,
            t_dis,
            hydr_corr_type,
            step_length,
            extra_output=output_params,
            heat_balance=heat_balance,
        )

        # Дополнительный расчет параметров
        h_dyn = None
        if not optimizer:

            if self.natural_sep:
                # Расчет динамического уровня
                if p_ann is None:
                    raise exc.UniflocPyError(
                        "Не задано затрубное давление. "
                        "Расчет динамического уровня невозможен"
                    )
                self.fluid.reinit()
                self.annulus.fluid = deepcopy(self.fluid)
                self.annulus.fluid.modify(p_in, t_in, k_sep_gen, calc_type="annulus")
                t_ann = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()
                h_dyn, _ = self.annulus.calc_hdyn(
                    p_in, t_in, p_ann, t_ann, wct, step_length, heat_balance
                )
            else:
                h_dyn = None

        if finalize:
            # Сохранение доп.атрибутов
            self.__output_objects["esp_sys"] = self.esp_system
            self.__output_objects["tubings"] = [self.tubing]

        if status != 0:
            # Случай неуспешного расчета до буфера
            if finalize:
                # Сохранение доп.атрибутов
                self._extra_output = tls.make_unified_distributions(
                    **self.__output_objects
                )
            if optimizer:
                # Костыль до разработки оптимизатора с динамическими границами
                p_wh = -9999999999
            return (
                p_wh,
                el_params[9],
                h_dyn,
                el_params[7],
                el_params[5],
                el_params[3],
                el_params[10],
                el_params[11],
                k_sep_gen,
                p_in,
                t_in,
                el_params[2],
                el_params[4],
                gas_fraction,
                status,
            )

        # Расчет давления и температуры в линии
        if self.choke:

            if isinstance(c_choke, dict) and "const" in c_choke:
                p_fl, t_fl = p_wh - c_choke["const"], t_wh
            else:
                try:
                    self.__output_objects["choke"] = self.choke
                    p_fl, t_fl, *_ = self.choke.calc_pt(
                        p_wh,
                        t_wh,
                        -1,
                        q_liq,
                        wct,
                        None,
                        c_choke,
                        extra_output=output_params,
                    )
                except exc.UniflocPyError:
                    p_fl, t_fl = p_wh, t_wh
        else:
            p_fl, t_fl, status = p_wh, t_wh, 0

        if not optimizer and finalize and "casing" in self.__output_objects:
            self._extra_output = tls.make_unified_distributions(**self.__output_objects)

        return (
            p_fl,
            el_params[9],
            h_dyn,
            el_params[7],
            el_params[5],
            el_params[3],
            el_params[10],
            el_params[11],
            k_sep_gen,
            p_in,
            t_in,
            el_params[2],
            el_params[4],
            gas_fraction,
            status,
        )

    def calc_pfl_pwf(
        self,
        p_wf: float,
        q_liq: float,
        wct: float,
        freq: float,
        p_ann: Optional[float] = None,
        hydr_corr_type: Optional[str] = None,
        head_factor: Optional[float] = None,
        step_length: float = 10,
        output_params: bool = False,
        heat_balance: bool = False,
    ) -> tuple:
        """
        Расчет линейного давления по забойному с учетом всех гидравлических элементов

        Parameters
        ----------
        :param p_wf: забойное давление, Па абс.
        :param q_liq: дебит жидкости, ст. м3/с
        :param wct: обводненность, доли ед.
        :param freq: частота работы эцн, Гц
        :param p_ann: затрубное давление, Па изб.
        :param hydr_corr_type: тип гидравлической корреляции
        :param head_factor: к-т адаптации на напор ЭЦН
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг расчета распределений параметров
        :param heat_balance: опция расчета теплопотерь

        :return: линейное давление, Па абс.
        :return: мощность на станции управления, Вт
        :return: динамический уровень, м
        :return: напряжение на трансформаторе, В
        :return: сила тока ПЭД, А
        :return: загрузка ПЭД, доли ед.
        :return: КПД насоса факт., доли ед.
        :return: КПД системы, доли ед.
        :return: коэффициент сепарации общий, доли ед.
        :return: давление на приеме, Па изб.
        :return: температура ПЭД, К
        :return: мощность ЭЦН, Вт
        :return: мощность ПЭД, Вт
        :return: доля газа на приеме насоса, доли ед.
        :return: статус расчёта:
                 0 - расчет успешный;
                 1 - достигнуто минимальное давление, невозможно рассчитать линейное давление;
                 -1 - ошибка интегрирования

        """
        # Установим дебит жидкости и обводненность в флюид и переопределим флюид для всех
        # зависимых от него классов
        self.__output_objects = {"params": ["p", "t", "depth"]}

        if output_params:
            self.__output_objects["params"] += const.DISTRS

        self._reinit(wct, q_liq)
        self.casing.fluid = deepcopy(self.fluid)

        # Расчет давления, температуры на приеме по ЭК вверх
        t_wf = self.amb_temp_dist.calc_temp(self.casing.bottom_depth).item()
        p_in, t_in, status = self.casing.calc_pt(
            "bottom",
            p_wf,
            -1,
            q_liq,
            wct,
            None,
            t_wf,
            hydr_corr_type,
            step_length,
            extra_output=output_params,
            heat_balance=heat_balance,
        )

        self.__output_objects["casing"] = self.casing
        if status != 0:
            # Случай неуспешного расчета до приема
            self._extra_output = tls.make_unified_distributions(**self.__output_objects)
            return None, 0, None, 0, 0, 0, 0, 0, 0, p_in, t_in, 0, 0, 0, status

        # Расчет давления во всех остальных узлах (выкид, буфер, линия)
        results = self.calc_pfl_pin(
            p_in,
            t_in,
            q_liq,
            wct,
            freq,
            p_ann,
            hydr_corr_type,
            head_factor,
            None,
            step_length,
            output_params,
            heat_balance,
            False,
            True,
        )
        return results

    def calc_pwf_pfl(
        self,
        p_fl: float,
        q_liq: float,
        wct: float,
        freq: float,
        p_wh: Optional[float] = None,
        p_ann: Optional[float] = None,
        hydr_corr_type: Optional[str] = None,
        head_factor: Optional[float] = None,
        c_choke: Optional[Union[float, dict]] = None,
        c_pump_power: float = 1,
        c_cosf: float = 1,
        c_amperage: float = 1,
        c_transform_power: float = 1,
        c_motor_volt: float = 1,
        step_length: float = 10,
        output_params: bool = False,
        heat_balance: bool = False,
    ) -> list:
        """
        Расчет забойного давления по линейному с учетом всех гидравлических элементов

        Parameters
        ----------
        :param p_fl: линейное давление, Па абс.
        :param q_liq: дебит жидкости, ст. м3/с
        :param wct: обводненность, доли ед.
        :param freq: частота вращения вала ЭЦН, Гц
        :param p_wh: буферное давление, Па абс.
        :param p_ann: затрубное давление, Па изб.
        :param hydr_corr_type: тип гидравлической корреляции
        :param head_factor: к-т адаптации на напор ЭЦН
        :param c_choke: адаптационный коэффициент штуцера\
        Задается в виде числа как коэффициент калибровки, либо как словарь {"const": value},\
        где value - постоянный перепад, который будет использоваться как перепад между буферным и линейным давлением
        :param c_pump_power: адаптационный коэффициент для мощности насоса
        :param c_cosf: корректировочный коэффициент для зависимости загрузка-косинус мощности
        :param c_amperage: корректировочный коэффициент для зависимости загрузка-сила тока
        :param c_transform_power: адаптационный коэффициент для мощности на трансформаторе
        :param c_motor_volt: адаптационный коэффициент для напряжение на ПЭД
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг расчета распределений параметров
        :param heat_balance: опция расчета теплопотерь

        :return: забойное давление, Па абс.
        :return: мощность на станции управления, Вт
        :return: динамический уровень, м
        :return: напряжение на трансформаторе, В
        :return: сила тока ПЭД, А
        :return: загрузка ПЭД, доли ед.
        :return: КПД насоса факт., доли ед.
        :return: КПД системы, доли ед.
        :return: коэффициент сепарации общий, доли ед.
        :return: давление на приеме, Па изб.
        :return: температура ПЭД, К
        :return: мощность ЭЦН, Вт
        :return: мощность ПЭД, Вт
        :return: доля газа на приеме насоса, доли ед.
        :return: флаг сходимости расчета:
                 1 - сошлось;
                 0 - нет
        """

        # Установим дебит жидкости и обводненность в флюид и переопределим флюид для всех
        # зависимых от него классов
        self.__output_objects = {"params": ["p", "t", "depth"]}

        if output_params:
            self.__output_objects["params"] += const.DISTRS

        self._reinit(wct, q_liq)
        self.casing.fluid = deepcopy(self.fluid)

        # 1. Расчет в штуцере, если он есть
        if self.choke:
            t_fl = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()
            self.choke.fluid = deepcopy(self.fluid)

            # 1.1 Адаптация штуцера в случае наличия буферного давления и отсутствия коэффициента штуцера
            if p_wh is not None and c_choke is None:
                c_choke = com.adapt_choke(self.choke, p_fl, p_wh, t_fl, q_liq, wct)

        # Расчет давления, температуры на приеме и остальных требуемых параметров
        results = self.__calc_p_in(
            p_fl=p_fl,
            q_liq=q_liq,
            wct=wct,
            freq=freq,
            p_ann=p_ann,
            hydr_corr_type=hydr_corr_type,
            head_factor=head_factor,
            step_length=step_length,
            output_params=output_params,
            heat_balance=heat_balance,
            c_choke=c_choke,
            c_pump_power=c_pump_power,
            c_cosf=c_cosf,
            c_amperage=c_amperage,
            c_transform_power=c_transform_power,
            c_motor_volt=c_motor_volt,
        )

        # Расчет давления на забое по ЭК вниз
        p_wf, *_ = self.casing.calc_pt(
            "top",
            results[9],
            1,
            q_liq,
            wct,
            None,
            results[10],
            hydr_corr_type,
            step_length,
            extra_output=output_params,
            heat_balance=heat_balance,
        )
        self.__output_objects["casing"] = self.casing
        # Сохранение результата
        results[0] = p_wf

        # Сохранение дополнительных атрибутов распределений
        self._extra_output = tls.make_unified_distributions(**self.__output_objects)
        self._extra_output["nodes"] = self.__make_nodes()

        return results
