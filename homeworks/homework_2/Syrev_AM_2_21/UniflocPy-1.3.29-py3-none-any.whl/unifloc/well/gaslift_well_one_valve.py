from copy import deepcopy
from typing import Optional, Tuple, Union

import numpy as np
import scipy.interpolate as interp
import scipy.optimize as opt
import shapely.geometry as shp

import unifloc.equipment.gl_system as gl_sys
import unifloc.equipment.choke as chk
import unifloc.pipe.annulus as ann
import unifloc.service._constants as const
import unifloc.service._tools as tls
import unifloc.tools.common_calculations as com
import unifloc.tools.exceptions as exc
import unifloc.well._well as abw


class GasLiftWellOneValve(abw.AbstractWell):
    """
    Класс для расчета газлифтной скважины с одним рабочим клапаном.

    Принимает на вход словари с исходными данными.

    Структура словарей исходных данных:

    * fluid_data ("ключ" - определение - тип) - dict
        * "q_fluid" - дебит жидкости в ст.у., ст. м/c - float
        * "wct" - объемная обводненность, доли ед. - float
        * "pvt_model_data" - словарь с флюидами - dict
            * "black_oil" - словарь с свойствами нефти, газа и воды для модели Black Oil - dict
                * "gamma_gas" - относительная плотность газа по воздуху в ст.у.
                 (плотность воздуха = 1.2217 кг/м3)-float
                * "gamma_oil" - относительная плотность нефти по воде в ст.у.
                 (плотность воды = 1000 кг/м3) - float
                * "gamma_wat" - относительная плотность воды по воде в ст.у.
                 (плотность воды = 1000 кг/м3) - float
                * "rp" - газовый фактор, ст. м3 газа/ст. м3 нефти - float
                * "oil_correlations" - словарь с набором корреляций для нефти - dict, optional
                    * "pb" - название корреляции для давления насыщения - string, optional
                        * Возможные значения: "Standing"
                    * "rs" - название корреляции для газосодержания - string, optional
                        * Возможные значения: "Standing"
                    * "rho" - название корреляции для плотности нефти - string, optional
                        * Возможные значения: "Standing"
                    * "mu" - название корреляции для вязкости нефти - string, optional
                        * Возможные значения: "Beggs"
                    * "b" - название корреляции для объемного коэффициента нефти - string, optional
                        * Возможные значения: "Standing"
                    * "compr" - название корреляции для сжимаемости нефти - string, optional
                        * Возможные значения: "Vasquez"
                * "gas_correlations" - словарь с набором корреляций для газа - dict, optional
                    * "ppc" - название корреляции для критического давления - string, optional
                        * Возможные значения: "Standing"
                    * "tpc" - название корреляции для критической температуры - string, optional
                        * Возможные значения: "Standing"
                    * "z" - название корреляции для z-фактора - string, optional
                        * Возможные значения: "Kareem", "Dranchuk"
                    * "mu" - название корреляции для вязкости газа - string, optional
                        * Возможные значения: "Lee"
                * "water_correlations" - словарь с набором корреляций для газа - dict, optional
                    * "b" - название корреляции для объемного коэффициента воды - string, optional
                        * Возможные значения: "McCain"
                    * "rho" - название корреляции для плотности воды - string, optional
                        * Возможные значения: "Standing", "IAPWS"
                    * "mu" - название корреляции для вязкости воды - string, optional
                        * Возможные значения: "McCain", "IAPWS"
                    * "compr" - название корреляции для сжимаемости воды - string, optional
                        * Возможные значения: "Kriel"
                * "salinity" - минерализация воды, ppm - float, optional
                * "rsb" - словарь с калибровочным значением газосодержания при давлении насыщения -
                dict, optional
                    * "value" - калибровочное значение газосодержания при давлении насыщения,
                    ст. м3 газа/ст. м3 нефти - float
                    * "p" - давление калибровки, Па абс. - float
                    * "t" - температура калибровки газосодержания, К - float
                * "bob" - словарь с калибровочным значением объемного коэффициента нефти при
                давлении насыщения - dict, optional
                    * "value" - калибровочное значение объемного коэффициента нефти при давлении
                    насыщения, ст. м3/ст. м3 - float
                    * "p" - давление калибровки, Па абс. - float
                    * "t" - температура калибровки объемного коэффициента нефти, К - float
                * "muob" - словарь с калибровочным значением вязкости нефти при давлении насыщения
                - dict, optional
                    * "value" - калибровочное значение вязкости нефти при давлении насыщения,
                    сПз - float
                    * "p" - давление калибровки, Па абс. - float
                    * "t" - температура калибровки вязкости нефти, К - float
                * "table_model_data" - словарь с исходными данными табличной модели - dict, optional
                    * "pvt_dataframes_dict" - словарь с таблицами с исходными данными
                    - dict of DataFrames
                    * "interp_type" -  тип интерполяции (по умолчанию - линейный) - string, optional
                * "use_table_model" - флаг использования табличной модели - boolean, optional
    * pipe_data ("ключ" - определение - тип) - dict
        * "casing" - словарь с исходными данными для создания ЭК - dict
            * "bottom_depth" - измеренная глубина верхних дыр перфорации, м - float
            * "d" - внутренний диаметр ЭК, м - float, pd.DataFrame("MD", "d")
            * ! можно задавать как числом, так и таблицей с распределением по глубине или словарем,
             см. пример
            * "roughness" - шероховатость, м - float

        * "tubing" - словарь с исходными данными для создания колонны НКТ - dict
            * "bottom_depth" - измеренная глубина спуска колонны НКТ, м - float
            * "d" - внутренний диаметр колонны НКТ, м - float, pd.DataFrame("MD", "d")
            * ! можно задавать как числом, так и таблицей с распределением по глубине или словарем,
             см. пример
            * "roughness" - шероховатость, м - float
            * "s_wall" - толщина стенки, м - float
    * well_trajectory_data ("ключ" - определение - тип) - dict
        * "inclinometry" - таблица с инклинометрией, две колонки: "MD","TVD", индекс по умолчанию,
         см.пример - DataFrame
        * или возможно с помощью dict с ключами "MD", "TVD"
    * ambient_temperature_data ("ключ" - определение - тип) - словарь с распределением температуры
     породы по MD - dict
        * обязательные ключи MD, T - list
    * equipment_data ("ключ" - определение - тип) - dict, optional
        * "choke" - словарь с исходными данными для создания объекта штуцера - dict, optional
            * "d" - диаметр штуцера, м - float
        * "ann_choke" - словарь с исходными данными для создания объекта штуцера на газовой линии - dict, optional
            * "d" - диаметр штуцера, м - float
        * "gl_system" - словарь с исходными данными для создания системы газлифтных клапанов -
         dict, optional
            * "**valves_data" - произвольное количество словарей с газлифтными клапанами
                * Ключем словаря обязательно должен быть ключ начинающийся с "valve", например
                "valve1", "valve2"
                * Аргументы словаря:
                    * "h_mes" - измеренная глубина установки клапана, м - float
                    * "d" - диаметр клапана, м - float, optional
                    * "p_valve" - давление зарядки клапана, Па абс. - float, optional
                    * "s_bellow" - площадь поперечного сечения сильфона клапана, м2 - float, optional
                    * "valve_type" - тип клапана - string, optional
                * Если непонятно, см. пример ниже
    """

    def __init__(
        self,
        fluid_data: dict,
        pipe_data: dict,
        well_trajectory_data: dict,
        ambient_temperature_data: dict,
        equipment_data: Optional[dict] = None,
    ):
        """
        Parameters
        ----------
        :param fluid_data: словарь с исходными данными для создания флюида
        :param pipe_data: словарь с исходными данными для создания колонн труб
        :param well_trajectory_data: словарь с исходными данными для создания инклинометрии скважины
        :param ambient_temperature_data: словарь с распределением температуры породы по MD
        :param equipment_data: словарь с исходными данными для создания различного оборудования,
         optional

        Examples:
        --------
        >>> import pandas as pd
        >>> import unifloc.tools.units_converter as uc
        >>> from unifloc.well.gaslift_well_one_valve import GasLiftWellOneValve
        >>> # Инициализация исходных данных
        >>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1400], [1800, 1800]])
        >>> # Возможный способ задания инклинометрии через dict
        >>> # df = {"MD": [0, 1000],
        >>> #       "TVD": [0, 900]}
        >>>
        >>> # В словари с калибровками подается давление и температура калибровки.
        >>> # Зачастую - это давление насыщения и пластовая температура
        >>> fluid_data = {"q_fluid": uc.convert_rate(100, "m3/day", "m3/s"), "wct": 0.1,
        ...               "pvt_model_data": {"black_oil": {"gamma_gas": 0.7, "gamma_wat": 1, "gamma_oil": 0.8,
        ...               "rp": 300,
        ...               "oil_correlations": {"pb": "Standing", "rs": "Standing","rho": "Standing",
        ...               "b": "Standing", "mu": "Beggs", "compr": "Vasquez"},
        ...               "gas_correlations":
        ...               {"ppc": "Standing","tpc": "Standing", "z": "Dranchuk", "mu": "Lee"},
        ...               "water_correlations": {"b": "McCain", "compr": "Kriel","rho": "Standing",
        ...               "mu": "McCain"},
        ...               "rsb": {"value": 300, "p": 10000000, "t": 303.15},
        ...               "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
        ...               "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
        ...               "table_model_data": None, "use_table_model": False}}}
        >>> # Диаметр можно задавать как числом так и таблицей с распределением по глубине
        >>> d = pd.DataFrame(columns=["MD", "d"], data=[[0, 0.062], [1000, 0.082]])
        >>> # Так тоже возможно: d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        >>> pipe_data = {"casing": {"bottom_depth": 1800, "d": 0.146, "roughness": 0.0001, "s_wall": 0.005},
        ...              "tubing": {"bottom_depth": 1400, "d": d, "roughness": 0.0001, "s_wall": 0.005}}
        >>> well_trajectory_data = {"inclinometry": df}
        >>> equipment_data = {"gl_system": {
        ...                   "valve1": {"h_mes": 800, "d": 0.006,
        ...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
        ...                              "valve_type": "ЦКсОК"},
        ...                   "valve2": {"h_mes": 850, "d": 0.006,
        ...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
        ...                              "valve_type": "ЦКсОК"},
        ...                   "valve3": {"h_mes": 900, "d": 0.006,
        ...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
        ...                              "valve_type": "ЦКсОК"},
        ...                   "valve4": {"h_mes": 1000, "d": 0.006,
        ...                               "p_valve": uc.convert_pressure(3, "atm", "Pa"),
        ...                              "valve_type": "ЦКсОК"}
        ...                                               }
        ...                   }
        >>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
        >>>
        >>> # Инициализация объекта скважины
        >>> well = GasLiftWellOneValve(fluid_data, pipe_data, well_trajectory_data,
        ...                    ambient_temperature_data, equipment_data)
        >>> # Расчет линейного давления
        >>> parameters = well.calc_pwh_pwf(p_wf=uc.convert_pressure(20, "MPa", "Pa"),
        ...                                q_liq=uc.convert_rate(100, "m3/day", "m3/s"), wct=0.1,
        ...                                p_gas_inj=uc.convert_pressure(15, "MPa", "Pa"))
        >>> # Расчет забойного давления
        >>> p_fl = parameters[0]
        >>> q_inj = well.gl_system.q_inj
        >>> # Расчет с сохранением доп. атрибутов распределений свойств
        >>> p_wf = well.calc_pwf_pfl(p_fl=p_fl, q_liq=uc.convert_rate(100, "m3/day", "m3/s"), wct=0.1,
        ...                          q_gas_inj=q_inj,
        ...                          output_params=True)
        >>> # Запрос всех значений доп. свойств в виде словаря
        >>> result = well.extra_output
        >>> result_ann = well.extra_output_annulus
        """
        super().__init__(
            fluid_data,
            pipe_data,
            equipment_data,
            well_trajectory_data,
            ambient_temperature_data,
        )
        if (
            equipment_data is not None
            and "gl_system" in equipment_data
            and equipment_data["gl_system"] is not None
        ):
            self.gl_system = gl_sys.GlSystem(equipment_data["gl_system"])
        else:
            # Считаем, что клапанов нет
            self.gl_system = gl_sys.GlSystem(
                {"valve": {"h_mes": self.tubing.bottom_depth, "d": 0.006}}
            )

        # Флюид для расчета затрубного пространства
        self.annulus_fluid = deepcopy(self.fluid)
        self.annulus_fluid.fluid_type = "gas"

        # Инициализация класса для расчета затрубного пространства
        if "casing" in pipe_data and "tubing" in pipe_data:
            self.annulus = ann.Annulus(
                fluid=self.annulus_fluid,
                bottom_depth=self.gl_system.h_mes_work,
                ambient_temperature_distribution=self.amb_temp_dist,
                d_casing=pipe_data["casing"]["d"],
                d_tubing=pipe_data["tubing"]["d"],
                s_wall=self.tubing.s_wall,
                roughness=pipe_data["casing"]["roughness"],
                trajectory=self.well_trajectory,
            )
        else:
            self.annulus = None

        # Инициализация класса для расчета штуцера на газовой линии
        if equipment_data is not None and "ann_choke" in equipment_data:
            equipment_data["ann_choke"].update(
                {"h_mes": 0, "fluid": self.annulus_fluid, "d_up": self.casing.d0}
            )
            self.ann_choke = chk.Choke(**equipment_data["ann_choke"])
        else:
            self.ann_choke = None

        self.tubing_upper_point = None
        self.tubing_below_point = None

        self.__output_objects = dict()
        self.__ann_output_objects = dict()

    def _reinit(self, wct, q_liq):
        """
        Сброс флюида и пересохранение объекта в других объектах

        :param wct: обводненность, д.ед.
        :param q_liq: дебит жидкости, м/c
        :return:
        """
        super()._reinit(wct, q_liq)
        self.tubing_upper_point = None
        self.tubing_below_point = None

    def __make_nodes(self) -> list:
        """
        Создание распределений ключевых узлов

        :return:
        """
        nodes_cas = [None for _ in self.casing.distributions["depth"]]
        nodes_cas[-1] = "Верхние дыры перфорации"

        if self.tubing_below_point is None:
            nodes_tub = [None for _ in self.tubing_upper_point.distributions["depth"]]
            nodes_tub[0] = "Буфер"
            nodes_tub[-1] = "Башмак НКТ"
            nodes_cas = nodes_tub + nodes_cas
        else:
            nodes_tub_upper = [
                None for _ in self.tubing_upper_point.distributions["depth"]
            ]
            nodes_tub_upper[0] = "Буфер"
            nodes_tub_upper[-1] = "Рабочий газлифтный клапан"
            nodes_tub_below = [
                None for _ in self.tubing_below_point.distributions["depth"]
            ]
            nodes_tub_below[-1] = "Башмак НКТ"
            nodes_cas = nodes_tub_upper + nodes_tub_below + nodes_cas

        if self.choke and "depth" in self.choke.distributions:
            nodes_ch = [None for _ in self.choke.distributions["depth"]]
            nodes_ch[0] = "Линия"
            nodes_cas = nodes_ch + nodes_cas

        return nodes_cas

    def __make_nodes_annulus(self) -> list:
        """
        Создание распределений ключевых узлов

        :return:
        """
        nodes_ann = [None for _ in self.annulus.distributions["depth"]]
        nodes_ann[-1] = "Рабочий газлифтный клапан"
        nodes_ann[0] = "Затруб"

        if self.ann_choke and "depth" in self.ann_choke.distributions:
            nodes_ch = [None for _ in self.ann_choke.distributions["depth"]]
            nodes_ch[0] = "Газовая линия"
            nodes_ann = nodes_ch + nodes_ann

        return nodes_ann

    def calc_pwf_pfl(
        self,
        p_fl: float,
        q_liq: float,
        wct: float,
        p_wh: Optional[float] = None,
        p_ann: Optional[float] = None,
        hydr_corr_type: Optional[str] = None,
        q_gas_inj: Optional[float] = None,
        p_gas_inj: Optional[float] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_choke: Optional[Union[float, dict]] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        recalc_pb: bool = False,
        calc_curve: bool = False,
    ) -> list:
        """
        Расчет забойного давления по линейному с учетом всех гидравлических элементов

        Parameters
        ----------
        :param p_fl: линейное давление, Па абс.
        :param q_liq: дебит жидкости, ст. м3/с
        :param wct: обводненность, доли ед.
        :param p_wh: буферное давление, Па абс.
        :param p_ann: затрубное давление, Па абс.
        :param hydr_corr_type: тип гидравлической корреляции
        :param q_gas_inj: закачка газлифтного газа, ст. м3/с
        :param p_gas_inj: давление закачки газлифтного газа, Па
        :param friction_factor: к-т адаптации КРД на трение, если не задан берется
         из атрибутов трубы
        :param grav_holdup_factor: к-т адаптации КРД на гравитацию/holdup, если не задан берется
         из атрибутов трубы
        :param c_choke: адаптационный коэффициент штуцера \
        Задается в виде числа как коэффициент калибровки, либо как словарь {"const": value}, \
        где value - постоянный перепад, который будет использоваться как перепад между буферным и
        линейным давлением
        :param c_ann_choke: адаптационный коэффициент штуцера на газовой линии \
        Задается в виде числа как коэффициент калибровки, либо как словарь {"const": value}, \
        где value - постоянный перепад, который будет использоваться как перепад между затрубным
        и давлением закачки гл.г.
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг для расчета дополнительных распределений параметров
        :param heat_balance: опция учета теплопотерь
        :param recalc_pb: опция пересчета давления насыщения выше точки ввода газа
        :param calc_curve: флаг для расчета адаптации на тек.замеры с использованием кривых

        :return: давление закачки газлифтного газа, Па
        :return: температура закачки газлифтного газа, К
        :return: забойное давление, Па
        :return: давление на выходе из клапана (давление в НКТ на глубине спуска клапана), Па
        :return: температура на выходе из клапана (температура в НКТ на глубине спуска клапана), К
        :return: статус расчёта:
                 0 - расчет успешный;
                 1 - достигнуто минимальное давление, невозможно рассчитать линейное давление;
                 -1 - ошибка интегрирования
        :return: давление на входе в клапан (давление в затрубе на глубине спуска клапана), Па
        :return: температура на входе в клапана (температура в затрубе на глубине спуска клапана), К
        :return: закачка газлифтного газа, ст. м3/с
        """
        self.__output_objects = {"params": ["p", "t", "depth"]}
        self.__ann_output_objects = {"params": ["p", "t", "depth"]}

        if output_params:
            self.__output_objects["params"] += const.DISTRS
            self.__ann_output_objects["params"] += const.DISTRS

        if self.choke:
            self.choke.fluid = deepcopy(self.fluid)
            # 1.1 Адаптация штуцера в случае наличия буферного давления и отсутствия коэффициента
            # штуцера
            if p_wh is not None and q_gas_inj is not None and c_choke is None:
                self.choke.fluid.q_gas_free = q_gas_inj
                t_fl = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()
                c_choke = com.adapt_choke(self.choke, p_fl, p_wh, t_fl, q_liq, wct)

        if self.ann_choke:
            self.ann_choke.fluid = deepcopy(self.annulus_fluid)
            # 1.2 Адаптация штуцера на газовой линии в случае наличия затрубного давления,
            # давления закачки гл/г, расхода гл/г  и отсутствия коэффициента штуцера
            if (
                p_ann is not None
                and p_gas_inj is not None
                and q_gas_inj is not None
                and c_ann_choke is None
            ):
                self.ann_choke.fluid.q_fluid = q_gas_inj
                t_ann = self.amb_temp_dist.calc_temp(self.casing.top_depth).item()
                c_ann_choke = com.adapt_choke(
                    self.ann_choke, p_ann, p_gas_inj, t_ann, q_gas_inj, 0
                )

        # 2. Итерационный расчет Рзаб путем минимизации ошибки Рбуф
        results = self.__calc_pwf(
            p_fl=p_fl,
            q_liq=q_liq,
            wct=wct,
            hydr_corr_type=hydr_corr_type,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            friction_factor=friction_factor,
            grav_holdup_factor=grav_holdup_factor,
            c_choke=c_choke,
            c_ann_choke=c_ann_choke,
            step_length=step_length,
            output_params=output_params,
            heat_balance=heat_balance,
            recalc_pb=recalc_pb,
            calc_curve=calc_curve,
        )

        # 3. Расчет давления на входе в клапан (в ЭК на глубине спуска клапана)
        p_cas_valve = self.gl_system.valve_working.calc_pt(
            p_mes=results[3],
            t_mes=results[4],
            flow_direction=1,
            q_gas=self.gl_system.q_inj,
            gamma_gas=self.fluid.gamma_gas,
        )

        # 4. Расчет затрубного давления
        self.annulus.fluid = deepcopy(self.annulus_fluid)
        self.annulus.fluid.q_fluid = self.gl_system.q_inj

        t_cas_valve = self.amb_temp_dist.calc_temp(self.annulus.bottom_depth).item()
        p_ann, t_ann, status = self.annulus.calc_pt(
            h_start="bottom",
            p_mes=p_cas_valve,
            flow_direction=1,
            q_liq=self.gl_system.q_inj,
            wct=0,
            t_mes=t_cas_valve,
            hydr_corr_type="gray",
            step_len=step_length,
            friction_factor=friction_factor,
            extra_output=output_params,
            heat_balance=heat_balance,
            grav_holdup_factor=grav_holdup_factor,
        )

        self.__ann_output_objects["annulus"] = self.annulus
        if status != 0:
            # Случай неуспешного расчета затрубного давления
            self._ann_extra_output = tls.make_unified_distributions(
                **self.__ann_output_objects
            )
            result = p_ann, t_ann, results[2], results[3], results[4], status
            return list(result)

        # 5. Расчет давления закачки газа
        if self.ann_choke:
            self.ann_choke.fluid = deepcopy(self.annulus_fluid)
            self.ann_choke.fluid.q_fluid = self.gl_system.q_inj

            if isinstance(c_ann_choke, dict) and "const" in c_ann_choke:
                p_gas_inj, t_gas_inj = p_ann + c_ann_choke["const"], t_ann
            else:
                p_gas_inj, t_gas_inj, *_ = self.ann_choke.calc_pt(
                    p_ann,
                    t_ann,
                    1,
                    self.gl_system.q_inj,
                    0,
                    None,
                    c_ann_choke,
                    extra_output=output_params,
                )
                self.__ann_output_objects["ann_choke"] = self.ann_choke
        else:
            p_gas_inj, t_gas_inj = p_ann, t_ann

        self._extra_output = tls.make_unified_distributions(**self.__output_objects)
        self._extra_output["nodes"] = self.__make_nodes()

        self._extra_output_annulus = tls.make_unified_distributions(
            **self.__ann_output_objects
        )
        self._extra_output_annulus["nodes"] = self.__make_nodes_annulus()

        results[0] = p_gas_inj
        results[1] = t_gas_inj
        results.append(p_cas_valve)
        results.append(t_cas_valve)
        results.append(self.gl_system.q_inj)

        return results

    def calc_pwh_pwf(
        self,
        p_wf: float,
        q_liq: float,
        wct: float,
        hydr_corr_type: Optional[str] = None,
        q_gas_inj: Optional[float] = None,
        p_gas_inj: Optional[float] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        recalc_pb: bool = False,
        calc_curve: bool = False,
    ) -> tuple:
        """
        Расчет буферного давления по забойному с учетом всех гидравлических элементов

        Parameters
        ----------
        :param p_wf: забойное давление, Па абс.
        :param q_liq: дебит жидкости, ст. м3/с
        :param wct: обводненность, доли ед.
        :param hydr_corr_type: тип гидравлической корреляции
        :param q_gas_inj: закачка газлифтного газа, ст. м3/с
        :param p_gas_inj: давление закачки газлифтного газа, Па
        :param friction_factor: к-т адаптации КРД на трение,
        если не задан берется из атрибутов трубы
        :param grav_holdup_factor: к-т адаптации КРД на гравитацию / holdup,
        если не задан берется из атрибутов трубы
        :param c_ann_choke: адаптационный коэффициент штуцера на газовой линии \
        Задается в виде числа как коэффициент калибровки, либо как словарь {"const": value}, \
        где value - постоянный перепад, который будет использоваться как перепад между затрубным
        и давлением закачки гл.г.
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг для расчета дополнительных распределений параметров
        :param heat_balance: опция учета теплопотерь
        :param recalc_pb: опция пересчета давления насыщения выше точки ввода газа
        :param calc_curve: флаг для расчета адаптации на тек.замеры с использованием кривых

        :return: буферное давление, Па
        :return: температура на буфере, К
        :return: забойное давление, Па
        :return: давление на выходе из клапана (давление в НКТ на глубине спуска клапана), Па
        :return: температура на выходе из клапана (температура в НКТ на глубине спуска клапана), К
        :return: статус расчёта:
                 0 - расчет успешный;
                 1 - достигнуто минимальное давление, невозможно рассчитать линейное давление;
                 -1 - ошибка интегрирования
        """
        if not self.__output_objects:
            self.__output_objects = {"params": ["p", "t", "depth"]}
            if output_params:
                self.__output_objects["params"] += const.DISTRS

        if not self.__ann_output_objects:
            self.__ann_output_objects = {"params": ["p", "t", "depth"]}
            if output_params:
                self.__ann_output_objects["params"] += const.DISTRS

        # Сброс флюида и пересохранение объекта в других объектах
        self._reinit(wct, q_liq)
        self.tubing.fluid = deepcopy(self.fluid)
        self.casing.fluid = deepcopy(self.fluid)

        # Фонтан в случае отсутствия расхода
        if q_gas_inj is not None:
            self.gl_system.q_inj = q_gas_inj
        else:
            self.gl_system.q_inj = 0

        # 1.  Расчет распределения давления по ЭК от забоя до глубины спуска НКТ
        t_wf = self.amb_temp_dist.calc_temp(self.casing.bottom_depth).item()
        p_in, t_in, status = self.casing.calc_pt(
            h_start="bottom",
            p_mes=p_wf,
            flow_direction=-1,
            q_liq=q_liq,
            wct=wct,
            t_mes=t_wf,
            hydr_corr_type=hydr_corr_type,
            step_len=step_length,
            friction_factor=friction_factor,
            grav_holdup_factor=grav_holdup_factor,
            extra_output=output_params,
            heat_balance=heat_balance,
        )

        self.__output_objects["casing"] = self.casing
        if status != 0:
            # Случай неуспешного расчета до приема
            self._extra_output = tls.make_unified_distributions(**self.__output_objects)
            return p_in, t_in, p_wf, None, None, status

        # 2. Расчет естественной сепарации и модификация свойств флюида после сепарации
        self.fluid.calc_flow(p_in, t_in)

        if self.gl_system.h_mes_work > self.tubing.bottom_depth:
            raise exc.GlValveError(
                f"Глубина рабочего клапана = {self.gl_system.h_mes_work} м больше "
                f"глубины НКТ = {self.tubing.bottom_depth} м.",
                self.gl_system.h_mes_work,
            )
        if self.gl_system.h_mes_work == self.tubing.bottom_depth:

            self.tubing_upper_point = deepcopy(self.tubing)
            fluid_upper_point = deepcopy(self.fluid)
            self.__output_objects["tubings"] = []

            p_tub_valve, t_tub_valve = p_in, t_in
        else:
            self.tubing_below_point = deepcopy(self.tubing)
            self.tubing_below_point.top_depth = self.gl_system.h_mes_work

            self.tubing_upper_point = deepcopy(self.tubing)
            self.tubing_upper_point.bottom_depth = self.gl_system.h_mes_work
            fluid_upper_point = deepcopy(self.fluid)

            # 3. Расчет распределения давления по НКТ ниже клапана
            p_tub_valve, t_tub_valve, status = self.tubing_below_point.calc_pt(
                h_start="bottom",
                p_mes=p_in,
                flow_direction=-1,
                q_liq=q_liq,
                wct=wct,
                t_mes=t_in,
                hydr_corr_type=hydr_corr_type,
                step_len=step_length,
                friction_factor=friction_factor,
                grav_holdup_factor=grav_holdup_factor,
                extra_output=output_params,
                heat_balance=heat_balance,
            )

            self.__output_objects["tubings"] = [self.tubing_below_point]
            if status != 0:
                # Случай неуспешного расчета до клапана
                self._extra_output = tls.make_unified_distributions(
                    **self.__output_objects
                )
                return p_tub_valve, t_tub_valve, p_wf, p_tub_valve, t_tub_valve, status

        # 3.1. Определение расхода г/г при известном давлении закачки
        if q_gas_inj is None and p_gas_inj is not None:
            self.gl_system.q_inj = self.__calc_q_gas_inj(
                p_gas_inj,
                p_tub_valve,
                t_tub_valve,
                hydr_corr_type,
                friction_factor,
                grav_holdup_factor,
                c_ann_choke,
                step_length,
                output_params,
                heat_balance,
                calc_curve,
            )[2]
        if recalc_pb:
            # Расчет нового газового фактора
            q_oil_st = (1 - self.fluid.wct) * self.fluid.q_fluid
            q_gas_st = self.fluid.rp * q_oil_st
            rp_new = (q_gas_st + self.gl_system.q_inj) / q_oil_st

            fluid_upper_point.rp = rp_new
            fluid_upper_point.pvt_model.rp = rp_new
        else:
            # Расчет с добавлением дебита свободного газа
            fluid_upper_point.q_gas_free = self.gl_system.q_inj

        self.tubing_upper_point.fluid = fluid_upper_point
        if self.choke is not None:
            self.choke.fluid = self.tubing_upper_point.fluid

        # 4. Расчет распределения давления по НКТ выше клапана
        p_wh, t_wh, status = self.tubing_upper_point.calc_pt(
            h_start="bottom",
            p_mes=p_tub_valve,
            flow_direction=-1,
            q_liq=q_liq,
            wct=wct,
            t_mes=t_tub_valve,
            hydr_corr_type=hydr_corr_type,
            step_len=step_length,
            friction_factor=friction_factor,
            grav_holdup_factor=grav_holdup_factor,
            extra_output=output_params,
            heat_balance=heat_balance,
        )

        self.__output_objects["tubings"].insert(0, self.tubing_upper_point)
        if status != 0:
            # Случай неуспешного расчета до буфера
            self._extra_output = tls.make_unified_distributions(**self.__output_objects)
            return p_wh, t_wh, p_wf, p_tub_valve, t_tub_valve, status

        self._extra_output = tls.make_unified_distributions(**self.__output_objects)
        self._extra_output_annulus = tls.make_unified_distributions(
            **self.__ann_output_objects
        )

        return p_wh, t_wh, p_wf, p_tub_valve, t_tub_valve, status

    def __calc_pwf(
        self,
        p_fl: float,
        q_liq: float,
        wct: float,
        hydr_corr_type: Optional[str] = None,
        q_gas_inj: Optional[float] = None,
        p_gas_inj: Optional[float] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_choke: Optional[Union[float, dict]] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        recalc_pb: bool = False,
        calc_curve: bool = False,
    ) -> list:
        """
        Функция расчета забойного давления итеративно по буферному давлению
        """
        if calc_curve:
            # Расчет забойного давления методом кривых

            pwf_array = np.linspace(101325, 500 * 101325, 70)
            pwh_array = np.zeros((len(pwf_array)))
            twh_array = np.zeros((len(pwf_array)))
            q_gas_inj_array = np.zeros((len(pwf_array)))
            p_tub_valve_array = np.zeros((len(pwf_array)))
            t_tub_valve_array = np.zeros((len(pwf_array)))
            step = 0

            # Расчет точек буферного далвения для заданных забойных
            for pwf_input in pwf_array:
                try:
                    result_pwh = self.calc_pwh_pwf(
                        p_wf=pwf_input,
                        q_liq=q_liq,
                        wct=wct,
                        hydr_corr_type=hydr_corr_type,
                        q_gas_inj=q_gas_inj,
                        p_gas_inj=p_gas_inj,
                        friction_factor=friction_factor,
                        grav_holdup_factor=grav_holdup_factor,
                        c_ann_choke=c_ann_choke,
                        step_length=step_length,
                        output_params=output_params,
                        heat_balance=heat_balance,
                        recalc_pb=recalc_pb,
                        calc_curve=calc_curve,
                    )
                    pwh_array[step] = result_pwh[0]
                    twh_array[step] = result_pwh[1]
                    q_gas_inj_array[step] = self.gl_system.q_inj
                    if result_pwh[3] is None:
                        p_tub_valve_array[step] = 0
                    else:
                        p_tub_valve_array[step] = result_pwh[3]
                    t_tub_valve_array[step] = result_pwh[4]

                except ValueError:
                    pass

                step += 1

            # Расчет фактического буферного давления по заданному линейному
            t_fl = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()
            if self.choke:
                self.choke.fluid = deepcopy(self.fluid)
                if isinstance(c_choke, dict) and "const" in c_choke:
                    p_wh, t_wh = p_fl + c_choke["const"], t_fl
                else:
                    p_wh, t_wh, *_ = self.choke.calc_pt(
                        p_fl,
                        t_fl,
                        1,
                        q_liq,
                        wct,
                        None,
                        c_choke,
                        extra_output=output_params,
                    )
                    self.__output_objects["choke"] = self.choke
            else:
                p_wh, t_wh = p_fl, t_fl

            # Запись точек для кривых Рбуф(Рзаб)
            pwf_pwh_line = shp.LineString(np.column_stack((pwf_array, pwh_array)))
            pwh_line = shp.LineString(
                np.column_stack(([101325, 500 * 101325], [p_wh, p_wh]))
            )
            # Поиск точек пересечения
            intersection = pwf_pwh_line.intersection(pwh_line)

            if intersection.geom_type == "MultiPoint":
                p_wf_result = []
                q_gas_inj_result = []
                for i in range(len(intersection)):
                    p_wf_result.append(intersection[i].x)

                    interp_func_qg = interp.interp1d(
                        pwf_array,
                        q_gas_inj_array,
                        kind="linear",
                        fill_value="extrapolate",
                    )
                    q_gas_inj_result.append(interp_func_qg(p_wf_result[i]).item())

                self.gl_system.q_inj = max(q_gas_inj_result)
                p_wf = p_wf_result[q_gas_inj_result.index(self.gl_system.q_inj)]
            else:
                p_wf = intersection.x

                interp_func_qg = interp.interp1d(
                    pwf_array, q_gas_inj_array, kind="linear", fill_value="extrapolate"
                )
                q_gas_inj = interp_func_qg(p_wf).item()
                self.gl_system.q_inj = q_gas_inj

            interp_func_pwh = interp.interp1d(
                pwf_array, pwh_array, kind="linear", fill_value="extrapolate"
            )
            p_wh = interp_func_pwh(p_wf).item()
            interp_func_twh = interp.interp1d(
                pwf_array, twh_array, kind="linear", fill_value="extrapolate"
            )
            t_wh = interp_func_twh(p_wf).item()

            interp_func_pt = interp.interp1d(
                pwf_array, p_tub_valve_array, kind="linear", fill_value="extrapolate"
            )
            p_tub_valve = interp_func_pt(p_wf).item()
            interp_func_tt = interp.interp1d(
                pwf_array, t_tub_valve_array, kind="linear", fill_value="extrapolate"
            )
            t_tub_valve = interp_func_tt(p_wf).item()

            return [p_wh, t_wh, p_wf, p_tub_valve, t_tub_valve, 0]
        else:
            # Расчет забойного давления с помощью оптимизатора
            try:
                p_wf = opt.brenth(
                    self.__calc_pwh_error,
                    a=101325,
                    b=const.P_UP_LIMIT,
                    args=(
                        p_fl,
                        q_liq,
                        wct,
                        hydr_corr_type,
                        q_gas_inj,
                        p_gas_inj,
                        friction_factor,
                        grav_holdup_factor,
                        c_choke,
                        c_ann_choke,
                        step_length,
                        output_params,
                        heat_balance,
                        recalc_pb,
                    ),
                    xtol=10000,
                )
            except ValueError:
                p_wf = opt.minimize_scalar(
                    self.__calc_pwh_error_abs,
                    method="bounded",
                    bounds=(101325, const.P_UP_LIMIT),
                    args=(
                        p_fl,
                        q_liq,
                        wct,
                        hydr_corr_type,
                        q_gas_inj,
                        p_gas_inj,
                        friction_factor,
                        grav_holdup_factor,
                        c_choke,
                        c_ann_choke,
                        step_length,
                        output_params,
                        heat_balance,
                        recalc_pb,
                    ),
                    options={"xatol": 10000},
                )
                p_wf = p_wf.x

            return list(
                self.calc_pwh_pwf(
                    p_wf=p_wf,
                    q_liq=q_liq,
                    wct=wct,
                    hydr_corr_type=hydr_corr_type,
                    q_gas_inj=q_gas_inj,
                    p_gas_inj=p_gas_inj,
                    friction_factor=friction_factor,
                    grav_holdup_factor=grav_holdup_factor,
                    c_ann_choke=c_ann_choke,
                    step_length=step_length,
                    output_params=output_params,
                    heat_balance=heat_balance,
                    recalc_pb=recalc_pb,
                )
            )

    def __calc_pwh_error_abs(
        self,
        p_wf: float,
        p_fl: float,
        q_liq: float,
        wct: float,
        hydr_corr_type: Optional[str] = None,
        q_gas_inj: Optional[float] = None,
        p_gas_inj: Optional[float] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_choke: Optional[Union[float, dict]] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        recalc_pb: bool = False,
    ) -> float:
        """
        Расчет модуля ошибки в буферном давлении
        """
        return abs(
            self.__calc_pwh_error(
                p_wf=p_wf,
                p_fl=p_fl,
                q_liq=q_liq,
                wct=wct,
                hydr_corr_type=hydr_corr_type,
                q_gas_inj=q_gas_inj,
                p_gas_inj=p_gas_inj,
                friction_factor=friction_factor,
                grav_holdup_factor=grav_holdup_factor,
                c_choke=c_choke,
                c_ann_choke=c_ann_choke,
                step_length=step_length,
                output_params=output_params,
                heat_balance=heat_balance,
                recalc_pb=recalc_pb,
            )
        )

    def __calc_pwh_error(
        self,
        p_wf: float,
        p_fl: float,
        q_liq: float,
        wct: float,
        hydr_corr_type: Optional[str] = None,
        q_gas_inj: Optional[float] = None,
        p_gas_inj: Optional[float] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_choke: Optional[Union[float, dict]] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        recalc_pb: bool = False,
    ) -> float:
        """
        Расчет ошибки в буферном давлении
        """
        calc_pwh = self.calc_pwh_pwf(
            p_wf=p_wf,
            q_liq=q_liq,
            wct=wct,
            hydr_corr_type=hydr_corr_type,
            q_gas_inj=q_gas_inj,
            p_gas_inj=p_gas_inj,
            friction_factor=friction_factor,
            grav_holdup_factor=grav_holdup_factor,
            c_ann_choke=c_ann_choke,
            step_length=step_length,
            output_params=output_params,
            heat_balance=heat_balance,
            recalc_pb=recalc_pb,
        )[0]

        # Расчет фактического буферного давления по заданному линейному
        t_fl = self.amb_temp_dist.calc_temp(self.tubing.top_depth).item()
        if self.choke:
            if isinstance(c_choke, dict) and "const" in c_choke:
                p_wh, t_wh = p_fl + c_choke["const"], t_fl
            else:
                p_wh, t_wh, *_ = self.choke.calc_pt(
                    p_fl, t_fl, 1, q_liq, wct, None, c_choke, extra_output=output_params
                )
                self.__output_objects["choke"] = self.choke
        else:
            p_wh, t_wh = p_fl, t_fl

        return p_wh - calc_pwh

    def __calc_q_gas_inj(
        self,
        p_gas_inj: float,
        p_tub_valve: float,
        t_tub_valve: float,
        hydr_corr_type: Optional[str] = None,
        friction_factor: Optional[float] = None,
        grav_holdup_factor: Optional[float] = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: Optional[float] = 10,
        output_params: bool = False,
        heat_balance: bool = False,
        calc_curve: bool = False,
    ) -> list:
        """
        Функция расчета расхода газлифтного газа итеративно по давлению в газовой линии
        """
        if calc_curve:
            # Расчет расхода газлифтного газа методом кривых

            q_gas_inj_array = np.linspace(0.000001, 6.554825, 50)
            p_gas_inj_array = np.zeros((len(q_gas_inj_array)))
            t_gas_inj_array = np.zeros((len(q_gas_inj_array)))
            p_cas_array = np.zeros((len(q_gas_inj_array)))
            t_cas_array = np.zeros((len(q_gas_inj_array)))
            p_ann_array = np.zeros((len(q_gas_inj_array)))
            t_ann_array = np.zeros((len(q_gas_inj_array)))
            step = 0

            # Расчет точек далвения закачки гл. газа для заданных расходов гл. газа
            for q_gas_inj_input in q_gas_inj_array:
                try:
                    calc_results = self.calc_p_gas_inj_q_gas_inj(
                        q_gas_inj=q_gas_inj_input,
                        p_tub_valve=p_tub_valve,
                        t_tub_valve=t_tub_valve,
                        hydr_corr_type=hydr_corr_type,
                        friction_factor=friction_factor,
                        grav_holdup_factor=grav_holdup_factor,
                        c_ann_choke=c_ann_choke,
                        step_length=step_length,
                        output_params=output_params,
                        heat_balance=heat_balance,
                        calc_curve=calc_curve,
                    )
                    p_gas_inj_array[step] = calc_results[0]
                    t_gas_inj_array[step] = calc_results[1]
                    p_cas_array[step] = calc_results[3]
                    t_cas_array[step] = calc_results[4]
                    p_ann_array[step] = calc_results[5]
                    t_ann_array[step] = calc_results[6]
                except ValueError:
                    pass

                step += 1

            # Поиск точки пересечения
            interp_func_qg = interp.interp1d(
                p_gas_inj_array,
                q_gas_inj_array,
                kind="linear",
                fill_value="extrapolate",
            )
            q_gas_inj = interp_func_qg(p_gas_inj).item()
            interp_func_tg = interp.interp1d(
                p_gas_inj_array,
                t_gas_inj_array,
                kind="linear",
                fill_value="extrapolate",
            )
            t_gas_inj = interp_func_tg(p_gas_inj).item()

            interp_func_pc = interp.interp1d(
                p_gas_inj_array, p_cas_array, kind="linear", fill_value="extrapolate"
            )
            p_cas_valve = interp_func_pc(p_gas_inj).item()
            interp_func_tc = interp.interp1d(
                p_gas_inj_array, t_cas_array, kind="linear", fill_value="extrapolate"
            )
            t_cas_valve = interp_func_tc(p_gas_inj).item()

            interp_func_pa = interp.interp1d(
                p_gas_inj_array, p_ann_array, kind="linear", fill_value="extrapolate"
            )
            p_ann = interp_func_pa(p_gas_inj).item()
            interp_func_ta = interp.interp1d(
                p_gas_inj_array, t_ann_array, kind="linear", fill_value="extrapolate"
            )
            t_ann = interp_func_ta(p_gas_inj).item()

            if p_tub_valve > p_cas_valve:
                q_gas_inj = 0

            return [
                p_gas_inj,
                t_gas_inj,
                q_gas_inj,
                p_cas_valve,
                t_cas_valve,
                p_ann,
                t_ann,
                0,
            ]
        else:
            # Расчет расхода газлифтного газа с помощью оптимизатора
            try:
                q_gas_inj = opt.brenth(
                    self.__calc_p_gas_inj_error,
                    a=0.000001,
                    b=6.554825,
                    args=(
                        p_gas_inj,
                        p_tub_valve,
                        t_tub_valve,
                        hydr_corr_type,
                        friction_factor,
                        grav_holdup_factor,
                        c_ann_choke,
                        step_length,
                        output_params,
                        heat_balance,
                    ),
                    xtol=0.00001,
                )
                convergence = 1
            except ValueError:
                q_gas_inj = opt.minimize_scalar(
                    self.__calc_p_gas_inj_error_abs,
                    method="bounded",
                    bounds=(0.000001, 6.554825),
                    args=(
                        p_gas_inj,
                        p_tub_valve,
                        t_tub_valve,
                        hydr_corr_type,
                        friction_factor,
                        grav_holdup_factor,
                        c_ann_choke,
                        step_length,
                        output_params,
                        heat_balance,
                    ),
                    options={"xatol": 0.00001},
                )
                q_gas_inj = q_gas_inj.x
                convergence = 0

            results = list(
                self.calc_p_gas_inj_q_gas_inj(
                    q_gas_inj=q_gas_inj,
                    p_tub_valve=p_tub_valve,
                    t_tub_valve=t_tub_valve,
                    hydr_corr_type=hydr_corr_type,
                    friction_factor=friction_factor,
                    grav_holdup_factor=grav_holdup_factor,
                    c_ann_choke=c_ann_choke,
                    step_length=step_length,
                    output_params=output_params,
                    heat_balance=heat_balance,
                )
            )
            results[-1] = convergence

            return results

    def __calc_p_gas_inj_error_abs(
        self,
        q_gas_inj: float,
        p_gas_inj: float,
        p_tub_valve: float,
        t_tub_valve: float,
        hydr_corr_type: str = None,
        friction_factor: float = None,
        grav_holdup_factor: float = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: float = None,
        output_params: bool = False,
        heat_balance: bool = False,
    ) -> float:
        """
        Расчет модуля ошибки в давлении газовой линии
        """
        return abs(
            self.__calc_p_gas_inj_error(
                q_gas_inj,
                p_gas_inj,
                p_tub_valve,
                t_tub_valve,
                hydr_corr_type,
                friction_factor,
                grav_holdup_factor,
                c_ann_choke,
                step_length,
                output_params,
                heat_balance,
            )
        )

    def __calc_p_gas_inj_error(
        self,
        q_gas_inj: float,
        p_gas_inj: float,
        p_tub_valve: float,
        t_tub_valve: float,
        hydr_corr_type: str = None,
        friction_factor: float = None,
        grav_holdup_factor: float = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: float = None,
        output_params: bool = False,
        heat_balance: bool = False,
    ) -> float:
        """
        Расчет ошибки в давлении газовой линии
        """
        calc_pgas = self.calc_p_gas_inj_q_gas_inj(
            q_gas_inj=q_gas_inj,
            p_tub_valve=p_tub_valve,
            t_tub_valve=t_tub_valve,
            hydr_corr_type=hydr_corr_type,
            friction_factor=friction_factor,
            grav_holdup_factor=grav_holdup_factor,
            c_ann_choke=c_ann_choke,
            step_length=step_length,
            output_params=output_params,
            heat_balance=heat_balance,
        )[0]

        return p_gas_inj - calc_pgas

    def calc_p_gas_inj_q_gas_inj(
        self,
        q_gas_inj: float,
        p_tub_valve: float,
        t_tub_valve: float,
        hydr_corr_type: str = None,
        friction_factor: float = None,
        grav_holdup_factor: float = None,
        c_ann_choke: Optional[Union[float, dict]] = None,
        step_length: float = None,
        output_params: bool = False,
        heat_balance: bool = False,
        calc_curve=False,
    ) -> tuple:
        """
        Метод расчета давления в газовой линии по известному расходу газлифтного газа

        Parameters
        ----------
        :param q_gas_inj: расход газлифтного газа, ст. м3/с
        :param p_tub_valve: давление на выходе из клапана, Па
        :param t_tub_valve: температура на выходе из клапана, К
        :param hydr_corr_type: тип гидравлической корреляции
        :param friction_factor: к-т адаптации КРД на трение, если не задан берется из атрибутов
        трубы
        :param grav_holdup_factor: к-т адаптации КРД на гравитацию / holdup, если не задан
        берется из атрибутов трубы
        :param c_ann_choke: адаптационный коэффициент штуцера на газовой линии \
        Задается в виде числа как коэффициент калибровки, либо как словарь {"const": value}, \
        где value - постоянный перепад, который будет использоваться как перепад между затрубным
        и давлением закачки гл.г.
        :param step_length: длина шага интегрирования, м
        :param output_params: флаг для расчета дополнительных распределений параметров
        :param heat_balance: опция расчета теплопотерь
        :param calc_curve: флаг для расчета адаптации на тек.замеры с использованием кривых

        :return: давление закачки г/г, Па
        :return: температура закачки г/г, К
        :return: расход г/г, м3/с
        :return: давление на входе в клапан (давление в затрубе на глубине спуска клапана), Па
        :return: температура на входе в клапан (температура в затрубе на глубине спуска клапана), К
        :return: затрубное давление, Па
        :return: затрубная температура, К
        :return: статус расчёта:
                 0 - расчет успешный;
                 1 - достигнуто минимальное давление, невозможно рассчитать давление закачки г/г;
                 -1 - ошибка интегрирования
        -------
        """

        # 1. Расчет давления на входе в клапан
        p_cas_valve = self.gl_system.valve_working.calc_pt(
            p_mes=p_tub_valve,
            t_mes=t_tub_valve,
            flow_direction=1,
            q_gas=q_gas_inj,
            gamma_gas=self.fluid.gamma_gas,
            calc_curve=calc_curve,
        )
        if output_params:
            fluid_valve = deepcopy(self.fluid)
            self.gl_system.valve_working.distributions.update(
                tls.make_output_attrs(
                    fluid_valve,
                    self.gl_system.valve_working.distributions["p"],
                    self.gl_system.valve_working.distributions["t"],
                )
            )

            ann_fluid_valve = deepcopy(self.annulus_fluid)
            self.gl_system.valve_working.distributions_annulus.update(
                tls.make_output_attrs(
                    ann_fluid_valve,
                    self.gl_system.valve_working.distributions["p"],
                    self.gl_system.valve_working.distributions["t"],
                )
            )

        self.__ann_output_objects["gl_valves"] = self.gl_system.valve_working
        self.__output_objects["gl_valves"] = self.gl_system.valve_working

        # 2. Расчет затрубного давления
        self.annulus.fluid = deepcopy(self.annulus_fluid)
        self.annulus.fluid.q_fluid = q_gas_inj

        t_cas_valve = self.amb_temp_dist.calc_temp(self.annulus.bottom_depth).item()
        p_ann, t_ann, status = self.annulus.calc_pt(
            h_start="bottom",
            p_mes=p_cas_valve,
            flow_direction=1,
            q_liq=q_gas_inj,
            wct=0,
            t_mes=t_cas_valve,
            hydr_corr_type="gray",
            step_len=step_length,
            friction_factor=friction_factor,
            extra_output=output_params,
            heat_balance=heat_balance,
            grav_holdup_factor=grav_holdup_factor,
        )

        self.__ann_output_objects["annulus"] = self.annulus
        if status != 0:
            # Случай неуспешного расчета затрубного давления
            return (
                p_ann,
                t_ann,
                q_gas_inj,
                p_cas_valve,
                t_cas_valve,
                p_ann,
                t_ann,
                status,
            )

        # 3. Расчет давления закачки гл газа
        if self.ann_choke:
            self.ann_choke.fluid = deepcopy(self.annulus_fluid)
            self.ann_choke.fluid.q_fluid = q_gas_inj

            if isinstance(c_ann_choke, dict) and "const" in c_ann_choke:
                p_gas_inj, t_gas_inj = p_ann + c_ann_choke["const"], t_ann
            else:
                self.__ann_output_objects["ann_choke"] = self.ann_choke
                p_gas_inj, t_gas_inj, *_ = self.ann_choke.calc_pt(
                    p_ann,
                    t_ann,
                    1,
                    q_gas_inj,
                    0,
                    None,
                    c_ann_choke,
                    extra_output=output_params,
                )
        else:
            p_gas_inj, t_gas_inj = p_ann, t_ann

        return (
            p_gas_inj,
            t_gas_inj,
            q_gas_inj,
            p_cas_valve,
            t_cas_valve,
            p_ann,
            t_ann,
            status,
        )
