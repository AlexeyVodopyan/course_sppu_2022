"""
Модуль для дополнительного расчетного функционала
"""

from typing import Tuple, Optional, Union
from copy import deepcopy

import pandas as pd
import scipy.optimize as opt

import unifloc.common.trajectory as traj
import unifloc.common.ambient_temperature_distribution as amb
import unifloc.equipment.choke as ch
import unifloc.equipment.esp_electric_system as ees
import unifloc.equipment.natural_separation as nat
import unifloc.equipment.separator as sep
import unifloc.pipe.pipeline as pipe
import unifloc.pvt.fluid_flow as fl
import unifloc.tools.exceptions as exc


class PipePressSep:
    """
    Класс для расчета давления и доли газа на конце трубы при заданном дебите и давлении на другом
    """

    def __init__(
            self,
            fluid_data: dict,
            pipe_data: dict,
            equipment_data: dict,
            well_trajectory_data: dict,
            ambient_temperature_data: dict,
    ):
        """
            Parameters
            ----------
            :param fluid_data: словарь с исходными данными для создания флюида
            :param pipe_data: словарь с исходными данными для создания трубы
            :param equipment_data: словарь с исходными данными для создания пакера и сепаратора
            :param well_trajectory_data: словарь с исходными данными для создания инклинометрии трубы
            :param ambient_temperature_data: словарь с распределением температуры породы по MD

            Со структурой словарей можно ознакомиться в примере ниже

            Examples:
            --------
        >>> # Пример на основе расчета потенциала ОПТ
        >>> from unifloc.tools.common_calculations import PipePressSep
        >>>
        >>> import pandas as pd
        >>>
        >>> fluid_data = {
        ...     "q_fluid": 100 / 86400,
        ...     "wct": 0,
        ...     "pvt_model_data": {
        ...         "black_oil": {
        ...             "gamma_gas": 0.7,
        ...             "gamma_wat": 1,
        ...             "gamma_oil": 0.8,
        ...             "rp": 50,
        ...             "rsb": {"value": 50, "p": 10000000, "t": 303.15},
        ...             "muob": {"value": 0.5, "p": 10000000, "t": 303.15},
        ...             "bob": {"value": 1.5, "p": 10000000, "t": 303.15},
        ...             "table_model_data": None,
        ...             "use_table_model": False,
        ...         }
        ...     },
        ... }
        >>> d = {"MD": [0, 1000], "d": [0.06, 0.08]}
        >>> pipe_data = {"top_depth": 1400, "bottom_depth": 1800, "d": 0.146, "roughness": 0.0001}
        >>>
        >>> df = pd.DataFrame(columns=["MD", "TVD"], data=[[0, 0], [1400, 1200], [1800, 1542.85]])
        >>> well_trajectory_data = {"inclinometry": df}
        >>>
        >>> equipment_data = {"packer": True, "separator": 0.7}
        >>>
        >>> ambient_temperature_data = {"MD": [0, 1800], "T": [293.15, 303.15]}
        >>>
        >>> potential = PipePressSep(
        ...     fluid_data,
        ...     pipe_data,
        ...     equipment_data,
        ...     well_trajectory_data,
        ...     ambient_temperature_data,
        ... )
        >>>
        >>> q_liq = 150 / 86400
        >>> pin = 30 * 101325
        >>> h_esp = 1500
        >>> # Расчет забойного давления и доли газа
        >>> pwf, a_gas = potential.calc_pressure_and_sep(q_liq, pin, h_esp)
        >>>
        """

        # Инициализация класса для расчета флюида
        self.fluid = fl.FluidFlow(**fluid_data)

        # Проверка на пропущенные нули в инклинометрии
        if (
                isinstance(well_trajectory_data["inclinometry"], pd.DataFrame)
                and not (well_trajectory_data["inclinometry"].iloc[0] == [0, 0]).all()
        ):
            well_trajectory_data["inclinometry"] = pd.concat(
                [
                    pd.DataFrame({"MD": 0, "TVD": 0}, index=[0]),
                    well_trajectory_data["inclinometry"],
                ]
            ).reset_index(drop=True)
        elif isinstance(well_trajectory_data["inclinometry"], dict) and not (
                well_trajectory_data["inclinometry"]["MD"][0] == 0 and well_trajectory_data["inclinometry"]["TVD"][
            0] == 0
        ):
            well_trajectory_data["inclinometry"]["MD"].insert(0, 0)
            well_trajectory_data["inclinometry"]["TVD"].insert(0, 0)

        # Инициализация класса для расчета инклинометрии трубы
        well_trajectory = traj.Trajectory(**well_trajectory_data)

        # Инициализация класса для расчета температуры окружающей породы
        self.amb_temp_dist = amb.AmbientTemperatureDistribution(ambient_temperature_data)

        # Инициализация класса для расчета трубы
        pipe_data.update(
            {
                "fluid": self.fluid,
                "trajectory": well_trajectory,
                "ambient_temperature_distribution": self.amb_temp_dist,
            }
        )
        self.pipe = pipe.Pipeline(**pipe_data)

        # Инициализация класса для расчета сепаратора
        if equipment_data.get("separator") is not None:
            self.separator = sep.Separator(self.pipe.top_depth, equipment_data["separator"])
        else:
            self.separator = None

        # Инициализация класса для расчета естественной сепарации
        if equipment_data.get("packer") is not None and not equipment_data["packer"]:
            self.natural_sep = nat.NaturalSeparation(self.pipe.top_depth)
        else:
            self.natural_sep = None

    def calc_pressure_and_sep(
            self,
            q_liq: float,
            p_top: float,
            t_top: Optional[float] = None,
            h_top: Optional[float] = None,
            hydr_corr_type: str = "BeggsBrill",
            grav_holdup_factor: float = 1,
    ) -> Tuple[float, float]:

        """
        Функция для расчета давления на нижнем конце трубы и доли газа после сепарации на верхнем
        конце.

        Parameters
        ----------
        :param q_liq: дебит жидкости трубы, м3/с
        :param p_top: давление на верхнем конце трубы, Па изб.
        :param t_top: температура на глубине верхнего конца трубы, K
        :param h_top: измеренная глубина верхнего конца трубы, м
        :param hydr_corr_type: тип гидравлической корреляции
        :param grav_holdup_factor: коэффициент адаптации КРД на гравитацию/holdup, д.ед

        :return: давление на нижнем конце трубы, Па изб.
        :return: доля газа на верхнем конце трубы после сепарации, д.ед.
        """

        self.fluid.reinit()
        self.fluid.q_fluid = q_liq
        self.pipe.fluid = deepcopy(self.fluid)

        if h_top is None:
            h_top = self.pipe.top_depth

        # Если не задана температура на приеме, зададим ее равной пластовой
        if t_top is None:
            t_top = float(self.amb_temp_dist.calc_temp(h_top))

        # Расчет естественной сепарации
        if self.natural_sep is not None:
            # FIXME пока расчет коэффициента естественной сепарации не протестирован, задаем его
            #  равным 0.5
            k_sep_nat = 0.5
        else:
            k_sep_nat = 0

        # Расчет общей сепарацию
        if self.separator is not None:
            k_sep_gen = self.separator.calc_general_separation(k_sep_nat)
        else:
            k_sep_gen = k_sep_nat

        # Расчет модификации флюида
        self.fluid.modify(p_top, t_top, k_sep_gen)

        # Расчет свойств флюида после сепарации
        self.fluid.calc_flow(p_top, t_top)

        # Доля газа на приеме насоса после сепарации
        gas_fraction = self.fluid.qg / self.fluid.qm

        # Проверка, что глубина спуска насоса не превышает глубину ВДП
        if h_top < self.pipe.bottom_depth:
            # Расчет забойного давления
            self.pipe.top_depth = h_top
            p_bottom, _, _ = self.pipe.calc_pt(
                "top",
                p_top,
                1,
                q_liq,
                t_mes=t_top,
                hydr_corr_type=hydr_corr_type,
                grav_holdup_factor=grav_holdup_factor,
            )
        else:
            raise exc.UniflocPyError(
                f"Заданная глубина {h_top} м верхнего конца трубы"
                f"превышает глубину нижнего конца {self.pipe.bottom_depth} м."
                f" Задайте другую глубину"
            )

        return p_bottom, gas_fraction


def __adapt_func_choke(
        c_choke: float,
        choke: ch.Choke,
        p_out: float,
        p_in: float,
        t_out: float,
        q_liq: float,
        wct: float,
) -> float:
    """
    Функция адаптации штуцера

    :param c_choke: адаптационный коэффициент штуцера
    :param p_out: давление на выходе из штуцера, Па абс.
    :param choke: объект штуцера
    :param p_in: давление на входе в штуцер, Па абс.
    :param t_out: температура на выходе из штуцера, К
    :param q_liq: дебит жидкости, м3/с
    :param wct: обводненность, д. ед.

    :return ошибка в расчетном p_wh, Па
    """
    p_in_calc, *_ = choke.calc_pt(p_out, t_out, 1, q_liq, wct, None, c_choke)
    return p_in - p_in_calc


def __adapt_func_choke_abs(
        c_choke: float,
        choke: ch.Choke,
        p_out: float,
        p_in: float,
        t_out: float,
        q_liq: float,
        wct: float,
) -> float:
    """
    Функция адаптации штуцера

    :param c_choke: адаптационный коэффициент штуцера
    :param p_out: давление на выходе из штуцера, Па абс.
    :param choke: объект штуцера
    :param p_in: давление на входе в штуцер, Па абс.
    :param t_out: температура на выходе из штуцера, К
    :param q_liq: дебит жидкости, м3/с
    :param wct: обводненность, д. ед.

    :return модуль ошибки в расчетном p_wh, Па
    """
    return abs(__adapt_func_choke(c_choke, choke, p_out, p_in, t_out, q_liq, wct))


def adapt_choke(
        choke: ch.Choke,
        p_out: float,
        p_in: float,
        t_out: float,
        q_liq: float,
        wct: float
) -> Union[float, dict]:
    """
    Функция, адаптирующая штуцер и возвращающая адаптационный
    коэффициент штуцера

    :param choke: объект штуцера
    :param p_out: давление на выходе из штуцера, Па абс.
    :param p_in: давление на входе в штуцер, Па абс.
    :param t_out: температура на выходе из штуцера, К
    :param q_liq: дебит жидкости, м3/с
    :param wct: обводненность, д. ед.
    :return: адаптационный коэффициент штуцера
    """
    try:
        c_ch = opt.brentq(__adapt_func_choke, a=0.3, b=5, args=(choke, p_out, p_in, t_out, q_liq, wct), xtol=0.01)
    except ValueError:
        try:
            c_ch = opt.brentq(__adapt_func_choke, a=0.01, b=5,
                              args=(choke, p_out, p_in, t_out, q_liq, wct), xtol=0.01)
        except ValueError:
            c_ch = opt.minimize_scalar(
                __adapt_func_choke_abs,
                method="bounded",
                bounds=(0.3, 5),
                args=(choke, p_out, p_in, t_out, q_liq, wct),
            )
            if c_ch.fun > 10000:
                c_ch = {"const": p_in - p_out}
            else:
                c_ch = c_ch.x
    return c_ch


def __power_optimizer(
        pump_power: float,
        esp_electric_system: ees.EspElectricSystem,
        cs_power_fact: float,
        fluid_power: float,
        freq_shaft: float,
        t_cable: float,
) -> float:
    """
    Функция оптимизации мощности насоса при адаптации электротехнического расчета

    Вызывается в случае, если из замеров есть только мощность на СУ

    Parameters
    ----------
    :param pump_power: электрическая мощность насоса, Вт
    :param cs_power_fact: фактическая активная мощность на станции управления, Вт
    :param fluid_power: гидравлическая мощность, Вт
    :param freq_shaft: текущая частота вращения вала, Гц
    :param t_cable: температура на глубине спуска ПЭД, К

    Returns
    -------
    Абсолютное отклонение по активной мощности на станции управления
    """

    res = esp_electric_system.calc_electric_esp_system(
        pump_power=pump_power,
        fluid_power=fluid_power,
        freq_shaft=freq_shaft,
        t_cable=t_cable,
    )
    cs_power = res["cs_power"]

    return abs(cs_power_fact - cs_power)


def adapt_elsys(
        esp_electric_system: ees.EspElectricSystem,
        pump_power: float,
        fluid_power: float,
        freq_shaft: float,
        t_cable: float,
        cosf_fact: Optional[float] = None,
        motor_i_fact: Optional[float] = None,
        load_fact: Optional[float] = None,
        transform_voltage_fact: Optional[float] = None,
        cs_power_fact: Optional[float] = None,
) -> dict:
    """
    Функция расчета адаптационных коэффициентов для электротехнического расчета УЭЦН
    Расчет адаптационных коэффициентов происходит поочередно - снизу-вверх по компоновке УЭЦН

    Parameters
    ----------
    :param esp_electric_system: объект электрической системы УЭЦН
    :param pump_power: электрическая мощность насоса, Вт
    :param fluid_power: гидравлическая мощность, Вт
    :param freq_shaft: текущая частота вращения вала, Гц
    :param t_cable: температура на глубине спуска ПЭД, К
    :param cosf_fact: фактический косинус мощности, д.ед. - optional
    :param motor_i_fact: фактическая сила тока, А - optional
    :param load_fact: фактическая загрузка ПЭД, д.ед. - optional
    :param transform_voltage_fact: фактическое напряжение на отпайке трансформатора, В - optional
    :param cs_power_fact: фактическая активная мощность на станции управления, Вт - optional

    Returns
    -------
    Словарь с адаптационными коэффициентами:
        * корректировочный коэффициент для зависимости загрузка-косинус мощности
        * корректировочный коэффициент для зависимости загрузка-ампераж
        * адаптационный коэффициент для мощности насоса
        * адаптационный коэффициент для мощности на трансформаторе
        * адаптационный коэффициент для напряжения на ПЭД
    """

    c_pump_power = 1
    c_cosf = 1
    c_amperage = 1
    c_transform_power = 1
    c_motor_volt = 1

    if pump_power != 0 and fluid_power != 0:
        # Пересчет номинальной мощности ПЭД, сепаратора и протектора в зависимости от текущей частоты
        esp_electric_system._calc_equip_power(freq_shaft)

        # Если из фактических данных есть только активная мощность на СУ, то адаптация происходит за счет мощности
        if (
                cosf_fact is None
                and motor_i_fact is None
                and load_fact is None
                and transform_voltage_fact is None
                and cs_power_fact is not None
        ):
            # Запуск оптимизатора
            pump_power_adapt = opt.minimize_scalar(
                __power_optimizer,
                pump_power,
                args=(esp_electric_system, cs_power_fact, fluid_power, freq_shaft, t_cable),
                bounds=(0, 500000),
                method="bounded",
                tol=0.01,
            ).x
            # Адаптационный коэффициент для мощности насоса
            c_pump_power = pump_power_adapt / pump_power
        else:
            # TODO в 1.4.0 нужно избавиться от подобного рода проверок
            if load_fact is not None:
                # Адаптационный коэффициент для мощности насоса
                c_pump_power = (
                                       load_fact * esp_electric_system.motor_nom_power_fr
                                       - esp_electric_system.gassep_power
                                       - esp_electric_system.protector_power
                               ) / pump_power
                # Корректировочный коэффициент для характеристики ПЭД загрузка-косинус мощности
                if cosf_fact is not None:
                    c_cosf = cosf_fact / esp_electric_system.motor_cosf_func(load_fact)
                # Корректировочный коэффициент для характеристики ПЭД загрузка-ампераж
                if motor_i_fact is not None:
                    c_amperage = motor_i_fact / (
                            esp_electric_system.motor_nom_i * esp_electric_system.motor_amperage_func(load_fact)
                    )
            else:
                res = esp_electric_system.calc_electric_esp_system(
                    pump_power, fluid_power, freq_shaft, t_cable)

                load_calc = res["load"]

                # Адаптационный коэффициент для мощности насоса
                c_pump_power = 1
                # Корректировочный коэффициент для характеристики ПЭД загрузка-косинус мощности
                if cosf_fact is not None:
                    c_cosf = cosf_fact / esp_electric_system.motor_cosf_func(load_calc)
                # Корректировочный коэффициент для характеристики ПЭД загрузка-ампераж
                if motor_i_fact is not None:
                    c_amperage = motor_i_fact / (
                            esp_electric_system.motor_nom_i * esp_electric_system.motor_amperage_func(load_calc)
                    )

            # Пересчет силы тока на ПЭД и активной мощности на СУ с учетом скорректированных характеристик ПЭД и
            # адаптированной мощности насоса
            res = esp_electric_system.calc_electric_esp_system(
                pump_power=pump_power,
                fluid_power=fluid_power,
                freq_shaft=freq_shaft,
                t_cable=t_cable,
                c_pump_power=c_pump_power,
                c_cosf=c_cosf,
                c_amperage=c_amperage,
            )

            transform_power_calc = res["transform_power"]
            motor_i_calc = res["motor_i"]
            motor_power_calc = res["motor_power"]
            cable_resistance = res["cable_resistance"]
            load_calc = res["load"]

            # Расчет напряжения на ПЭД при известном фактическом напряжении на отпайке трансформатора
            if transform_voltage_fact is not None:
                motor_voltage_fact = transform_voltage_fact - 1.732 * motor_i_calc * cable_resistance

                # Расчет адаптационного коэффициента для напряжения на ПЭД
                c_motor_volt = motor_voltage_fact / (
                        motor_power_calc / (
                            1.732 * motor_i_calc * esp_electric_system.motor_cosf_func(load_calc) * c_cosf)
                )

            # Расчет адаптационного коэффициента для мощности трансформатора
            if cs_power_fact is not None:
                c_transform_power = cs_power_fact / (transform_power_calc * (2 - esp_electric_system.cs_eff))

    return {
        "c_pump_power": c_pump_power,
        "c_cosf": c_cosf,
        "c_amperage": c_amperage,
        "c_transform_power": c_transform_power,
        "c_motor_volt": c_motor_volt,
    }
